from typing import Callable
import matplotlib.pyplot as plt
import matplotlib
import math
import re
#import polynom
#from polynom import SPolynomial,Polynomial,Monom,Vector,Quotient
from . import polynom
from .polynom import SPolynomial,Polynomial,Monom,Vector,Quotient
class Op:
    def __init__(self,symbol:str,pri: int,arity: int,action: Callable,
                identity:set = None,direction="right",acts_on="left",unary_overload=None):
        self.pri=pri
        self.arity=arity
        self.action=action
        self.symbol=symbol
        self.identity=identity
        self.direction=direction
        self.acts_on=acts_on
        self.unary_overload=unary_overload
        if self.identity:
            self.id_rep=next(iter(self.identity))
    
    def intr(self,*args):    
        
        if len(args)!=self.arity and self.arity!="*":
            raise ValueError("Spatny pocet argumentu!")
        else:
            #print(self.action,args)
            return self.action(*args)
    def __repr__(self):
        return "Priority: {0}, arity: {1},interpretation: {2},direction: {3}, acts on: {4}".format(
            self.pri,self.arity,self.action,self.direction,self.acts_on
        )
class Parser:


    def __init__(self,preload=True,preparse=True,fill_id=True,force_func_brackets=False,implicit=False,
                restrict_symb=True,verbose=True,fill_implicit_ops=True,fractions=True):
        self.operators={}
        self.opsymbols=set()
        self.funcs={}
        self.funcsymbols=set()
        self.symbols=set()
        self.brackets=[]
        self.modifier="#"
        self.forbidden_symbols={"-","+","."} # Plus,- a . pred cislem python chape jako cislo. ALternativa je mist maskovani kontrolovat, jestli se tyto symboly vyskytuji na zacatku a neuznavat je jako cisla.
        self.modified_symbols=set()
        self.implicit_op="*"
        self.implicit=implicit # prevadet automaticky nedefinovane symboly na polynomy?
        self.orig_text=None
        self._temp_ops=set()
        self.verbose=verbose
        self.preparse=preparse
        self.fill_implicit_ops=fill_implicit_ops
        self.fill_id=fill_id
        self.force_func_brackets=force_func_brackets
        self.restrict_symb=restrict_symb
        self.fractions=fractions
        self.max_symbol_len=0
        # emergency error handling 
        self.max_error_depth=10
        self.__cur_error_depth=0
        self.__error_text=None

        if preload:
            self.load_standard()
        print(self)
    def __str__(self):
        return "\nParser with operators {0}\n {1:>20} {2} \n {3:>20} {4}".format(
            [self.unmake_unique_text(el) for el in list(self.operators.keys())],"and functions",list(self.funcs.keys()),"and brackets",self.brackets)
        
    def add_operator(self,op: str,pri: int,arity: int,action: Callable,identity:set =None,
                    direction="right",acts_on="left",implicit=False,unary_func=None,overwrite=False):
        if op in self.forbidden_symbols:
            op=self.make_unique(op)
        #print(type(self.operators),op,op in self.operators)
        if op in self.operators:
            if overwrite:
                self.delete_operator(op)
            else:
                raise ValueError("Operator uz je zaregistrovany! Pridejte 'overwrite=True' ")
        if arity==1:
            if acts_on=="right":
                direction="right"
            else:
                direction="left"
        
        if implicit:
            self.implicit_op=op
        if unary_func==None:
            uop=None
        else:
            uop=Op("",pri,1,unary_func[0],acts_on=unary_func[1])
        #print(uop)
        self.operators[op]=Op(op,pri,arity,action,identity=identity,direction=direction,acts_on=acts_on,unary_overload=uop)
        self.opsymbols.add(op)
        self.add_symbol(op)
        
        self._sort_ops()

    def add_symbol(self,symbol):
        self.symbols.add(symbol)
        self.max_symbol_len=max(map(len,self.symbols))

    def delete_operator(self,op):
        if op in self.forbidden_symbols:
            op=self.make_unique(op)
        try:
            del self.operators[op]
            self.opsymbols.remove(op)
        except KeyError:
            print(f"The parser does not have operator {op}! ")

    def delete_function(self,name):
        try:
            del self.funcs[name]
            self.funcsymbols.remove(name)
            self.symbols.remove(name)
        except KeyError:
            print(f"The parser does not have function {name}! ")
    def add_function(self,name: str,arity: int,action: Callable,identity:set =None):
        self.funcs[name]=Op(name,10000,arity,action,identity)
        self.funcsymbols.add(name)
        self.add_symbol(name)
        self._sort_functions()
    def make_unique(self,symbol):
        nt=self.modifier+symbol+self.modifier
        self.modified_symbols.add((symbol,nt))
        return nt
    def unmake_unique_text(self,text):
        for el in self.modified_symbols:
            text=text.replace(el[1],el[0])
        return text
    def add_brackets(self,brackets: list):
        if len(brackets)!=2:
            raise ValueError("Must specify a pair of brackets!")
        self.brackets.append(brackets)
        self.add_symbol(brackets[0])
        self.add_symbol(brackets[1])

    def delete_bracekts(self,brackets: list):
        try:
            self.bracekts.remove(brackets)
            self.symbols.remove(brackets[0])
            self.symbols.remove(brackets[1])
        except ValueError:
            print(f"The parser does not have brackets {brackets}")
            

    def _sort_ops(self):
        def sort_key(op):
            if op[1].arity==0:
                return 10**7-len(op[0])
            else:
                return op[1].pri
        #self.operators=dict(sorted(self.operators.items(),key=lambda op: op[1].pri))
        self.operators=dict(sorted(self.operators.items(),key=sort_key))
        
    def _sort_functions(self):
        self.funcs=dict(sorted(self.funcs.items(),key=lambda item:len(item[0])))
    def find_all(self,text,p,direction="right"):
        '''Yields all the positions of
        the pattern p in the string s.'''

        if direction=="right":
            if p=="":
                return
            i = text.find(p)
            while i != -1:
                yield i
                i = text.find(p, i+len(p))
        else:
            if p=="":
                return
            i = text.rfind(p)
            while i != -1:
                yield i
                i = text.rfind(p, i+len(p))


    def _filter_brackets(self,text:str):
        masked_inds=[[] for _ in self.brackets]
        #print(text)
        for bind,bracks in enumerate(self.brackets):
            left,right=bracks
            linds=[(pos,"l") for pos in self.find_all(text,left)]
            rinds=[(pos,"r") for pos in self.find_all(text,right)]
            inds=sorted(linds+rinds)
            lc=0
            rc=0
            for ind in inds:
                if lc==0:
                    lp=ind[0]
                if ind[1]=="l":
                    lc+=1
                else:
                     rc+=1
                if lc==rc:
                    rp=ind[0]
                    lc=0
                    rc=0
                    masked_inds[bind].append((lp,rp))
                
        return masked_inds
    
    def mask_text(self,text,brack_inds):
        masked_text=str(text)
        for ind_list in brack_inds:
            for lind,rind in ind_list:
                masked_text=masked_text[:lind]+" "*(rind-lind+1)+masked_text[rind+1:]
        #print("text: {0}, masked: {1}, brack_inds: {2}".format(text,masked_text,brack_inds))
        return(masked_text)


    def mask_text_im(self,text): #C onveniece routine, combines bracks and mask
        brack_inds=self._filter_brackets(text)
        return self.mask_text(text,brack_inds)

    def is_number(self,text):
        try:
            float(text)
        except ValueError:
            
            return False
        else:
            return True
    
    def convert_to_num(self,text):
        try:
            res=int(text)
        except ValueError:
            res=float(text)
        return res

    def strip_brackets(self,text):
        
        text=text.strip()
        for left,right in self.brackets:
            if text.startswith(left) and text.endswith(right):
                #print(f"yes it does {text}")
                len_left=len(left)
                len_right=len(right)
                cp=len_left
                while cp<len(text)-1:
                    li=text.find(left,cp)
                    ri=text.find(right,cp)
                    #print(text,li,ri,text[li],text[ri])
                    if ri<li:
                        return text
                    else:
                        cp=ri+len_right
                #print(f"Found brackets: {text}",end="")
                text=self.strip_brackets(text[len_left:-len_right])
                #print(f", stripping: {text}")
        if text.strip()=="":
            return "0"
        else:
            return text

    def strip2(self,text,brack_inds):
        #print(f"strip text {text}",brack_inds)
        for ind,bind in enumerate(brack_inds):
            #print(ind,bind)0
            if len(bind)==1:
                
                lind,rind=bind[0]
                len_left=len(self.brackets[ind][0])
                len_right=len(self.brackets[ind][1])
             #   print(len_left,len_right,lind,rind,text[len_left:rind])
                if lind==0 and rind==len(text)-len_right:
                    return text[len_left:rind]
        return text

    def check_forward_conflicts(self,text,symbol):
        for it_symbol in self.symbols:
            if len(it_symbol)>len(symbol):
                    if text.startswith(it_symbol):
                        return True
        return False


    def is_substring(self,text,my_pos,sub_len=1,let_pass={}):
        for symbol in self.symbols:
            if symbol in let_pass:
                continue
            for pos in self.find_all(symbol,text[my_pos:my_pos+sub_len]): # Najde pozici znaku v symbolu
                if my_pos-pos<0: # pozice znaku v symbolu je vetsi nez nase misto v textu (tudiz to nemuze byt match)
                    continue
                else:
                    if text[my_pos-pos:my_pos+len(symbol)-pos]==symbol:
                        return True,my_pos+len(symbol)-pos
        return False,None

    def contains_illegals(self,text):
            letind=0
            while letind<len(text):
                #print(letind)
                letter=text[letind]
                if letter not in self.symbols.union({"."," ",","}) and not letter.isdigit(): #is the letter missing from symbols?
                    found,new_ind=self.is_substring(text,letind)
                    if not found:
                        if self.implicit:
                            if letter.isalpha() or not self.restrict_symb:
                                #self.add_monvar(letter)
                                self.add_polvar(letter)
                                if self.verbose:
                                    print(f"Converting {letter} to variable")
                            else:
                                raise ValueError(f"Can't implicitly convert the non-alphabetic symbol {letter} to variable. "
                            "To override this, set restrict_symb to 'False'")
                        else:
                            return True,letter
                    else:
                        letind=new_ind
                else:
                    letind+=1
            return False,None



            
    def fill_implicit(self,text):
        nssymbols={"{","}"}
        for lbrack,rbrack in self.brackets:
            #modlbrack = lbrack if lbrack.isalnum() or lbrack in nssymbols else "\\"+lbrack
            #modrbrack = rbrack if rbrack.isalnum() or rbrack in nssymbols else "\\"+rbrack
            #modlbrack=re.escape(lbrack)
            #modrbrack=re.escape(rbrack)
            #print(lbrack,rbrack,nssymbols,modlbrack,modlbrack)
            #print(f"{modrbrack}(\d)")
            text=re.sub(f"(\d)\s*{re.escape(lbrack)}",lambda s: s[1]+f"{self.implicit_op}{lbrack}",text)
            text=re.sub(f"{re.escape(rbrack)}\s*(\d)",lambda s: f"{rbrack}{self.implicit_op}"+s[1],text)
            for symb,op in self.operators.items():
                if op.arity==0:
                    text=re.sub(f"({re.escape(symb)})\s*{re.escape(lbrack)}",lambda s: s[1]+f"{self.implicit_op}{lbrack}",text)
                    text=re.sub(f"{re.escape(rbrack)}\s*({re.escape(symb)})",lambda s: f"{rbrack}{self.implicit_op}"+s[1],text)
        for lbrack in (brack[0] for brack in self.brackets):
            for rbrack in (brack[1] for brack in self.brackets):
                #modlbrack = lbrack if lbrack.isalnum() or lbrack in nssymbols else "\\"+lbrack
                #modrbrack = rbrack if rbrack.isalnum() or rbrack in nssymbols else "\\"+lbrack
             #   modlbrack=re.escape(lbrack)
             #  modrbrack=re.escape(rbrack)
                text=re.sub(f"{re.escape(rbrack)}\s*{re.escape(lbrack)}",f"{rbrack}*{lbrack}",text)
        for name,func in self.funcs.items():
            text=re.sub(f"(\d)\s*{name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)
            for symb2,op2 in self.operators.items():
                if op2.arity==0: 
                    for ind in self.find_all(text,f"{symb2}{name}"):      

                        if ind==-1:
                            continue
                        else:
                            if not self.is_substring(text,ind,len(f"{symb2}{name}"))[0]:
                                text=re.sub(f"({symb2}){name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)
                    
                    text=re.sub(f"({symb2})\s+{name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)

        for symb,op in self.operators.items():
            if op.arity==0:
                text=re.sub(f"(\d)\s*{symb}",lambda s: f"{s[1]}{self.implicit_op}{symb}",text)
                text=re.sub(f"{symb}\s*(\d)",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)
                for symb2,op2 in self.operators.items():
                    if op2.arity==0:
                        for ind in self.find_all(text,f"{symb}{symb2}"):       
                            if ind==-1:
                                continue
                            else:
                                if not self.is_substring(text,ind,len(f"{symb}{symb2}"))[0]:
                                    text=re.sub(f"{symb}\s*({symb2})",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)
                        text=re.sub(f"{symb}\s+({symb2})",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)
        return text

    def substitute(self,text):
        var_ind=text.find("|")
        if var_ind!=-1:
            var_enum=text[var_ind+1:].split(";")
            text=text[:var_ind]
            sub_list=[]
            
            for sub in var_enum:
                found_asign=False
                ind=sub.find("=") 
                #assert ind!=-1, f"Wrong substitution in {sub}"
                if ind!=-1:
                    found_asign=True
                    sub_list.append((sub[:ind].strip(),sub[ind+1:].strip()))  
                    for dirsub in sub_list:
                        text=re.sub(f"{dirsub[0]}",f"({dirsub[1]})" ,text)
                else:
                    ind=sub.find("->") 
                    #assert ind!=-1, f"Wrong substitution in {sub}"
                    if ind!=-1: 
                        found_asign=True
                        symbol,value=sub[:ind].strip(),sub[ind+2:].strip()
                        #print(symbol,value)
                        if symbol not in self.opsymbols:
                            self._temp_ops.add(symbol)
                            if value.startswith("\\"):
                                value=eval("lambda "+value[1:])
                                self.add_operator(symbol,10**4,2,value)
                            else:
                                if self.is_number(value):
                                    value=self.convert_to_num(value)
                                self.add_operator(symbol,10**4,0,lambda value=value: value)
                    else:
                        
                        symbol=sub.strip()
                        if symbol.isalpha() or not self.restrict_symb:
                          
                            if symbol not in self.opsymbols:
                                #self.add_monvar(symbol)
                                self.add_polvar(symbol)
                                
                        else:
                            raise ValueError(f"Can't use {symbol} as a variable name, use letters of the alphabet."
                        "To override this, set restrict_symb to 'False'")
                                
                        
        return text
    def add_monvar(self,symbol):
        self._temp_ops.add(symbol)
        self.add_operator(symbol,10**7,0,
        lambda value=Monom(1,{symbol:1}):value)
    def add_polvar(self,symbol):
        self._temp_ops.add(symbol) 
        self.add_operator(symbol,10**7,0,
        lambda value=Polynomial(Monom(1,{symbol:1})):value)
    def check_brackets(self,text):
        
        bracknums=[[0,0] for _ in self.brackets]
        last_left=[]
        for letind,letter in enumerate(text):
            for ind,brack in enumerate(self.brackets):
                if letter==brack[0]:
                    bracknums[ind][0]+=1
                    last_left.append(ind)
                if  letter==brack[1]:
                    bracknums[ind][1]+=1
                    if bracknums[ind][1]>bracknums[ind][0]:
                        raise ValueError(f"Spatne uzavrene zavorky (pravych zavorek je do pozice {letind+1} vic nez levych)!")
                    if ind==last_left.pop():
                        pass
                    else:
                        raise ValueError(f"Zkrizene zavorky na pozici {letind+1}!")
                    
                #print(bracknums,ind)
                
                

        if any(num[1]!=num[0] for num in bracknums):
            raise ValueError("Spatne uzavrene zavorky (levych je vic nez pravych)!")


    def preprocess(self,text):
        text=re.sub("(--)+","+",text) #sudy pocet minusu -> jedno plus
        
        #print(text)
        for op in self.operators:
            if self.operators[op].arity<2:
                continue
            for op2 in self.operators:
                if self.operators[op2].arity<2:
                    continue
                symb=self.unmake_unique_text(op)
                symb2=self.unmake_unique_text(op2)
                #print(op,op2)
                
                if symb in text and symb2 in text:
                 
                    #modsymb = symb if symb.isalnum() else "\\"+symb
                    #modsymb2= symb2 if symb2.isalnum() else "\\"+symb2
                    #print(symb,symb2,modsymb,modsymb2)   
                    if self.operators[op].pri>self.operators[op2].pri:
                        text=re.sub(f"{re.escape(symb)}{re.escape(symb2)}(-?\d+\.?\d*)",lambda s: f"{symb}({symb2}{s[1]})",text) #*- -> *(-)
        
        return text

    def parse(self,text:str,draw=False,verbose=None,implicit=None,preparse=None,fill_implicit_ops=None,fractions=None,**kwargs):
        self.partial_results=[]
        self.orig_text=text
        self.check_brackets(text)
        text=self.substitute(text)
        
        orig_impl=self.implicit
        if implicit!=None:
            self.implicit=implicit
        orig_verbose=self.verbose
        if verbose!=None:
            self.verbose=verbose
        orig_preparse=self.preparse
        if preparse!=None:
            self.preparse=preparse
        orig_fill_implicit_ops=self.fill_implicit_ops
        if fill_implicit_ops!=None:
            self.fill_implicit_ops=fill_implicit_ops
        orig_fractions=self.fractions
        #print(fractions,self.fractions,orig_fractions)
        if fractions!=None:
            self.fractions=fractions
        if self.preparse:
            text=self.preprocess(text)
        

        for symb in self.forbidden_symbols:
            if self.make_unique(symb) in self.symbols:
                if symb in text:
                    text=text.replace(symb,self.make_unique(symb))
        
        found_illegal,illegal_symbol=self.contains_illegals(text)
        if found_illegal:
            raise ValueError(f"The expression {text} contains an undefined symbol '{illegal_symbol}'!")
        if self.fill_implicit_ops:
            text=self.fill_implicit(text)
        if self.preparse:
            if verbose:
                print("Preparsed: ", self.unmake_unique_text(text))
            
            #text=re.sub("\*-(\d+\.?\d*)",lambda s: f"*(-{s[1]})",text) #*- -> *(-)
            #text=re.sub("\*\+(\d+\.?\d*)",lambda s: f"*(+{s[1]})",text) #*+ -> *(+)

        
        
        
        #print(text)
        #input()
            #return str(self._parse(text))
        try:    
            res=self._parse(text)
        
        finally:
            for op in set(self._temp_ops):
                self._temp_ops.remove(op)
                self.opsymbols.remove(op)
                self.symbols.remove(op)
                del self.operators[op]
                self.implicit=orig_impl
                self.verbose=orig_verbose
                self.preparse=orig_preparse
                self.fill_implicit_ops=orig_fill_implicit_ops
                self.fractions=orig_fractions
            self.__cur_error_depth=0
            
        if draw:
            self.draw_parse_tree(**kwargs)
        return res

    def sparse(self,*args,**kwargs):
        res=self.parse(*args,**kwargs)
        if isinstance(res,(int,float)):
            return polynom.truncate_number(res)
        else:
            return str(res)
        
    def _parse(self,text:str,level=(0,0)):
        #self.partial_results.append((level,self.unmake_unique_text(text),"sym"))
        text=self.strip_brackets(text)
        self.partial_results.append([level,self.unmake_unique_text(text),"sym",None])
        for symbol,op in self.operators.items():
            
        # while True:
                #print(f"text: {text}")
                brack_inds=self._filter_brackets(text)
                #text=self.strip2(text,brack_inds)
                #print(f"Before mask {text}") 
                if op.direction=="right":
                    ind=self.mask_text(text,brack_inds).find(symbol)
                else:
                    ind=self.mask_text(text,brack_inds).rfind(symbol)
                #ind=text.find(symbol)
                if ind==-1: 
                   # break
                   continue
                else:
                    if op.direction=="right":
                        is_conflict=self.check_forward_conflicts(text[ind:ind+self.max_symbol_len],symbol)
                    else:
                        if ind<self.max_symbol_len:
                            is_conflict=self.check_forward_conflicts(text[ind::-1],symbol)
                        else:
                            is_conflict=self.check_forward_conflicts(
                                text[ind:ind-self.max_symbol_len:-1],symbol)
                    if is_conflict: #alternativa: maskovat prekryvajici se operatory krizkem #
                        continue
                    lp=text[:ind]
                    rp=text[ind+len(symbol):]
                    #print(symbol)
                    #print(f"Before eval: lp = {lp}, rp= {rp}")
                    
                    if op.arity==0:
                        text=lp+str(op.intr())+rp    
                    else:
                        if op.arity==1:
                            text=self.expr_eval1(lp,rp,op,level=level)
                     #       print(lp,rp)
                          
                        elif op.arity==2:
                            if ""  in [lp,rp] and op.unary_overload:
                            #    print("Overloading")
                                if lp=="":
                             #       print("Overloading right")
                                    if op.unary_overload.acts_on=="left":
                                        
                                        raise ValueError("Wrong direction of action!")
                                else:
                                    if op.unary_overload.acts_on=="right":
                                        raise ValueError("Wrong direction of action")
                                text=self.expr_eval1(lp,rp,op.unary_overload,level=level)
                            else:
                                text=str(self.expr_eval2(lp,rp,op,level=level))
                                
                            #print(f"Text: {text}")
        text=str(self.eval_funcs(text,level=(level[0],level[1])))

        #print(f"Konec: {text}")
        if self.is_number(text): # Obecne by tu mohlo byt nejake jine kriterium
            #return(str(float(text)))
            
            res=self.convert_to_num(text) # a zde by se mohli vracet obecnejsi algebraicke objekty
            self.partial_results.append([level,res,"res",None])
            return(res)
        else:
            print(f"'{text}' neni Finalni!")
            if self.__error_text==text:
                self.__cur_error_depth+=1
                if self.__cur_error_depth>=self.max_error_depth:
                    raise ValueError("Nezpracovatelny vyraz!")
            else:
                self.__error_text=text
                self.__cur_error_depth=0
                
            return(self._parse(text))

    def expr_eval1(self,lp,rp,op,level=(0,0)):
        #print(f"Unary, expr= {expr},op= {op.symbol}")
        #if self.is_number(expr):
        #    return op.intr(float(expr))
        #else:
        #return self.expr_eval1(self._parse(expr),op)
        xl,yl=level
        if op.acts_on=="left": 
            return str(op.intr(self._parse(lp,level=(xl,yl+1))))+rp
        else:
            return lp+str(op.intr(self._parse(rp,level=(xl,yl+1))))
     
        

    def expr_eval2(self,lp,rp,op,level=(0,0)):
        xl,yl=level
        #print(f"lp = {lp}, rp= {rp},op= {op.symbol}")
        #if self.is_number(lp) and self.is_number(rp):
            #print(f"returning {op.intr(float(lp),float(rp))}")
         #   return op.intr(float(lp),float(rp))

        if ""  in [lp,rp]:
            
            if self.fill_id and op.identity:
                
                if lp=="":
               #     print(f"Ker rep: {op.kernel_rep}")
                    lp=str(op.id_rep)
                if rp=="":
                    rp=str(op.id_rep)
            else:
                raise ValueError("Wrong input!")
        #return self.expr_eval2(self._parse(lp),self._parse(rp),op)
        self.partial_results[-1][3]=self.unmake_unique_text(op.symbol)    

        return op.intr(self._parse(lp,level=(xl-1/2**yl,yl+1)),self._parse(rp,level=(xl+1/2**yl,yl+1)))

    def eval_funcs(self,text,level=(0,0)):
        
        for symb in self.funcsymbols:
            if text.startswith(symb):
                
                if self.force_func_brackets:
                    if not any((text[len(symb):].strip()).startswith(lbra) for lbra,_ in self.brackets):
                        raise ValueError("Funkce nema zavorky!")
                text=self.strip_brackets(text[len(symb):])
                #print(text[len(symb):])
                

                brack_inds=self._filter_brackets(text)
                #print(text,brack_inds)
                commas=self.find_all(self.mask_text(text,brack_inds),",")
                expr_list=[]
                last_pos=0
                for comma_pos in commas:
                    expr_list.append(text[last_pos:comma_pos])
                    last_pos=comma_pos+1

                expr_list.append(text[last_pos:])
                #print(expr_list)
                arity=self.funcs[symb].arity
                arg_num=len(expr_list)
                
                if arity != "*":
                    if arg_num!=arity:
                        raise ValueError("Spatny pocet argumentu!") 
                xl,yl=level
                if arg_num%2==0:
                    xlevels=list(range(-(arg_num//2),0))+list(range(1,arg_num//2+1))
                else:
                    xlevels=list(range(-(arg_num//2),arg_num//2+1))
                return self.funcs[symb].intr(*(self._parse(el,level=(xl+xlevels[ind]/arg_num**yl,yl+1)) 
                                            for ind,el in enumerate(expr_list)))
        return text

    def simple_tree(self,part_res):
        part_res=sorted(part_res,key=lambda t: t[0][1])
        tree=[]#list((el[2],el[1]part_res)
        levels=[]
        
        for el in part_res:
            level=el[0][1]
            if level not in levels:
                levels.append(level)
                tree.append([])
            if el[2]=="sym":
                tree[level].append({"sym":el})
                for rel in part_res:
                    if rel[0]==el[0] and rel[2]=="res":
                        tree[level][-1]["res"]=rel
                        break
        #print(expr_by_levels)
        return tree
        
        

    def print_simple_tree(self,indtensity=5,row_height=1):
        indtensity=indtensity
        row_height=row_height
        base=3
        tree=self.simple_tree(self.partial_results)
        for exprs in tree:
            #print(exprs)
            #input()
            sorted_expr=sorted(exprs,key=lambda el: el["res"][0][1] )
            #print(sorted_expr)
            cp=0
            
            for el in sorted_expr:
                x=el["sym"][0][0]
                y=el["sym"][0][1]
                #pos=(base+x)
                pos=(base+round(x))
                true_space=(pos)*indtensity
            #    print(" "*(true_space-cp),end="")
                text="{0} [={1},:{2}]".format(el["sym"][1],el["res"][1],el["sym"][3] if el["sym"][3] else "")
             #   print(text,end="")
                cp=true_space+len(text)
                
                
            print("\n"*row_height,end="")
        
    def draw_parse_tree(self,pr=None,xc=0.5,yc=0.9,size0=20,adapt_size=False,zepr=None,save=False,filename=None):
        if pr is None:
            tree=self.simple_tree(self.partial_results)
        else:
            tree=self.simple_tree(pr)
        if save:
            matplotlib.use("Agg")
            x0,y0=0.15,1.1
        else:
            #matplotlib.use("Qt5Agg")
            matplotlib.use("Qt5Agg")
            x0,y0=0.2,1.1
        height=0.2
        width=0.2
        size_exp=1.1
        fig,ax=plt.subplots(figsize=(15,7))
        mng = plt.get_current_fig_manager()
        try:
            mng.window.state("zoomed")
        except AttributeError:
            pass
        ax.text(0.5,1.1,self.orig_text,size=size0,color="green",horizontalalignment="center",verticalalignment="center")

        for exprs in tree:
            
            #print(exprs)
            #input()
            sorted_expr=sorted(exprs,key=lambda el: el["res"][0][1] )
            #print(sorted_expr)
            replace_powers=re.compile("\^\(?(-?\d+)\)?")
            for el in sorted_expr:
                level=el["sym"][0][1]
                x=xc+el["sym"][0][0]*width
                y=yc-level*height
                #text1="{:^12}".format(el["sym"][1])
                #text2="{:^12.3f}".format(el["res"][1])
                text1=el["sym"][1]
                res=el["res"][1]
                if type(el["res"][1])==float:
                    text2=str(res) if type(res)==int else polynom.truncate_number(res,3)
                else:
                    text2=str(res) 
                text1=replace_powers.sub(lambda s: f"${{}}^{{{s[1]}}}$",text1)
                text2=replace_powers.sub(lambda s: f"${{}}^{{{s[1]}}}$",text2)
                #text1=re.sub("\^\(?(\d+)\)?",lambda s: f"${{}}^{{{s[1]}}}$",text1)
                #text2=re.sub("\^(\d+)",lambda s: f"${{}}^{{{s[1]}}}$",text2)

             #   print(x,y)
                if adapt_size:
                    size=size0*size_exp**(-level)
                else:
                    size=size0
                ax.text(x,y,text1,size=size,horizontalalignment="center",verticalalignment="center")
                ax.text(x,y+height/2,text2,size=size*0.8,color="red",horizontalalignment="center",verticalalignment="center")
                if el["sym"][3]:
                    x=xc+(el["sym"][0][0])*width
                    y=yc-(level+1)*height
              #      print(el["sym"][3],el["sym"][1],level)
                    #ax.text(x,y,"{:^12}".format(el["sym"][3]),size=size*0.8,color="blue")
                    ax.text(x,y,el["sym"][3],size=size,color="blue",horizontalalignment="center",verticalalignment="center")
            for spine in ax.spines.values():
                spine.set_visible(False)
            ax.xaxis.set_ticks([])        
            ax.yaxis.set_ticks([]) 
                #plt.plot(np.arange(0,1,0.1),np.arange(0,1,0.1))
            level+=1
        if save:
            plt.savefig(filename+".png")
        else:
            plt.show()
        #plt.close(fig)
    def draw_exprs(self,*expressions,verbose=False,**kwargs):
        for ind,expr in enumerate(expressions):
            self.parse(expr,draw=True,save=True,filename=f"SavedFigures/Expr. # {ind+1}",**kwargs,verbose=verbose)
    def load_standard(self):
        self.add_operator("*",100,2,lambda x,y: x*y,identity={1})
        self.add_operator("/",110,2,lambda x,y: x/y,direction="left")
        self.add_operator("=",-10,2,self.solve2)
        self.add_operator("+",10,2,lambda x,y: x+y,identity={0},unary_func=(lambda x: x,"right"))
        self.add_operator("-",12,2,lambda x,y: x-y,identity={0},direction="left",unary_func=(lambda x: -x,"right"))
        #self.add_operator("m",100,1,lambda x: -x,acts_on="right")
        #self.add_operator("^2",190,1,lambda x: x**2,acts_on="left")
        self.add_operator("#",-1,1,lambda x: x**2,acts_on="right")
    #  self.add_operator("~2",190,1,lambda x: x**2,acts_on="right")
        self.add_operator("^",200,2,lambda x,y: x**y)
        
        self.add_operator("**",200,2,lambda x,y: x**y)
        self.add_operator("e",1000,0,lambda: math.e)
        self.add_operator("pi",1000,0,lambda: math.pi)
        self.add_operator("π",1000,0,lambda: math.pi)
        def ldiv(x,y): 
            if type(x) in [int,float]:
                x=Polynomial(x)
            return x.longdiv(y)[0]
        def ldiv_modulo(x,y):
            if type(x) in [int,float]:
                x=Polynomial(x)
            return x.longdiv(y)[1]
        def deriv(pol,def_var=None,full_set=None):
            
            if full_set==None:
                full_set=set()
            if isinstance(pol,(int,float)):
                return 0
            elif isinstance(pol,Vector):
                if pol==0:
                    return 0
                for comp in pol:
                    #print("comp",comp)
                    if isinstance(comp,Polynomial):
                     #   print("fs above above",full_set)
                        full_set.update(comp.varset)
                      #  print("fs above:",full_set)
                    #print("fs_ad",full_set,comp)
                return Vector(*(deriv(comp,def_var=def_var,full_set=full_set) for comp in pol))
            else:
                if def_var!=None:
                    return pol.deriv(def_var)
                else:
                    if not full_set:
                     #   print("fs:",full_set,pol,repr(pol),type(pol))
                        full_set=pol.varset
                      #  print("fs:",full_set)
                    if len(full_set)==1:
                        if def_var!=None:
                            var=def_var
                        else:
                            var=next(iter(full_set))
                       # print("fs below:",full_set)
                        return pol.deriv(var)
                    else:
                        sorted_vars=list(sorted(full_set))
                        if sorted_vars:
                            return Vector(*(deriv(pol,def_var=var) for var in sorted_vars ))
                        else:
                            return Polynomial(0)
                
        self.add_operator(":",-5,2,ldiv)
        self.add_operator("%",-4,2,ldiv_modulo)
        self.add_operator("'",193,1,deriv,acts_on="left")
        #self.add_function("g",3,lambda x,y,z: z*abs(x-y))

        self.add_function("sin",1,math.sin)
        self.add_function("cos",1,math.cos)
        self.add_function("asin",1,math.asin)
        self.add_function("acos",1,math.acos)
        self.add_function("sqrt",1,math.sqrt)
        self.add_function("√",1,math.sqrt)
        self.add_function("exp",1,math.exp)
        self.add_function("ln",1,math.log)
        self.add_function("log",1,math.log10)
        self.add_function("tan",1,math.tan)
        self.add_function("atan",1,math.atan)
        self.add_function("abs",1,abs)
        def dot(v,w):
            if not isinstance(v,Vector):
                raise ValueError("The left argument of the function 'dot' is not a vector!")
            return v.dot(w)
        
        def cross(v,w):
            if not isinstance(v,Vector):
                raise ValueError("The left argument of the function 'cross' is not a vector!")
            return v.cross(w)

        
        self.add_function("V","*",Vector)
        self.add_function("dot",2,dot)
        self.add_function("cross",2,cross)
        self.add_function("Q","*",Quotient)
        self.add_brackets("()")
        self.add_brackets("{}")
        self.add_brackets("[]")
    
    def solve(self,lhs,rhs):
        lhs=Polynomial(lhs)
        rhs=Polynomial(rhs)
        
        if lhs.order>1 or rhs.order>1:
            raise NotImplementedError("Nelinearni rovnice zatim neumime resit")
        else:
            
            lvar=lhs.varset
            rvar=rhs.varset
            #print(len(lvar),len(rvar))
            #if len(lvar)==len(rvar)==0:
            if (not lvar) and (not rvar):
                
                if lhs!=rhs:
                    raise ValueError("Nejedna se o rovnici")
                else:
                    return "Always true"
            else:
                #print("1")

                if not lvar:
                    rvar=next(iter(rhs.varset))
                    lvar=rvar
                else:
                    lvar=next(iter(lhs.varset))
                    rvar=lvar
                if lvar!=rvar:
                    raise ValueError("Rovnice musi byt ve stejnych promennych")
            
            b,a=lhs.get_coefs(lvar,at_least=1).values()
            d,c=rhs.get_coefs(lvar,at_least=1).values()
            num=d-b
            den=a-c
            
            if den==0:
                if num==0:    
                    return "Always true"
                else:
                    return "Never True"
            else: 
                return num/den

    def solve2(self,lhs,rhs):
        """ def make_whole(x,y):
            for _ in range(5):
                if int(x)==x and int(y)==y:
                    x,y=int(x),int(y)
                    break
                x,y=x*10,y*10
            return x,y"""
        lhs=Polynomial(lhs)
        rhs=Polynomial(rhs)
        
        if lhs.order>2 or rhs.order>2:
            raise NotImplementedError("Rovnice vetsiho nez druheho radu zatim neumime resit.")
        else:
            
            lvar=lhs.varset
            rvar=rhs.varset
            #print(len(lvar),len(rvar))
            #if len(lvar)==len(rvar)==0:
            if (not lvar) and (not rvar):
                
                if lhs!=rhs:
                    raise ValueError("Nejedna se o rovnici")
                else:
                    return "Always true"
            else:
                #print("1")

                if not lvar:
                    rvar=next(iter(rhs.varset))
                    lvar=rvar
                else:
                    lvar=next(iter(lhs.varset))
                    rvar=lvar
                if lvar!=rvar:
                    raise ValueError("Rovnice musi byt ve stejnych promennych, soustavy zatim neumime resit.")
            
            c1,b1,a1=lhs.get_coefs(lvar,at_least=2).values()
            c2,b2,a2=rhs.get_coefs(lvar,at_least=2).values()
           # print(a1,b1,c1)
           # print(a2,b2,c2)
            if a1==a2:
                num=c2-c1
                den=b1-b2
                
                if den==0:
                    if num==0:    
                        return "Always true"
                    else:
                        return "No solution"
                else: 
                    if self.fractions:
                        print("fractions")
                        #num,den=make_whole(num,den)
                        return Quotient(num,den)
                    else:
                        return num/den if num%den else int(num//den)
            else:
                a=a1-a2
                bh=(b1-b2)/2
                c=c1-c2
                D=bh**2-a*c
                print(a,bh,c,D)
                if D<0:
                    return "No solution"
                elif D==0:
                    return -bh/(a)
                else:
                    sqrtD=math.sqrt(D)
                    if self.fractions:
                        print("Fractions")
                        #print("Got res: ",sqrtD-bh,-sqrtD-bh,a,Quotient(sqrtD-bh,a),Quotient(-sqrtD-bh,a))
                        #return (Vector(Quotient(sqrtD-bh,a),Quotient(-sqrtD-bh,a)))
                        if int(sqrtD)==sqrtD or int(1/sqrtD)==1/sqrtD:
                            num1,num2,den=-bh+sqrtD,-bh-sqrtD,a
                            print(num1,num2,den)
                            #inum1,iden1=make_whole(num1,den)
                            #inum2,iden2=make_whole(num2,den)
                            #return Vector(Quotient(inum1,iden1),Quotient(inum2,iden2)) 
                            return Vector(Quotient(num1,den),Quotient(num2,den)) 
                        
                        D=polynom.truncate_number(D)
                        #num,den=make_whole(-bh,a)
                        #vertex=Quotient(num,den)
                        vertex=Quotient(-bh,a)
                        print(vertex,repr(vertex),vertex.p.isconst,vertex.q.isconst)
                        if vertex==0:
                                    vertex=""
                        if a<0:
                            
                            if a==-1:
                                
                                return (Vector((vertex,f"-√({D})"),(vertex,f"+√({D})")))
                            else:
                                return (Vector((vertex,f"-√({D})/{-a}"),(vertex,f"+√({D})/{-a}")))
                        else:
                            if a==1:
                                return (Vector((vertex,f"+√({D})"),(vertex,f"-√({D})")))
                            else:
                                return (Vector((vertex,f"+√({D})/{a}"),(vertex,f"-√({D})/{a}")))
                    else:
                        return (Vector(sqrtD,-sqrtD)-bh)*(1/a)

    def longdiv(self,s1,s2=None,draw=False,implicit=True,**kwargs):
        if s2==None:
            s=s1.split(":")
            if len(s)!=2:
                raise ValueError("The expression must contain exactly  one ':' sign!")
            elif any(t.strip()=="" for t in s):
                raise ValueError("There have to non-empty expressions on each side of the division sign!")
            s1,s2=s
            if "|" in s2:
                _,sub,*_=s2.split("|")
                s1+=" | "+sub

        pol1=self.parse(s1,implicit=implicit,verbose=False,**kwargs)
        pol2=self.parse(s2,implicit=implicit,verbose=False,**kwargs)
        if type(pol1) in [int,float]:
            pol1=Polynomial(pol1)
        if type(pol2) in [int,float]:
            pol2=Polynomial(pol2)
        
        res,zbytek,partial=pol1.longdiv(pol2)
        #print(partial)
        spartial=list(map(lambda t: tuple(map(str,t)),partial))
        if draw:
            self.draw_ldiv(spartial,str(pol2),**kwargs)
        return str(res),str(zbytek),list(map(lambda t: tuple(map(str,t)),partial))
    
    def draw_ldiv(self,partial,pol2,use_colors=True,color_mode=1,save=False,filename=None,size=18):
        assert len(partial)>0,"Chybi mezivysledky!"
    
        if save:
            matplotlib.use("Agg")
            x0,y0=0.15,1.1
        else:
            matplotlib.use("Qt5Agg")
            x0,y0=0.2,1.1
  
        fig,ax=plt.subplots(figsize=(15,7))
        mng = plt.get_current_fig_manager()
        try:
            mng.window.state("zoomed")
        except AttributeError:
            pass
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.xaxis.set_ticks([])        
        ax.yaxis.set_ticks([]) 
        def subpow(text): return re.sub("\^\(?(-?\d+)\)?",lambda s: f"${{}}^{{{s[1]}}}$",text)
        nice_partial=[(subpow(text1),subpow(text2)) for text1,text2 in partial ]
        print(nice_partial)
        #ax.text(0.5,1.1,self.orig_text,size=size0,color="green",horizontalalignment="center",verticalalignment="center")
        font = {'family' : 'monospace',
        'weight' : 'normal',
        'size'   : size}
        matplotlib.rc('font', **font)
        #print(partial)
        nice_lhs=nice_partial[0][0]
        adjl=len(list(self.find_all(nice_lhs,"^")))
        adjconst=7
        if use_colors:
            colors=["blue","green","orange","darkmagenta"]*100
        else:
            colors=["black"]*400   
        #xlevel0=len("{0} : {1} = ".format(lhs,pol2))
        pol2=subpow(str(pol2))
        adjm=len(list(self.find_all(pol2,"^")))
        xlevel0=len(" : {0} = ".format(pol2))-adjm*7
        xlevel=xlevel0
        respos=0
        toplevel=0
        ylevel=toplevel
        height=0.1
        #size=15
        #print("{0} : {1} = {2}".format(lhs,pol2,rhs))
        if color_mode==1:
            lcolor=colors[0]
        elif color_mode==2:
            lcolor="black"
        ax.text(x0,y0+ylevel*height,"{0}".format(nice_lhs),size=size,color=lcolor,
                horizontalalignment="right",verticalalignment="center")
        ax.text(x0,y0+ylevel*height," : {0} = ".format(pol2),size=size,color="black",
                horizontalalignment="left",verticalalignment="center")
        ylevel+=1
        
        last_color=colors[0]
        if color_mode==1:
            colors=colors[1:]
        elif color_mode==2:
            last_color=colors[0]
            colors=colors
        if len(partial)==1:
            ax.text(x0,y0-toplevel*height," "*xlevel+str(0),size=size,color="black",
                    horizontalalignment="left",verticalalignment="center") 
        for (r,s),color in zip(nice_partial[1:],colors):
            if color_mode==1:
                lcolor=color
                rcolor=last_color
            elif color_mode==2:
                lcolor=color
                rcolor=color
            #print(r,s,"{0:>{ljust}}".format(r,ljust=ljust)) "x{0:>{ljust}}".format(r,ljust=ljust)
            adjl=len(list(self.find_all(r,"^")))
            ax.text(x0,y0-ylevel*height,"{0}".format(r),size=size,color=lcolor,
            horizontalalignment="right",verticalalignment="center")
            adjl=len(list(self.find_all(s,"^")))
            ax.text(x0,y0-toplevel*height," "*xlevel+" {0}".format(s[respos:]),size=size,color=rcolor,
                    horizontalalignment="left",verticalalignment="center")            
            respos=len(s)
            print(respos)
            xlevel=xlevel0+respos-adjl*adjconst
            last_color=color
            ylevel+=1


        #if respos==0:
        #  ax.text(x0,y0+toplevel," "*xlevel+" {}".format(0),size=size,color=lcolor,horizontalalignment="center",verticalalignment="center")            
        if save:
            plt.savefig(filename+".png",bbox_inches='tight')
            
                

        else:
            plt.show()
        #plt.close(fig)
        

    def ldiv_and_save(self,*exprlist,**kwargs):
        for ind,expr in enumerate(exprlist):
            
            self.longdiv(expr,draw=True,save=True,filename=f"SavedFigures/Deleni #{ind+1}",**kwargs)

        

if __name__=="__main__":                

    p=Parser()
    