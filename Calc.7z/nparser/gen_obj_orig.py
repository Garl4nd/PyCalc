from abc import ABC,abstractmethod,abstractproperty
import itertools as it
import functools as ft
import polynom as pl
from operator import mul
import math

class GeneralObject(ABC):
    @abstractproperty
    def name(self):
        pass
    @abstractproperty
    def evaluables(self):
        return int,float
    @abstractproperty
    def is_evaluable(self):
        return False
    @property
    def coef(self):
        return self._coef
    @coef.setter
    def coef(self,x):
        self._coef=x

    def __init__(self,*attached_objs: "GeneralObject"):
        self.attached=attached_objs
        #print(self.attached)
        self._coef=1
        super().__init__()

    def __add__(self,other):
        import genpolynom
        print("adding")
        return genpolynom.Monom(self)+genpolynom.Monom(other)
        if self==other:
         #   print("attached:",self.attached)
            new_obj=self.__class__(*self.attached)
            new_obj.coef=self.coef+other.coef
          #  print("returning ",new_obj)
            return new_obj
        return ObjSum(self,other)
    __radd__=__add__
    def __sub__(self,other):
        return self+(-1)*other
    def __mul__(self,other):
        #print("multiplying")
        
        if isinstance(other,(int,float)):
            
         #   print("attached:",self.attached)
            new_obj=self.__class__(*self.attached)
            new_obj.coef=self.coef*other
          #  print("returning ",new_obj)
            return new_obj
        return ObjMul(self,other)
    
    __rmul__=__mul__

    def __truediv__(self,other):
        print("multiplying")
        
        if isinstance(other,(int,float)):
            print("got here",self,self.__class__,self.attached,other)
         #   print("attached:",self.attached)
            new_obj=self.__class__(*self.attached)
            new_obj.coef=self.coef/other
          #  print("returning ",new_obj)
            return new_obj
        return ObjMul(self,other)
    @abstractmethod 
    def eval(self,*args,**kwargs):
        pass

    def __repr__(self):
        return (f"General object '{self.name}', attached objects:',{self.attached}), coef: {self.coef}")
    def __str__(self):
        prefix="" if self.coef==1 else str(self.coef)
        return f"{prefix}{self.name}({self.attached})"
    def __eq__(self,other):
        if other is None:
            return False
        else:
            return self.name==other.name and self.attached==other.attached

class BinOp(GeneralObject):
    @property
    def name(self):
        return "Bin. op"
    @property
    def evaluables(self):
        #return ( (int,float),(pl.Polynomial,int),(pl.Polynomial,float))
        return ( int,float,pl.Polynomial)
    @property
    def is_evaluable(self):
        return all(obj.is_evaluable for obj in self.attached)
    @abstractmethod
    def action(self,*args):
        pass
    @abstractproperty
    def symbol(self):
        return ""
    
    def __init__(self,*attached):
        super().__init__(*attached)
        self.obj1=attached[0]
        self.obj2=attached[1]

    def eval(self,*args,**kwargs): 
        obj1,obj2=self.attached
        #print("Multiplying...") 
        if isinstance(obj1,self.evaluables) and isinstance(obj2,self.evaluables):
            return self.action(obj1,obj2)
        else:
            print(obj1.eval(*args,**kwargs),"*",obj2.eval(*args,**kwargs),type(obj1.eval(*args,**kwargs)),"*",type(obj2.eval(*args,**kwargs)))
            return self.coef*self.action(obj1.eval(*args,**kwargs),obj2.eval(*args,**kwargs))
    def __str__(self):
        if self.coef==1:
            prefix,postfix="",""
        else:
            prefix=str(self.coef)+"("
            postfix=")"
        return prefix+self.symbol.join("("+str(el)+")" for el in self.attached)+postfix

class ObjSum(BinOp):
    def action(self,*args):
        #print(args[0]+args[1])
        return sum(args)
    @property
    def symbol(self):
        return "+"

class ObjMul(BinOp):
    def action(self,*args):
        print("= ",ft.reduce(mul,args),type(ft.reduce(mul,args)))
        return ft.reduce(mul,args)
    @property
    def symbol(self):
        return "*"



class Func(GeneralObject):
    
    @property
    def coef(self):
        return self._coef
    @coef.setter
    def coef(self,x):
        self._coef=x
    @property
    def evaluables(self):
        return int,float
    @property
    def is_evaluable(self):
        return all(isinstance(obj,self.evaluables) for obj in self.attached )
    @abstractproperty
    def numarg(self):
        return None

    @abstractmethod
    def func(self):
        return None
    

    def eval(self,*args,**kwargs): #nefunguje správně, co když některé argumenty budou čísla a jiná ne? Aha, možná to funguje správně

        if len(self.attached)!=self.numarg:
            raise ValueError(f"Func {self.name}  needs to take exactly {self.numarg} argument(s)!")
        else:
            if all( isinstance(obj,self.evaluables) for obj in self.attached):
              #  print("evaluable")
                return self.coef*self.func()(*self.attached)
            else:
             #   print("evaling",self.attached,kwargs)
                results=[obj.eval(*args,**kwargs) for obj in self.attached]
            #    print("results:",results)
                if all(isinstance(res,self.evaluables) for res in results):
                    return self.coef*self.func()(*(obj.eval(*args,**kwargs) for obj in self.attached))
                else:
                    
                    tr=self.__class__(*results)
                    tr.coef=self.coef
                  #  print("r,tr",results,tr)
                    return tr

    def __str__(self):
        prefix="" if self.coef==1 else str(self.coef)
        return f"{prefix}{self.name}({self.attached[0]})"

class Sin(Func):
    @property
    def name(self):
        return "sin"
    @property
    def numarg(self):
        return 1
    def func(self):
        return math.sin
    def simplify(self):
        if self.attached[0].coef==2:
            return 2*(Sin(self.attached[0]/2)*Cos(self.attached[0]/2))
        else:
            return self

class Cos(Func):
    @property
    def name(self):
        return "cos"
    
    @property
    def numarg(self):
        return 1
    def func(self):
        return math.cos
    def simplify(self):
        if self.attached[0].coef==2:
            return Cos(self.attached[0]/2)*Cos(self.attached[0]/2)-Sin(self.attached[0]/2)*Sin(self.attached[0]/2)
        else:
            return self
class extPolynomial(GeneralObject):
    @property
    def name(self):
        return "Polynomial"
    def evaluables(self):
        return int,float
    def __init__(self,*attached):
        self.attached=attached
        var,*coefs=attached
        self.pol=pl.SPolynomial(var,*coefs)
        self._coef=1
    def eval(self,*args,**kwargs):
        
        at=kwargs
        if not at:
            raise ValueError("Can't evaluate extPolynomial without evaluation points!")
        else:
            return self.coef*self.pol.at(**at)
    def __str__(self):
        prefix="" if self.coef==1 else f"{self.coef}("
        postfix="" if self.coef==1 else f")"
        return f"{prefix}{self.pol}{postfix}"

class absMonom(GeneralObject):
    @property
    def name(self):
        return "absMonom"
    def evaluables(self):
        return int,float
    def __init__(self,*attached):
        self.mcoef,*self.rest=attached
        self.objects,self.powers=zip(*self.rest)
        self.objdict={obj.name: obj for obj in self.objects}
        self.mon=pl.Monom(self.mcoef,{obj.name:power for obj,power in zip(self.objects,self.powers)})
        self._coef=1
    
    def eval(self,*args,**kwargs):
        
        at=kwargs
        if not at:
            raise ValueError("Can't evaluate eabsolynomial without evaluation points!")
        else:
            return self.coef*self.mon.at(**{name:obj[name].eval(**at) for name,obj in self.objdict.items()})
    def __str__(self):
        prefix="" if self.coef==1 else f"{self.coef}("
        postfix="" if self.coef==1 else f")"
        return f"{prefix}{self.mon}{postfix}"

class absPolynomial(GeneralObject):
    @property
    def name(self):
        return "Polynomial"
    def evaluables(self):
        return int,float
    def __init__(self,*attached):
        self.attached=attached
        self.var,self.coefs=str(attached[0]),attached[1:]
        self.pol=pl.SPolynomial(self.var,*self.coefs)
        self._coef=1
    def __pow__(self,exponent):
        np=absPolynomial(*self.attached)
        np.pol=np.pol**exponent
        return np
    def __mul__(self,other):
        np=absPolynomial(*self.attached)
        np.pol=self.pol*other.pol
        return np
    def eval(self,*args,**kwargs):
        
        at=kwargs
        if not at:
            raise ValueError("Can't evaluate eabsolynomial without evaluation points!")
        else:
            return self.coef*self.pol.at(**{self.var:self.attached[0].eval(**at)})

    def __str__(self):
        prefix="" if self.coef==1 else f"{self.coef}("
        postfix="" if self.coef==1 else f")"
        return f"{prefix}{self.pol}{postfix}"
"""
a=Sin(4).eval()
b=Sin(pl.SPolynomial("x",0,1,2))
c=Sin(1).eval()
d=ObjSum(a,b)
e=ObjSum(a,c)
print(a,b,c)
print(d,"|||",d.eval())
print(e,"|||",d.eval())
q=extPolynomial("x",1,2,3)
print(q,q.eval())
"""
"""
a=Sin()
a.attached=(4,)
#print(a.eval())
p=extPolynomial("x",0,1,2)
q=extPolynomial("y",0,1,2)
a.attached=(extPolynomial("x",0,1,2),)
#print(a,a.eval(x=4))
a=Sin(p)
b=Cos(p)
#c=extPolynomial("x",0,1,3)
d=a+b
#print("|".join(str(el) for el in (d,c,d+c,5*d)))
#h=5*c+2*d
#print(c*d)
#q=c*d
print(d,d.eval(x=3))
z=5*Sin(p)-100*Cos(q)
print(z,z.eval(y=7,x=2))
s=Sin(2*q)
#print(c,d,q)
#print(c.eval(x=3),d.eval(x=3),q.eval(x=3))
print(s," = ",s.simplify())
print(s.eval(x=1,y=4)," = ",s.simplify().eval(x=1,y=4))
w=Sin(5)
print(w,w.eval())
x=extPolynomial("x",0,1)
q=Cos(2*(Sin(5)*Sin(x)))
print(q,"=",q.simplify(),"|at x=2 =",q.eval(x=2))
q=absPolynomial(a,1,2)
print(q,"|",q**2," =|at x=1 ",(q**2).eval(x=1))
r=absPolynomial(b,1,2)
print(q*r,(q*r).eval(x=1))"""