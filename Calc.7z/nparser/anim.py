import matplotlib
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import functools as ft
import numpy as np

def par_anim(data,t0,t1,polar=False):
        if not data:
            return
     #   print("Got data:",data,t0,t1)
        if polar:
            fig=plt.figure()
            #t1=2*math.pi
            ax = fig.add_subplot(111, projection='polar')
        else:
            fig,ax=plt.subplots()
        backend = matplotlib.get_backend()
        print(backend)
        if backend=="Qt5Agg":
            mngr = plt.get_current_fig_manager()
            geom = mngr.window.geometry()
            x,y,dx,dy = geom.getRect()
            mngr.window.setGeometry(x+dx/2, y+dy/2, dx, dy)
        
        names,xdata,ydata=zip(*data)
        max_t=t1-t0
        len_t=len(xdata[0])
        dt=max_t/len_t*1000
        lines=[ax.plot([],[],label=name)[0] for name in names]
        
        #x_min,x_max=0,2*math.pi
        if polar:
             x_min,x_max=0,2*math.pi
        else:
            x_min=ft.reduce(min,[np.min(ar) for ar in xdata])
            x_max=ft.reduce(max,[np.max(ar) for ar in xdata])
        #if polar:
        #    y_min,y_max=0,2*math.pi
        #else:
        y_min=ft.reduce(min,[np.min(ar) for ar in ydata])
        y_max=ft.reduce(max,[np.max(ar) for ar in ydata])
        #print(x_maxes)
        #print(lines)
        #xlim=x_max#200
        #ylim=y_max#50
        #x_maxes=[max(ylim,x_max) for x_max in x_maxes]
        #y_maxes=[max(ylim,y_max) for y_max in y_maxes]
        #print(y_maxes)
        time_text = ax.text(.7, .8, '', fontsize=15,transform=ax.transAxes)
        global pause,direction,frame
        
        frame=0
        pause = False
        direction=1
        def init():
            #ax.clear()
            global frame
            print("launching init")
            for line in lines:
                line.set_data([],[])
            ax.set_xlim(x_min,x_max)
            ax.set_ylim(y_min,y_max)
            time_text.set_text("")
            frame=0
            fig.legend()
            return lines+[time_text]
        
        def update(_):
            #if frame==len_t-1:
            #    init()
            global frame
            print(frame)
            if frame==len_t-1:
                frame=0
            elif frame==-1:
                frame=len_t-1
            if not pause:
                frame+=direction
                
            for lind,line in enumerate(lines):    
                line.set_data(xdata[lind][:frame],ydata[lind][:frame])
               # print(max(ylim,np.max(y_maxes[frame])))
            
            time_text.set_text("t = {0:.3f}".format(t0+(frame)*dt/1000))
            #ax.set_xlim((0,x_maxes[frame])) # moving lims
            #ax.set_ylim((0,y_maxes[frame])) # moving lims
            
            return lines+[time_text]
        def onClick(event):
            global pause
            global direction 
            if event.button==1:
                pause = not pause
            elif event.button==3:
                direction=-direction
                print(direction)
        #ani= FuncAnimation(fig,update,frames=range(len_t),init_func=init,blit=True,interval=int(dt),repeat=True)
        fig.canvas.mpl_connect('button_press_event', onClick)
        #ani= FuncAnimation(fig,update,frames=range(len_t),init_func=init,blit=True,interval=1,repeat=True)
        anim=FuncAnimation(fig,update,init_func=init,blit=True,interval=1,repeat=True)

        #plt.ion()
        #plt.show()

x=("x",np.arange(1000),np.arange(1000))
y=("y",np.arange(1000),np.arange(1000))
data=[x,y]
par_anim(data,0,1000)