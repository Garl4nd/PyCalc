def FFT(a,inverse=False):
    N=len(a)
    power=math.log2(N)
    fac=-2j*np.pi
    if inverse:
        fac*=-1
    if int(power)!=power:
        raise ValueError("Vzorků musí být 2^N!")
    def _FFT(a,N):
        if N==1:
            return np.array(a[0])
        else:
           # print("N",N)
            k=np.arange(N//2)
            wNk=np.exp(fac*k/N)
            even=a[::2]#np.array([a[2*i] for i in k ])
            odd=a[1::2]#np.array([a[2*i+1] for i in k ])
         #   print(np.shape(even),np.shape(odd))
            Seven=_FFT(even,N//2)
            Sodd=_FFT(odd,N//2)
            #print("Seven",Seven,"Sodd",Sodd)
            #print("Sshapes",N//2,np.shape(even),np.shape(odd),np.shape(Seven),np.shape(Sodd))
            #input()
            return np.hstack([Seven+wNk*Sodd,Seven-wNk*Sodd])
    if inverse:
        return Vector(*_FFT(np.array(a)),N)
    else:
        return Vector(*_FFT(np.array(a),N)/N)