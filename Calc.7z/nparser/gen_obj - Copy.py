from abc import ABC,abstractmethod,abstractproperty
import itertools as it
import functools as ft
import cmath
from scipy.special import gamma as cgamma
import unicodedata
from operator import mul,add,pow
module_prefix="" #module_prefix=module_prefix_optinos["direct"]  to make eval the inverse of repr
# TODO: komplexní koeficienty u monomů (místo genobj...) -> obecněji to mohou být obecné koeficienty (z GeneralObject)
# TODO: Řešení rovnic v závislosti na parametru - bylo by nějak těžké přesunout členy monomu ze slovníku do koeficientu? 
#       Nemělo by být, problém je v tom, že násobení a sčítání je definované přes monomy, takže by se to (asi) muselo ošetřit.
# TODO: Grafy ve více proměnných  -done
# TODO: Opravit indexy v Draw_Parse_Tree
# TODO: Opravit celý Draw_Parse_Tree - hlavně případ kolize unárních a binárních operátorů (je třeba tam udělat víc místa, např 2-#4)
# TODO: soustavy rovnic (nelineární asi dosazovací metodou?)
# TODO: řešení obecných rovnic aproximativními metodami
# TODO: krácení polynomů ve více proměnných
# TODO: Ten __getitem__ se mi moc nelíbí, např. teď máme víc způsobů jak získat real a imag z komplexního čísla. Plus tam teď máme derivování. Aby to bylo čistší, tak by se mohlo přesunout z getitem do funkce v regparseru
import math
#import genpolynom
class GeneralObject(ABC):
    @abstractproperty
    def name(self):
        pass
    @abstractproperty
    def evaluables(self):
        return int,float
    @abstractproperty
    def is_evaluable(self):
        return False
    

    def __init__(self,*attached_objs: "GeneralObject"):
        self.attached=attached_objs
        #print(self.attached)
        
        super().__init__()

    def __add__(self,other):
        
        #print("adding")
        if isinstance(other,(Monom,Polynomial,Quotient)):
            return  other+Monom(self)
        elif isinstance(other,Complex):
                return Complex(self+other.real,other.imag)
        elif isinstance(other,Vector):
            return Vector(*(self+comp for comp in other.values))
        else:
            #print([(str(el),repr(el)) for el in (Monom(self),Monom(other))])
            return Monom(self)+Monom(other)
        if self==other:
         #   #print("attached:",self.attached)
            new_obj=self.__class__(*self.attached)
            
          #  #print("returning ",new_obj)
            return new_obj
        return ObjSum(self,other)
    __radd__=__add__
    def __sub__(self,other): 
        #print("subing",self,other)
        return self+(-1)*other
    def __rsub__(self,other):
        return -(self-other)
    def __mul__(self,other):
        #print("str",self,other,type(self),type(other),isinstance(self,GeneralObject),isinstance(other,GeneralObject))
        #import genpolynom
        #if isinstance(other,(int,float)):
        #    return other*Monom(self)
        if isinstance(other,(int,float,Monom,Polynomial,Quotient)):
            #print("here",other,type(other))
            return other*Monom(self)
        if isinstance(other,Complex):
            return Complex(self*other.real,self*other.imag)
        if isinstance(other,Vector):
            return Vector(*(self*comp for comp in other))
        if isinstance(other,GeneralObject):
            return Monom(self)*Monom(other)
            
        return ObjMul(self,other)
    
    __rmul__=__mul__
    def __pow__(self,exponent):
        if isinstance(exponent,(int,float)):
            return Monom(self)**exponent
        else:
            return ObjPow(self,exponent)
    def __rpow__(self,base):
        return ObjPow(base,self)
    def __truediv__(self,other):
        if isinstance(other,Complex):
            return self*(1/other)
        if isinstance(other,Vector):
            return Vector(*(self/comp  for comp in other.values))

        return Polynomial(self)/other
    def __rtruediv__(self,other):
        if self==0:
            raise ValueError("Can't divide by zero!")
        else:
            
            return other/Monom(self)
    def __neg__(self):
        return (-1)*self
    @abstractmethod 
    def eval(self,*args,**kwargs):
        pass
    def get_vars(self):
        vars=set()
        for arg in self.attached:
            #print(self,arg,type(arg))
            if isinstance(arg,GeneralObject):
                
                vars.update(arg.get_vars())
        return vars
        
    def contains_complex(self):
        for arg in self.attached:
            #print(self,arg,type(arg))
            if isinstance(arg,GeneralObject):
                if arg.contains_complex():
                    return True
        return False
    def deriv(self,dervar):
        pass
    def grad(self):
        vars=list(sorted(self.get_vars()))
        if vars:
            return Vector(*(self.deriv(var) for var in vars))
        else:
            return Monom(0)
    def laplace(self):
        return self.grad().divergence()
    def simplify(self):
        return self
    def __repr__(self):
        return (f"General object '{self.name}', attached objects:',{self.attached})")
    def __str__(self):
        return f"{self.name}({self.attached})"
    def __eq__(self,other):
        if not isinstance(other,GeneralObject):
            return False
        else:
            if isinstance(other,Complex) and other.isreal():
                return self==other.real
            else:
                return self.name==other.name and self.attached==other.attached

    def __getitem__(self,sl):
        if isinstance(sl,int):
            try:
                return self.attached[sl-1]
            except IndexError:
                if type(self) is Vector:
                    raise ValueError(f"The vector doesn't have a component with index {sl-1}!")
                elif type(self) is Complex:
                    raise ValueError(f"The complex number doesn't have a component with index {sl-1}!")
                else:
                    raise ValueError(f"The expression {self} doesn't have an argument with index {sl-1}!")
        if isinstance(sl,Vector):
            try: 
                if all(isinstance(comp,Variable) for comp in sl):
                    return ft.reduce(lambda x,y: x.deriv(y),sl,self)
                print("vec:",sl)
                sl=slice(*sl)
                print("slice:",sl)
                return Vector(*self.attached[slice(sl.start-1 if not (sl.start is  None or sl.start==0) else None,sl.stop  if not (sl.stop is None or sl.stop==0) else None,sl.step)])
            except (AttributeError,TypeError) as e:
                raise ValueError(f"The indices must either all be integers or all be variables ! |{e}")
        elif isinstance(sl,Variable):
            return self.deriv(sl)
        elif isinstance(sl,slice):
            return Vector(*self.attached[slice(sl.start-1 if not (sl.start is  None or sl.start==0) else None,sl.stop  if not (sl.stop is None or sl.stop==0) else None,sl.step)])
        else:
            raise ValueError("The index must either be an integer or a variable or a vector of integers or a vector of variables")
    #def __iter__(self):
    #    raise TypeError(f"The object {self.__class__} is not iterable")
    def __hash__(self): 
        return hash(repr(self))


class Variable(GeneralObject):
    @property
    def name(self):
        return "Variable"
    @property 
    def evaluables(self):
        return (int,float)
    @property
    def is_evaluable(self):
        return all(obj.is_evaluable for obj in self.attached)
    def __init__(self,varname):
        self.attached=varname
        self.varname=varname
    def eval(self,*args,**kwargs):
        for name,value in kwargs.items():
            if name==self.varname:
                return value
        return self
    def deriv(self,var):
        if var==self.varname or var==self:
            return Monom(1) #1
        else:
            return Monom(0) #0
    def __repr__(self):
        return self.varname+" [Variable] "
    def __str__(self):
        
        return self.varname
    def get_vars(self):
        #print("vr",self.varname)
        return {self.varname}

class PrettyVariable(Variable):
    def __init__(self,varname):
        super().__init__(self.pretty(varname))
    @staticmethod
    def pretty(varname):
        if varname:
            try:
                
                if varname[0].islower():
                    return unicodedata.lookup(f"Greek small letter {varname}")
                if varname[0].isupper():
                    return unicodedata.lookup(f"Greek Capital letter {varname}")
                else:
                    return varname 
            except KeyError:
                try:
                    return unicodedata.lookup(f"Hebrew letter {varname}")
                except KeyError:
                    return varname
        else:
            raise ValueError("The variable must have a name!")
            
class BinOp(GeneralObject):
    @property
    def name(self):
        return "Bin. op"
    @property
    def evaluables(self):
        #return ( (int,float),(pl.Polynomial,int),(pl.Polynomial,float))
        return ( int,float,Polynomial)
    @property
    def is_evaluable(self):
        return all(obj.is_evaluable for obj in self.attached)
    @abstractmethod
    def action(self,*args):
        pass
    @abstractproperty
    def symbol(self):
        return ""
    
    def __init__(self,*attached):
        super().__init__(*attached)
        self.obj1=attached[0]
        self.obj2=attached[1]

    def eval(self,*args,**kwargs): 
        obj1,obj2=(obj.eval(*args,**kwargs) if isinstance(obj,GeneralObject) else obj for obj in self.attached)
        #print("Multiplying...") 
        if isinstance(obj1,self.evaluables) and isinstance(obj2,self.evaluables):
            return self.action(obj1,obj2)
        else:
            #print(obj1.eval(*args,**kwargs),"*",obj2.eval(*args,**kwargs),type(obj1.eval(*args,**kwargs)),"*",type(obj2.eval(*args,**kwargs)))
            
            return self.action(obj1,obj2)
    def __str__(self):
        return self.symbol.join("("+str(el)+")" for el in self.attached)

class ObjSum(BinOp):
    @property
    def name(self):
        return "ObjSum"
    def action(self,*args):
        #print(args[0]+args[1])
        return sum(args)
    @property
    def symbol(self):
        return "+"
    def deriv(self,dervar):
        xder,yder=(obj.deriv(dervar) if isinstance(obj,GeneralObject) else Monom(0) for obj in self.attached)
        return xder+yder
class ObjMul(BinOp):
    @property
    def name(self):
        return "ObjMul"
    def action(self,*args):
        
        return ft.reduce(mul,args)
    @property
    def symbol(self):
        return "*"
    def deriv(self,dervar):
        x,y=self.attached
        xder,yder=(obj.deriv(dervar) if isinstance(obj,GeneralObject) else Monom(0) for obj in (x,y))
        return xder*y+x*yder

class ObjPow(BinOp):
    @property
    def name(self):
        return "ObjPow"
    def action(self,*args):
        return ft.reduce(pow,args)
    @property
    def symbol(self):
        return "^"
    def deriv(self,dervar):
        x,y=self.attached
        xder,yder=(obj.deriv(dervar) if isinstance(obj,GeneralObject) else Monom(0) for obj in (x,y))
        return Ln(x)*ObjPow(x,y)*yder+y*ObjPow(x,y-1)*xder

class Func(GeneralObject):
    
    
    @property
    def evaluables(self):
        return int,float
    @property
    def is_evaluable(self):
        return all(isinstance(obj,self.evaluables) for obj in self.attached )
    @abstractproperty
    def numarg(self):
        return None

    @abstractproperty
    def func(self):
        return (lambda : None)
    @abstractproperty
    def inverse(self):
        return type(None)

    def eval(self,*args,**kwargs): #nefunguje správně, co když některé argumenty budou čísla a jiná ne? Aha, možná to funguje správně
        #print(self.attached)
        if len(self.attached)!=self.numarg:
            raise ValueError(f"Func {self.name}  needs to take exactly {self.numarg} argument(s)!")
        else:
            #if False:# all(isinstance(obj,self.evaluables) for obj in self.attached):
            #    return self.func(*self.attached)
            #else:
            #vsechny komentare
            if Vector not in self.evaluables and type(self.attached[0]) is Vector:
                return Vector(*(self.__class__(comp).eval(*args,**kwargs) for comp in self.attached[0]))
            results=[obj.eval(*args,**kwargs) if isinstance(obj,GeneralObject) else obj for obj in self.attached]
            if all(isinstance(res,self.evaluables) for res in results):
                return self.func(*(results))
            else:
            #    tr=self.__class__(*results)
                return self.__class__(*results)
    @classmethod
    def complexification(cls,realfunc,complfunc):
        def compeval(z):
            if isinstance(z,Complex):
                if isinstance(z.real,(int,float)) and isinstance(z.imag,(int,float)):
                    res=complfunc(z.real+1j*z.imag)
                    return Complex(res.real,res.imag)
                else:
                    return cls(z)
            else:    
                return realfunc(z)
        return compeval
            

    def __str__(self):
        s=",".join(str(arg) for arg in self.attached)
        return f"{self.name}({s})"

class Exp(Func):
    @property
    def name(self):
        return "exp"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Ln
    @property
    def func(self):
        return self.complexification(math.exp,cmath.exp)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,Polynomial):
            return product((Exp(mon) if mon.coef>=0 else 1/Exp(-mon)  for mon in arg.monlist))
        elif isinstance(z,Complex):
            if z.isimag():
                return Complex(Cos(z.imag),Sin(z.imag)).eval()
            else:
                return (Exp(z.real)*Complex(Cos(z.imag),Sin(z.imag))).eval()
        return self
    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return self*(self.attached[0]).deriv(dervar)

class Ln(Func):
    @property
    def name(self):
        return "ln"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Exp
    @property
    def func(self):
        f=self.complexification(math.log,cmath.log)
        def corlog(z):
            try:
                return f(z)
            except ValueError:
                raise ZeroDivisionError(
            "Can't define take logarithm of a non-positive number. For non-zero numbers, change to complex arguments (x->x+0i). ")
        return corlog
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):
            
            return arg.attached[0]
        if isinstance(arg,Monom):
            return Polynomial((order*Ln(obj)  for (obj,order) in arg.vars))
        elif isinstance(z,Complex):
            if z.isimag():
                try:
                    if z.imag>0:
                        return Complex(math.log(z.imag),math.pi/2)
                    else:
                        return Complex(math.log(-z.imag),-math.pi/2)
                except (TypeError,ValueError):
                    return Complex(Ln(z.norm()),z.angle()).eval()
            else:
                return Complex(Ln(z.norm()),z.angle()).eval()
        else:
            return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/self.attached[0]*(self.attached[0]).deriv(dervar) 


class Log(Func):
    @property
    def name(self):
        return "log"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return type(None)
    @property
    def func(self):
        f=self.complexification(math.log10,cmath.log10)
        def corlog(z):
            try:
                return f(z)
            except ValueError:
                raise ZeroDivisionError(
            "Can't define take logarithm of a non-positive number. For non-zero numbers, change to complex arguments (x->x+0i). ")
        return corlog
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):
            
            return arg.attached[0]
        if isinstance(arg,Monom):
            return Polynomial((order*Ln(obj)  for (obj,order) in arg.vars))
        elif isinstance(z,Complex):
            if z.isimag():
                try:
                    if z.imag>0:
                        return Complex(math.log10(z.imag),math.pi/2)
                    else:
                        return Complex(math.log10(-z.imag),-math.pi/2)
                except (TypeError,ValueError):
                    return Complex(Log(z.norm()),z.angle()).eval()
            else:
                return Complex(Log(z.norm()),z.angle()).eval()
        else:
            return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/self.attached[0]*math.log10(math.e)*(self.attached[0]).deriv(dervar) 
#New code ↓
class Sinh(Func):
    @property
    def name(self):
        return "sinh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Asinh
    @property
    def func(self):
        return self.complexification(math.sinh,cmath.sinh)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return 2*(Sinh(arg/2)*Cosh(arg/2))
        elif isinstance(z,Complex):
            if z.isimag():
                return Complex(0,Sin(z.imag)).eval()
            else:
                return Complex(Sinh(z.real)*Cos(z.imag),Cosh(z.real)*Sin(z.imag)).eval()
        else:
            return self
    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return Cosh(self.attached[0])*(self.attached[0]).deriv(dervar)

class Asinh(Func):
    @property
    def name(self):
        return "asinh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Sinh
    @property
    def func(self):
            return self.complexification(math.asinh,cmath.asinh)
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(z,Complex):
            return  Ln(z+Sqrt(z**2+1)).eval()
        else:
            return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/Sqrt(1+self.attached[0]**2)*self.attached[0].deriv(dervar)
class Cosh(Func):
    @property
    def name(self):
        return "cosh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Acosh
    @property
    def func(self):
        return self.complexification(math.cosh,cmath.cosh)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return Cos(arg/2)**2+Sin(arg/2)**2
        elif isinstance(z,Complex):
            if z.isimag():
                return Complex(Cos(z.imag),0).eval()
            else:
                return Complex(Cosh(z.real)*Cos(z.imag),Sinh(z.real)*Sin(z.imag)).eval()
        else:
            return self

    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return Sinh(self.attached[0])*(self.attached[0]).deriv(dervar)
class Acosh(Func):
    @property
    def name(self):
        return "acosh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Cosh
    
    @property
    def func(self):
        return self.complexification(math.acosh,cmath.acosh)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,Complex):
            return Ln(z+Sqrt(z**2-1)).eval()
        return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/Sqrt(-1+self.attached[0]**2)*self.attached[0].deriv(dervar)
#New code ↑
class Gamma(Func):
    @property
    def name(self):
        return "Gamma"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return type(None)
    @property
    def func(self):
        ggamma=self.complexification(math.gamma,cgamma)
        def ext_func(z):
            try:
                
                return ggamma(z)
            except ValueError:
                raise ZeroDivisionError("The gamma function is undefined for negative integers!")
          #  try:
          #      return math.factorial(x)
          #  except ValueError:
          #      return ggamma(x+1)
        return ext_func

    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):            
            return arg.attached[0]

        return self
    def deriv(self,dervar):
        raise NotImplementedError("The derivative of factorial/Gamma function is not implemented yet")
    def __str__(self):
        return "("+str(self.attached[0])+")!"

class OldAbs(Func):
    @property
    def name(self):
        return "abs"
    @property
    def numarg(self):
        return 1
    @property 
    def inverse(self):
        return type(None)
    @property
    def func(self):
        return abs
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):
            
            return arg.attached[0]
        
        return self
    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return (self.attached[0])/Abs(self.attached[0])*(self.attached[0]).deriv(dervar)
class Sqrt(Func):
    @property
    def name(self):
        return "sqrt"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return type(None)
    @property
    def func(self):
        return self.complexification(math.sqrt,cmath.sqrt)
        
        
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):    
            return arg.attached[0]
        
        if isinstance(z,Complex):
            return (z**(1/2)).eval()
        elif isinstance(z,(int,float)) and z<0:
            return Complex(0,math.sqrt(-z))
        else:
            return self

    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 0.5*1/Sqrt(self.attached[0])*(self.attached[0]).deriv(dervar)
    def __str__(self):
        return "√("+str(self.attached[0])+")"
class Sin(Func):
    @property
    def name(self):
        return "sin"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Asin
#newcode ↓
    @property
    def func(self):
        return self.complexification(math.sin,cmath.sin)
        
#newcode ↑
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,Acos):
            return Sqrt(1-arg.attached[0]**2)
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return 2*(Sin(arg/2)*Cos(arg/2))
        if isinstance(z,Complex):
            if z.isimag():
                return Complex(0,Sinh(z.imag)).eval()
            else:
                return Complex(Sin(z.real)*Cosh(z.imag),Cos(z.real)*Sinh(z.imag)).eval()
        else:
            return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        #print("Sin:",type(Cos(self.attached[0])),type(self.attached[0].deriv(dervar)))
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return Cos(self.attached[0])*self.attached[0].deriv(dervar)

class Asin(Func):
    @property
    def name(self):
        return "asin"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Sin
    @property
    def func(self):
        return self.complexification(math.asin,cmath.asin)
    def simplify(self):
        arg=self.attached[0]
        
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        else:
            return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/Sqrt(1-self.attached[0]**2)*self.attached[0].deriv(dervar)
class Cos(Func):
    @property
    def name(self):
        return "cos"
    
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Acos
#newcode ↓
    @property
    def func(self):
        return self.complexification(math.cos,math.acos)
#newcode ↑
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,Asin):
            return Sqrt(1-arg.attached[0]**2)
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
            return Cos(arg/2)**2-Sin(arg/2)**2
        elif isinstance(z,Complex):
            if z.isimag():
                return Complex(Cosh(z.imag),0).eval()
            else:
                return Complex(Cos(z.real)*Cosh(z.imag),-Sin(z.real)*Sinh(z.imag)).eval()
        else:
            return self
    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return -Sin(*self.attached)*self.attached[0].deriv(dervar)

class Acos(Func):
    @property
    def name(self):
        return "acos"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Cos
    @property
    def func(self):
        return self.complexification(math.acos,cmath.acos)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        return self
    def deriv(self,dervar):
        #print(self,self.attached[0])
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return -1/Sqrt(1-self.attached[0]**2)*self.attached[0].deriv(dervar)

class Tan(Func):
    @property
    def name(self):
        return "tan"
    
    @property
    def numarg(self):
        return 1
    @property 
    def inverse(self):
        return Atan
    @property
    def evaluables(self):
        return int,float,Complex
    @property
    def func(self):
        f=self.complexification(math.tan,cmath.tan)
        def cortan(z):
            try:
                return f(z)
            except ValueError:
                raise ZeroDivisionError

        return cortan
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return 2*Tan(arg/2)/(1-Tan(arg/2))#**2)
        else:
            return self
    def deriv(self,dervar):
        arg=self.attached[0]
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return -1/Cos(arg)**2*arg.deriv(dervar)

class Atan(Func):
    @property
    def name(self):
        return "atan"
    
    @property
    def numarg(self):
        return 1
    @property 
    def inverse(self):
        return Tan
    @property
    def evaluables(self):
        return int,float,Complex
    @property
    def func(self):
        return self.complexification(math.atan,cmath.atan)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]

        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return 2*Tan(arg/2)/(1-Tan(arg/2))#**2)
        else:
            return self
    def deriv(self,dervar):
        arg=self.attached[0]
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/(arg**2+1)*arg.deriv(dervar)
class Tanh(Func):
    @property
    def name(self):
        return "tanh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Atanh
    @property
    def func(self):
        return self.complexification(math.tanh,cmath.tanh)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        
        
        return Sinh(z)/Cosh(z)
        #return self

    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return (1-Tanh(self.attached[0])**2)*(self.attached[0]).deriv(dervar)
class Atanh(Func):
    @property
    def name(self):
        return "atanh"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property 
    def inverse(self):
        return Tanh
    @property
    def func(self):
        return self.complexification(math.atanh,cmath.atanh)
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        return 0.5*Ln( (1+self.attached[0])/(1-self.attached[0]))
        #return self

    def deriv(self,dervar):
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/(1-self.attached[0]**2)*(self.attached[0]).deriv(dervar)
class Choose(Func):
    @property 
    def name(self):
        return "choose"
    
    @property
    def numarg(self):
        return 2
    @property 
    def inverse(self):
        return type(None)
    @property
    def func(self):
        def choose(a1,a2):
            try:
                return (Gamma(a1+1)/(Gamma(a2+1)*Gamma(a1-a2+1))).eval()
            except ZeroDivisionError:
                raise ZeroDivisionError("Can't evalute choose(n,m) for n,m integers and n<m.")
        return choose
    def simplify(self):
        arg=self.attached[0]
        if isinstance(arg,self.inverse):
            return arg.attached[0]
        if isinstance(arg,(Monom,Polynomial)) and arg.coef%2==0:
                return 2*Tan(arg/2)/(1-Tan(arg/2))#**2)
        else:
            return self
    def deriv(self,dervar):
        arg=self.attached[0]
        if isinstance(self.attached[0],(int,float)):
            return 0
        else:
            return 1/(arg**2+1)*arg.deriv(dervar)


def product(args): 
    
    return ft.reduce(mul,args,1)

def truncate_number(num,sig_nums=3):
    """Prevede cela cisla sama na sebe a desetinna cisla na cisla s desetinnou casti na sig_nums vyznamnych cislic"""
    inum=int(num)
    if inum==num: 
        return str(inum)
    else:
        base,decpart="{:.15f}".format(num).split(".")
        sig=decpart.strip("0")
        ind=decpart.find(sig)
        rounded=round(int(decpart[:ind+sig_nums+1]),-1)
        if rounded==10**(sig_nums+1):
            res=round(num,ind)
            ires=int(res)
            if ires==res: 
                return str(ires)
            else:
                return res
        decimal=str(rounded).rstrip("0")
        #print(base,decpart,sig,int(decpart[:ind+sig_nums+1]),decimal,round(int(decpart[:ind+sig_nums+1]),-1))    
        
        return (base+"."+"0"*ind+decimal).rstrip(".")

def to_sigfigs(num,sig_nums=3): #  Vyznamne cislice s hezci vedeckou notaci
    import re
    s="{:.{sign}g}".format(num,sign=sig_nums)
    s=re.sub("e[\+\-](\d+)",lambda k: f"^{k[1]}",s)
    return s

def make_whole(x,y):
    #print("make whole:",x,y)
    orx,ory=x,y
    if x==0:
        return 0,y
    rx,ry=1/x,1/y
    if int(rx)==rx:
        p=x*y
        if int(p)==p:
            return 1,p
        if int(ry)==ry:
            return ry,rx
    if int(ry)==ry:
        p=x*y
        if int(p)==p:
            return p,1

    #if abs(x)<abs(y):
    #    x,y=1/y,1/x
    for _ in range(5):
        if int(x)==x and int(y)==y:
            x,y=int(x),int(y)
            #print("looping",x,y)
            break
        x,y=x*10,y*10
    else:
        

        return orx,ory    
    #print("Returning",x,y)
    return x,y
    
class Monom(GeneralObject):
    @property
    def name(self):
        return "Monom"
    @property
    def evaluables(self):
        return int,float
    @property 
    def is_evaluable(self):
        return self.isconst
    def __init__(self,coef: float=0,vars :dict={}):

        self.isconst=True
        #print("Building Monom",coef,vars)
        if not vars:
            if isinstance(coef,Monom):
                coef,vars=coef.coef,coef.vars 
            elif isinstance(coef,GeneralObject):
                vars={repr(coef):(coef,1)}
                coef=1
            
        if coef==0:
            self.coef=0
            self.vars={}
            self.order=0
            self.varset=set()

        else:
            icoef=int(coef)
            if icoef==coef:
                coef=icoef
            self.vars={}
            
            for name,obj_info in vars.items():
                if isinstance(obj_info,tuple):
                    #print("obj_info:",obj_info)
                    obj,order=obj_info
                else:
                    #obj,order=None,obj_info
                    obj,order=Variable(name),obj_info
                if order!=0:
                    self.vars[name]=(obj,order)
                    self.isconst=False
            self.coef=coef
            self.vars=dict(sorted(self.vars.items(),key=lambda item:ord(str(item[1][0])[0])-(100000 if isinstance(item[1][0],(Variable,Monom,Polynomial)) else 0)))
            self.order=sum(order for _,order in self.vars.values())
            self.varset={*self.vars.keys()}
        self.attached=[obj for obj,_ in self.vars.values()] 
         #   #print("From Monom:",coef,self.varset,self.order,self.isconst)
    
    def eval(self,*args,**kwargs)->float or int: #Povinna funkce, diky ktere Monom bude hrdou podtridou abstraktni tridy "Obecny vyraz" 
        res=self.coef
        
        for (obj,power) in self.vars.values():
        
            res*=obj.eval(**kwargs)**power#**power

        #print("returning Monom with coef,new_vars:",coef,new_vars)
        return res
     
        

    def at(self,**vals):
        new_coef=self.coef
        new_vars={**self.vars}
        for var,value in vals.items():
            if var in self.vars:
                new_coef*=value**self.vars[var][1]
                del new_vars[var]
        return Monom(new_coef,new_vars)
        
    def issame(self,other):
        return self.vars==other.vars
    
    def inv(self):
        try:
            return Monom(1/self.coef if 1%self.coef else 1//self.coef,{
                var:-coef for var,coef in self.vars.items()})
        except ZeroDivisionError:
            #print("Deleni nulou!")
            raise
    def simplify(self):
        new_vars={}
        res=1
        for key,(obj,order) in self.vars.items():
            if isinstance(obj,Sqrt) and order%2==0:
                res*=obj.attached[0]**(order//2) #chybi simplify
            elif isinstance(obj,ObjPow) and order==1/obj.attached[1]:
                res*=obj.attached[0] #chybi simplify
            else:
                    new_vars[key]=(obj,order)
        return Monom(self.coef,{var:(obj.simplify(),order) for var,(obj,order) in new_vars.items()})*res
    def __add__(self,other):
        if not isinstance(other,Monom):
            if isinstance(other,(Polynomial,Quotient)):
                return other+self
            if type(other) in [int,float]:
                other=Monom(other,{})

            elif isinstance(other,Complex):
                return Complex(self+other.real,other.imag)
            elif isinstance(other,Vector):
                return Vector(*(self+comp for comp in other.values))
            elif isinstance(other,GeneralObject):
                other=Monom(other)

        if self.issame(other):
            return Polynomial([Monom(self.coef+other.coef,self.vars)])
        else:
            return Polynomial([self,other])
            #raise ValueError("Can't add different monomials in Monom!")
    
    __radd__=__add__

    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return other+(-self)

    def monaddition(self,other):
        if self.issame(other):
            return Monom(self.coef+other.coef,self.vars)
        else:
            raise ValueError("Monomy musi byt stejneho typu!")

    def __mul__(self,other):
        #print("Multiplying",self,other)
        #print(type(other))
        if not isinstance(other,Monom):
            if isinstance(other,Variable):
                #updict={var:(obj,order+1 if other==obj else order) for var,(obj,order) in self.vars.items() }                
                #return Monom(self.coef,{var:(obj,order+1 if other==obj else order) for var,(obj,order) in self.vars.items() })
                return self*Monom(other)
            if isinstance(other,(Polynomial,Quotient)):
                return other*self
            if isinstance(other,(int,float)):
                coef=self.coef*other
                return Monom(coef,self.vars)
            if isinstance(other,Complex):
                return Complex(self*other.real,self*other.imag)
            if isinstance(other,(GeneralObject)):
                other=Monom(other)
        
        nv={**self.vars,**other.vars}
        nc=self.coef*other.coef
        if nc==0: 
            return Monom(0,{})
        else:
            for var1,(obj1,order1) in self.vars.items():
                for var2,(obj2,order2) in other.vars.items():
                    if var1==var2:
                        if obj1==obj2:
                            nv[var1]=(obj1,order1+order2)
                    #if var1=="const":
                    #   nv[var2]=order2
        res=Monom(nc,nv)
        #print("returning",res)
        return res
    def __hash__(self):
        return hash(repr(self))
    __rmul__=__mul__

    def __truediv__(self,other):
        if isinstance(other, (int,float)):
           return Monom(self.coef/other if self.coef%other else self.coef//other,self.vars)
        return Polynomial(self)/other
    def __rtruediv__(self,other):
        return Quotient(other,self)
    def __neg__(self):
        return Monom(-self.coef,self.vars)

    def __pow__(self,exponent):
        if type(exponent)!=int:
            return ObjPow(self,exponent)
            #raise TypeError("Exponent musi byt cele cislo!")
        if exponent>0:
            return Monom(self.coef**exponent,{var:(obj,order*exponent) for var,(obj,order) in self.vars.items()})            
        elif exponent<0:
            return Quotient(1,self**(-exponent))
        else:
            return Monom(1)

        #return ft.reduce(mul,(self for _ in range(exponent)),Monom(1,{}))
    #def deriv(self,var):
    #    return Polynomial(self).deriv(var)
    def deriv(self,dervar):
        res=0 #Monom(self.coef)
        for var,(obj,order) in self.vars.items():
            #print("res a",res,self)
            rest=Monom(self.coef,{nvar:res for nvar,res in self.vars.items() if nvar!=var})
            
            
            dinner=obj.deriv(dervar)
            if order-1!=0:
                #print("douter",var,order)
                douter=Monom(order,{var:(obj,order-1)})
            else:
                douter=order
            #print(obj,"...",douter,dinner,rest)
            res+=douter*dinner*rest
        #print("res",res)
        #print("rt",res,type(res),new_coef,type(new_coef))
        #print("type",type(self.coef*res),str(self.coef*res))
        return res
            
    def divgrad(self):
        return Polynomial(self).divgrad()

    def __eq__(self,other):
        #print(self,other,repr(self),repr(other))
        if isinstance(other,(float,int)):
            if self.isconst: 
                return self.coef==other
            else:
                return False
        if isinstance(other,Complex) and other.isreal():
                return self==other.real
        if isinstance(other,Monom):
            return self.coef==other.coef and self.vars==other.vars
        if isinstance(other,(Polynomial,Quotient)):
            return other.__eq__(self)
        return super().__eq__(other)
    
    def __repr__(self):
        #return f"{module_prefix}Monom({self.coef!r},{self.vars!r})"
        #return f"{module_prefix}M({self.coef!r},{self.vars!r})"
        return f"{module_prefix}M({self.coef!r},{dict((key,order) for key,(_,order) in self.vars.items())!r})"
        #self.vars=(("x",1),("y",5))
    def __int__(self):
        if self.isconst:
            return int(self.coef)
        else:
            raise ValueError("Can't convert a non-constant monomial to int")
    def __float__(self):
        if self.isconst:
            return float(self.coef)
        else:
            raise ValueError("Can't convert a non-constant monomial to float")
    @classmethod
    def fromrepr(cls,text):
        if not text.startswith("M("):
            raise ValueError("Wrong format! The string must start with \"M(\" ")
        else:
            
            return eval("Monom("+text[2:])
        
    def __str__(self):
        s=""
        if self.isconst:
            return truncate_number(self.coef)
        else:
            if self.coef>=0:
                pref=""
            else:
                pref="-"
            #print("#printing self...",*(str(key)+":"+str(obj)+"..."+str(order) for key,(obj,order) in self.vars.items()))
            s+=f"{pref}{truncate_number(abs(self.coef)) if abs(self.coef)!=1 else ''}"
            for _,(obj,order) in self.vars.items():
                    s+=str(obj)
                    if order!=1:
                        if order>0:
                            s+=f"^{order}"
                        else:
                            s+=f"^({order})"
        
            return(s)
        
            

class Polynomial(GeneralObject):
    @property
    def name(self):
        return "Polynomial"
    @property
    def evaluables(self):
        return int,float
    @property
    def is_evaluable(self):
        return all(mon.is_evaluable for mon in self.monlist)

    def __init__(self,monlist):
        
        nl=[]
        if isinstance(monlist,Polynomial):
            monlist=monlist.monlist
        try:
            iter(monlist)
            if isinstance(monlist,Complex):
                
                if monlist.isreal():
                    monlist=[monlist.real]
                elif monlist.isimag():
                    monlist=[Complex(0,1)*monlist.imag]
                else:
                    monlist=[monlist]
                #print("monlist:",monlist)
            elif isinstance(monlist,Vector):
                monlist=[monlist]
        except TypeError:
            if isinstance(monlist,Polynomial):
                monlist=monlist.monlist
            elif isinstance(monlist,Quotient):
                if monlist.q.isconst:
                    const=(monlist.q.monlist)[0].coef
                    monlist=[mon/const for mon in monlist.p.monlist]

                else:
                    raise ValueError("Can't convert quotient with non-constant denominator to a polynomial!")
            else:
                
                monlist=[monlist]
        print([mon for mon in monlist])
        monlist=list(monlist)
        for mon in monlist:
            if not isinstance(mon,Monom):
                mon=Monom(mon)
            same=False
            
            for ind,savedmon in enumerate(list(nl)):
                if mon.issame(savedmon):
                    
                    same=True
                    res=mon.monaddition(nl[ind])
                    
                    if res==0:
                        del nl[ind]
                    else:
                        nl[ind]=res
            if not same:
                if mon!=0:
                    nl.append(mon)
        
        self.monlist=sorted(nl,key=self.msum)
        if not self.monlist:
            self.monlist.append(Monom(0,{}))
        
        self.order=max(mon.order for mon in self.monlist)
        self.varset={var for mon in self.monlist for var in mon.vars.keys()}
        self.isconst=all(mon.isconst for mon in self.monlist) 
        self.attached=self.monlist
        self.obj_dict={}
        for var in self.varset:
            #print("var:",var)
            for mon in self.monlist:
                #print("mon:",mon)
                if var in mon.vars:
                    self.obj_dict[var]=mon.vars[var][0]
                    break
    def eval(self,*args,**kwargs):
        if len(self.varset)!=1:
            return sum(mon.eval(*args,**kwargs) for mon in self.monlist)
        else:
            return self.horneval(*args,**kwargs)

    def horneval(self,*args,**kwargs): #Horner's scheme
        var=next(iter(self.varset))
        for mon in self.monlist:
            if not mon.isconst:
                val=mon.vars[var][0].eval(*args,**kwargs)
                break
        
        an=self.get_coefs(var)
        res=an[-1]
        for ai in reversed(an[:-1]):
            res=res*val+ai
        return res

    def simplify(self):
        return sum(mon.simplify() for mon in self.monlist)
    def factor_variables(self):
        #print("Factoring")
        d=self.monlist[0].coef
        #print(self.varset)
        if self==0:
            return (Monom(0),Polynomial(0))
        for mon in self.monlist[1:]:
            d=gcd(d,mon.coef)
        
        pref_vars={var:(self.obj_dict[var],min(mon.vars.get(var,(0,0))[1] for mon in self.monlist)) for var in self.varset}
        prefactor=Monom(d,pref_vars)
        new_coefs=(mon.coef//d  if d!=1 else mon.coef for mon in self.monlist)
        new_vars=({var:(obj,order-pref_vars[var][1]) for var,(obj,order) in mon.vars.items() if order-pref_vars[var][1]!=0}  for mon in self.monlist)
        rest=Polynomial(Monom(coef,var) for coef,var in zip(new_coefs,new_vars))

        #print("Returning from factor","|".join(str(el) for el in (prefactor,rest,prefactor.coef,prefactor.isconst)))
        return (prefactor,rest)
   
    @classmethod
    def convert(cls,obj):
        if isinstance(obj,Polynomial):
            return obj
        if isinstance(obj,(float,int)):
            #print(obj)
            return SPolynomial("",obj)
        elif isinstance(obj,Monom):
                return Polynomial([obj])
        else:
            raise ValueError(f"Can't convert object {obj} with type {type(obj)} to Polynomial")
    def msum(self,mon):
    
    #print(arglist,len(arglist))
 
        return -(mon.order*100000-len(mon.vars)*1000-0.01*sum(ord(str(key[0])) for key in mon.vars.keys()))

    def at(self,**vars):
        return sum(mon.at(**vars) for mon in self.monlist)

    def __add__(self,other):
        #print("adding",self,other,type(self),type(other),self.monlist,other.monlist)
        if isinstance(other,Polynomial):
            return Polynomial(self.monlist+other.monlist)
        elif isinstance(other,Monom):
            return Polynomial(self.monlist+[other])    
        elif isinstance(other,Quotient):    
            return other+self
        elif isinstance(other,Complex):
            return Complex(self+other.real,other.imag)
        elif isinstance(other,Vector):
            return Vector(*(self+comp for comp in other.values))
        else:
            return self+Monom(other)
    __radd__=__add__

    def __mul__(self,other):
        
        if isinstance(other,Polynomial):
            return Polynomial(mon1*mon2 for mon1 in self.monlist for mon2 in other.monlist)

        if isinstance(other,(int,float)): #nebo cokoliv jineho 
            return Polynomial(other*mon for mon in self.monlist)
        if isinstance(other,Monom):
            return Polynomial(mon1*mon2 for mon1 in self.monlist for mon2 in [other])    
           # return Polynomial(mon1*other for mon1 in self.monlist)    
        if isinstance(other,Quotient):
            return other*self
        if isinstance(other,Vector):
            return other.__class__(*(self*comp for comp in other.values))
        return self*Monom(other)
         
                
    __rmul__=__mul__

    def __neg__(self):
        nl=[(-1)*mon for mon in self.monlist]
        return Polynomial(nl)

    def __pow__(self,exponent):
        if not isinstance(exponent,int): #or exponent<0:
            return ObjPow(self,exponent)
            #raise TypeError("Exponent musi byt cele cislo!")
        if exponent==0:
            return Polynomial(1)
        if len(self.monlist)==1:
            if exponent>0:
                return Polynomial(self.monlist[0]**exponent)
            else:
                return Quotient(1,self**(-exponent))
            
        else:
            if exponent>0:
                return ft.reduce(mul,(self for _ in range(exponent)))
            else:
                return Quotient(1,self**(-exponent))
            
    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return other+(-self)

    def __truediv__(self,other):
        #print("Pol div",repr(self),"|",repr(other))
        if isinstance(other,(int,float)):
            if other==0:
                raise ZeroDivisionError("Deleni nulou!")
            else:
                return self*(1/other if 1%other else 1//other)
        if other==self:
            
            
            return Quotient(1)
        
        if isinstance(other,Monom):
            #return self*other.inv()
            return self/Polynomial(other)
        if isinstance(other,Quotient):
            #print("other.inv",other.inv())
            return other.inv()*self
        #if isinstance(other,GeneralObject):
        #    other=Monom(other)    
        #print(type(self),type(other))        
        #print("just passing through...")
        return Quotient(self,other) 

    def __rtruediv__(self,other):

        return Quotient(other)/self
    
    def derivo(self,var):
        nl=[]
        for mon in self.monlist:
            #print(var,mon.vars,mon.coef)
            if var not in mon.vars:
                continue
            new_vars={**mon.vars}
            new_vars[var]-=1
            #print(mon.coef,mon.vars[var]) 
            nl.append(Monom(mon.coef*mon.vars[var][1],new_vars))
        return Polynomial(nl)

    def deriv(self,dervar):
        nl=Polynomial(0)
        for mon in self.monlist:
            nl+=mon.deriv(dervar)

        return nl
    def divgrad(self):
        nl=[]
        for mon in self.monlist:
            if mon.isconst:
                continue
            for var,(_,order) in mon.vars.items():
                if order==0:
                    continue
                new_vars={**mon.vars}
                new_vars[var]-=1
                nl.append(Monom(mon.coef*order,new_vars))
        return Polynomial(nl)
    
    def __repr__(self):
        #return(f"{module_prefix}Polynomial(["+",".join((f"{mon!r}" for mon in self.monlist))+"])")
        return(f"{module_prefix}P(["+",".join((f"{mon!r}" for mon in self.monlist))+"])")

    def __eq__(self,other):
        #print(self.order)
        if isinstance(other,Complex):
            if other.isreal():
                return self==other.real
        if self.isconst:
            if isinstance(other,(float,int)):
                #print(self.monlist[0],other)
                return self.monlist[0]==other
        
        if isinstance(other,Monom):
            return self==Polynomial(other)
        
        if isinstance(other,Polynomial):
            #print(set(self.monlist))
            #print(set(other.monlist))#,"comp")
            #print(self.monlist[0].coef==other.monlist[0].coef)
            #print(self.monlist[0].vars==other.monlist[0].vars)
            #for ((key,(obj,order)),(key2,(obj2,order2))) in zip(self.monlist[0].vars.items(),other.monlist[0].vars.items()):
             #   #print(key,key2,key==key2)
             #   #print(obj,obj2,repr(obj),repr(obj2),obj==obj2)
              #  #print(order,order2,order==order2)
            #print(self.monlist[0].vars==other.monlist[0].vars)
            return set(self.monlist)==set(other.monlist)
        elif isinstance(other,Quotient):
            return other==self
        return super().__eq__(other)

    def __str__(self):
        #smonlist=sorted(self.monlist,key=lambda mon: product((order for order in mon.vars.values())))
        s=""
        for mon in self.monlist:
            if mon.coef!=0:
                if s=="":
                    s+=str(mon)
                    
                else:
                    if mon.coef>0:
                        s+=" + "+str(mon)
                    else:
                        s+=" - "+str(mon)[1:]   
        if s=="":
            s="0"               
        return s

    
    def __int__(self):
        for mon in self.monlist:
            if  mon.isconst:
                return int(mon.coef)
        raise ValueError("Can't convert a non-constant polynomial to int")

    def __float__(self):
        for mon in self.monlist:
            if  mon.isconst:
                return float(mon.coef)
        raise ValueError("Can't convert a non-constant polynomial to float")

    @classmethod
    def fromrepr(cls,text):
        return eval(text.replace("P","Polynomial").replace("M","Monom"))
    def get_coefs(self,var,at_least=None):
       # #print(self.varset,self.order)

        max_order=max(at_least,self.order) if at_least!=None else self.order
        #coefs={order:0 for order in range(max_order+1)}
        coefs=[0 for _ in range(max_order+1)]
        for mon in self.monlist:
            if mon.vars=={}:
                coefs[0]=mon.coef
            else:
                #coefs[mon.vars[var][1]]=mon.coef
                coefs[mon.vars[var][1]]=mon.coef
        return coefs
 #       return dict(sorted(coefs.items())) 
    def leading_term(self,var): 
            #return (0,pol.monlist[0].coef) if pol.isconst else max(filter(lambda d: d[1]!=0,(d for d in pol.get_coefs(var).items()) ))                    
            #return (0,pol.monlist[0].coef) if pol.isconst else max(filter(lambda d: d!=0,(d for d in pol.get_coefs(var))))
            #print(self.get_coefs(var))
            #input()
            for order,coef in enumerate(self.get_coefs(var)[::-1]):
                if coef!=0:
                    #print("returning",self.order-order,coef)
                    return self.order-order,coef
            return 0,0


    def longdiv(self,other):
        #print("longdiving with",(self),(other))
        if isinstance(other, (int,float,Monom,Variable)):
            other=Polynomial(other)
        elif isinstance(other,Quotient):
            if other.q.isconst:
                other=Polynomial(other.p/other.q.monlist[0])
            else:
                raise TypeError("Can't use the long division algorithm to divide by a quotient")
        if not self.varset:
            if not other.varset:
                num=self.monlist[0].coef
                den=other.monlist[0].coef
                return Polynomial(num//den),Polynomial(num%den),[(self,0),(num%den,num//den)]
            else:
                return Polynomial(0),self,[(self,0),(self,0)]
        if other.varset:
            if len(self.varset)>1 or self.varset!=other.varset:
                raise NotImplementedError(r"The polynomials must be of the same type and in one variable,"
        r"the more general case hasn't been implemented yet")
        
        var=next(iter(self.varset))

        p=self
        q=other            

        s=SPolynomial(var,0)
        partial_results=[(p,0)]

        porder,pcoef=p.leading_term(var)
        #print(porder,pcoef)
        qorder,qcoef=q.leading_term(var)
        
        while porder>=qorder:
            #print(p,":",q) 
            #print(porder,pcoef,qorder,qcoef)
            #input()
            #print(p,pcoef,q,qcoef,q.obj_dict)    
            if p.obj_dict:
                newterm=Monom(pcoef/qcoef if pcoef%qcoef else pcoef//qcoef,{var:(p.obj_dict[var],porder-qorder)})
            else:
                newterm=Monom(pcoef/qcoef if pcoef%qcoef else pcoef//qcoef)
            #print(pcoef,qcoef,"...",s,p,newterm*q,type(newterm),type(q),type(newterm*q))
            #print(" | ".join(str(el) for el in (var,repr(p),q,repr(newterm),q*newterm,newterm*q)))
            #input()
            #print(newterm,p,s)
            s+=newterm
            p-=newterm*q
            #print("->",p,s)
            #print(newterm,newterm*q)
            #print("s,r:",s,"|",p)
            #print(p,p.order)
            #print(repr(p),p==0,str(p))
            partial_results.append((p,s))
            if p==0:
                break
            
            porder,pcoef=p.leading_term(var)
            
         #   if self.order<other.order:
          #      return SPolynomial("",0.0),self
        #print(self.varset)
        
        if len(partial_results)==1:
            partial_results.append((self,0))
        return s,p,partial_results
       # except AttributeError as e:
        #    #print(e)
         #   #print("The argument must a monomial, a polynomial or a polynomial quotient!")

class SMonom(Monom): 
    def __init__(self,coef,symb,order):
        super().__init__(coef,{symb:order})

class SPolynomial(Polynomial):
    def __init__(self,symb,*coefs):
        var=Variable(symb)
        super().__init__((Monom(coef,{symb:(var,i)}) for i,coef in enumerate(coefs)))

class Quotient(GeneralObject):
    @property
    def name(self):
        return "Quotient"
    @property
    def evaluables(self):
        return int,float
    @property
    def is_evaluable(self):
        return self.p.is_evaluable and self.q.is_evaluable

    def __init__(self,p:Polynomial,q:Polynomial=None,cancel_common=True):
        
        if p is None:
            raise ValueError("P can't be None!")
        if q is None:
            q=1
        if isinstance(p,Quotient) and isinstance(q,Quotient):
            p,q=p.p*q.q,p.q*q.p
        elif isinstance(p,Quotient):
            p,q=p.p,p.q*q
        elif isinstance(q,Quotient):
            p,q=p*q.q,q.p
        if q==0:
            raise ZeroDivisionError("Division by zero!")   
        
        if p==0:
            p=Polynomial(0)
            q=Polynomial(1)
        else:
            if q is None:
                q=SPolynomial("",1)
          
            #print(p,q)
            if not isinstance(p,Polynomial): 
                p=Polynomial(p)
            if not isinstance(q,Polynomial):
                q=Polynomial(q)
            
            if p==q:
                
                p=Polynomial(1)
                q=Polynomial(1)
            elif p.isconst and q.isconst:
          
                a=p.monlist[0].coef
                b=q.monlist[0].coef
                a,b=make_whole(a,b)
                com_div=gcd(a,b)
                a,b=a/com_div,b/com_div
                p=Polynomial(a)
                q=Polynomial(b)
          
            else:
                
                #print("middling quotient with...",repr(p)," | ",repr(q)," | ")                      
                if p.varset==q.varset and len(p.varset)==1:
                 #    #print("longdiving",p,q)
                        

                    if p.order>=q.order:
                        s,r,_=p.longdiv(q)                
                        if r==0:
                            p=s
                            q=Polynomial(1)
                    else:
                        s,r,_=q.longdiv(p)                
                        if r==0:
                            p=Polynomial(1)
                            q=s
                    #print(s,r)
                 #   p,q=self.cancel_and_divide(p,q)

                else:
                    
                    if  cancel_common:
                        #print("cancel_common")    
                        p,q=self.cancel_and_divide(p,q)
                        #print("After cancelling, got",p,q)
        if q.monlist[0].coef<0:
            self.p,self.q=-p,-q            
        else:
            self.p,self.q=p,q
            
        self.varset=self.p.varset.union(self.q.varset)
        self.isconst=self.p.isconst and self.q.isconst
        self.attached=[self.p,self.q]
        #print("exiting quotient with...",repr(self.p)," | ",repr(self.q))                      
        #print("Finished Quotient with ",self.p,self.q)
            #print("Built Quotient with p,q:,type(p),type(q),varset,isconst:",self.p,self.q,type(p),type(q),self.varset,self.isconst)
 
    def cancel_and_divide(self,p,q):
        #print("cancelling",p,"|",q)
        ppref,prest=p.factor_variables()
        #print("factoring q",p,"|",q)
        qpref,qrest=q.factor_variables()
       # #print("|".join(str(el) for el in (ppref,qpref,prest,qrest)))
        #input()
        
        #print(" | ".join(map(str,(ppref,qpref,prest,qrest))))
        pcoef,qcoef=ppref.coef,qpref.coef
        #print("d=gcd(pcoef,qcoef)")
        d=gcd(pcoef,qcoef)

        pcoef,qcoef=pcoef/d,qcoef/d #pozor, co to udělá když jedno z toho bude float?
        obj_dict={**p.obj_dict,**q.obj_dict}
        common_vars={var:(obj_dict[var],(min(mon.vars.get(var,(None,0))[1] for mon in (ppref,qpref)))) for var in ppref.varset.union(qpref.varset)}
        newpvars,newqvars=({var:(obj,order-common_vars[var][1]) for var,(obj,order) in mon.vars.items() if order-common_vars[var][1]!=0} for mon in (ppref,qpref))
        ppref,qpref=Monom(pcoef,newpvars),Monom(qcoef,newqvars)
        
        #print("v1:",prest,qrest)
        #input()
       # #print(all(mon1.coef==mon2.coef for mon1,mon2 in zip(prest.monlist,qrest.monlist)))
      #  #print(prest==qrest,repr(prest),repr(qrest))
        
       # #print(v1)
        #v2=v1*ppref
        #print("v2 pass",v2,type(v2))
        #v3=v2/qpref
        #print("v3 pass",v3,type(v3))
        #print("Sending",prest,qrest,"and ",ppref,qpref," to newz")
        z1=Quotient(ppref,qpref,cancel_common=False)
        z2=Quotient(prest,qrest,cancel_common=False)
        
        newz=Quotient(z1.p*z2.p,z1.q*z2.q,cancel_common=False)
        return newz.p,newz.q

    def eval(self,*args,**kwargs):
        #print("---",repr(self.p.eval(*args,**kwargs)),"/",repr(self.q.eval(*args,**kwargs)))
        #print(repr(self.p.eval(*args,**kwargs)))
        #print(repr(self.q.eval(*args,**kwargs)))
        return self.p.eval(*args,**kwargs)/self.q.eval(*args,**kwargs)

    def at(self,**vars):
        res=self.p.at(**vars)/self.q.at(**vars)
        if isinstance(res,float):
            if int(res)==res:
                return int(res)
        else:
            return res
    
    def __add__(self,other):
     #   #print("type other",type(other),isinstance(other,Quotient))
        if not isinstance(other,Quotient):
            if isinstance(other,Complex):
                return Complex(self+other.real,other.imag)
            if isinstance(other,Vector):
                return other.__class__(*(self+comp for comp in other.values))
          #  if isinstance(other,Monom):
          #      other=Polynomial(other)
            else: #isinstance(other,(Polynomial,int,float)):
                return Quotient(self.p+other*self.q,self.q)    
        if self.q==other.q:
            return Quotient(self.p+other.p,self.q)    
        else:
            return Quotient(self.p*other.q+self.q*other.p,self.q*other.q)
    __radd__=__add__
   


    def __sub__(self,other):
        return self+(-other)

    def __rsub__(self,other):
        return other+(-self)

    def __mul__(self,other):
        #if isinstance(other,(Variable,Polynomial,Monom,int,float)):# or type(other) in [int,float]:
        if not isinstance(other,Quotient):# or type(other) in [int,float]:
            #return Quotient(self.p*other,self.q)
            if isinstance(other,Vector):
                return other.__class__(*(self*comp for comp in other.values))
            else:
                other=Quotient(other)
        if self.p!=0:
            
            if self.p==other.q and self.q==other.p:
                #print("1545")   
                return Quotient(1)
            elif self.p==other.q:
                return Quotient(other.p,self.q)
            elif other.p==self.q:
                #print("1550")   
                return Quotient(self.p,other.q)
            elif self.p*other.p==self.q*other.q:
                return Quotient(1)
            else: 
                #print("here")   
                return Quotient(self.p*other.p,self.q*other.q)
        else:
            return Quotient(0)
    __rmul__=__mul__

    def __pow__(self,exponent):
        if exponent>0:
            return Quotient(self.p**exponent,self.q**exponent)
        elif exponent<0:
            if self.p==0:
                raise ZeroDivisionError("Nula nema zaporne mocniny!")
            else:
                return Quotient(self.q**(-exponent),self.p**(-exponent))
        else: #exponent==0
            return Quotient(0)

    

    def __repr__(self):

        cs=self
        #return f"{module_prefix}Quotient({cs.p!r},{cs.q!r})"
        return f"{module_prefix}Q({cs.p!r},{cs.q!r})"

    def __str__(self):
        cs=self
        if self.q.isconst and self.q.monlist[0].coef<0:
                p,q=-self.p,-self.q
        else:
            p,q=self.p,self.q
        
        p,q=cs.p,cs.q
        pstr=str(p)
        qstr=str(q)
        
        pstrlen=max(len(pstr.split(" + ")),len(pstr.split(" - ")))
        upar="()" if pstrlen>1 or len(self.p.varset)>1 else ["",""]
        if q.isconst or (len(q.monlist)==1  and len(q.monlist[0].vars)==1) and q.monlist[0].coef==1: 
                lpar=["",""]
        else:
            lpar="()"
        #qstrlen=max(len(qstr.split(" + ")),len(qstr.split(" - ")))
        #print("debug",self.p,self.q)
        if q==1:
            return pstr
        
        return ("{upar[0]}{up}{upar[1]}/{lpar[0]}{down}{lpar[1]}".format(
            up=pstr,down=qstr,upar=upar,lpar=lpar))
    def __format__(self,fmt):
        if fmt=="q":
            pstr=str(self.p)
            qstr=str(self.q)

            pstrlen=max(len(pstr.split(" + ")),len(pstr.split(" - ")))
            qstrlen=max(len(qstr.split(" + ")),len(qstr.split(" - ")))
            upar="()" if pstrlen>1 else ["",""]
            lpar="()" if qstrlen>1 else ["",""]
        #print("debug",self.p,self.q)
            return ("{upar[0]}{up}{upar[1]}/{lpar[0]}{down}{lpar[1]}".format(
            up=pstr,down=qstr,upar=upar,lpar=lpar))
        else: 
            return str(self)
    def __int__(self):
        if self.isconst:
            return int(float(self.p)/float(self.q))
        else:
            raise ValueError("Can't convert a non-constant quotient to int")
    def __float__(self):
        
        if self.isconst:
            return float(float(self.p)/float(self.q))
        else:
            raise ValueError("Can't convert a non-constant quotient to float")
        
    def inv(self):
        #print(f"self {self},|{self.p},{self.q} | invself {Quotient(self.q,self.p)}")
        #print("from inv:",self.p,self.q)
        return Quotient(self.q,self.p,cancel_common=False)
    def simplify(self):
        return self.p.simplify()/self.q.simplify()
    def __neg__(self):
        return Quotient(-self.p,self.q)
    def deriv(self,var):
        return (self.p.deriv(var)*self.q-self.p*self.q.deriv(var))/(self.q**2)
    def __truediv__(self,other):
        #print("Quot div",self,"|",other)
        

        if not isinstance(other,Quotient):
            #print("self,other",self,other)
            other=Polynomial(other)

        if other==0:
            raise ZeroDivisionError("Deleni nulou!")
        else: 
            #print("here",self,other,type(other))#,type(other.inv()),self*other.inv())
            return Quotient(self.p,self.q*other)#other.inv()

    def __rtruediv__(self,other):
        
        if self.p==0:
            raise ZeroDivisionError("Deleni nulou!")
        else:
            if not isinstance(other,Quotient):
                other=Polynomial(other)
            return other/self
    def __eq__(self,other):
        if  not isinstance(other,Quotient):
            #print(self,other)
            #print(",".join(map(repr,(self.p,self.q,other,other*self.q))))
            if isinstance(other,Complex) and other.isreal():
                return self==other.real
                
            if self.q==1:
                return self.p==other
            else:
                
                return self.p==other*self.q
        else:
            return self.p*other.q==self.q*other.p

    

class Vector(GeneralObject):
    @property
    def name(self):
        return "Vector"
    @property
    def evaluables(self):
        return (int,float)
    def is_evaluable(self):
        return True
    def eval(self,*args,**kwargs):
        return Vector( *(comp.eval(*args,**kwargs) if isinstance(comp,GeneralObject) else comp for comp in self.values))
    
    def __init__(self,*values):
        #print("Vector got values",values)
        self.attached=self.values=list(values)
        self.dim=len(self.values)
        self.tol=1.e-10
    
    def __len__(self):
        return len(self.values)
    def __add__(self,other):
        if isinstance(other,Vector) and not isinstance(other,Complex):
            if self.dim!=other.dim:
                raise ValueError("The vectors must have same dimension!")
            return Vector(*(val1+val2 for val1,val2 in zip(self.values,other.values)))
        else:
            return Vector(*(val+other for val in self.values) )
    __radd__=__add__

    def __neg__(self):
        return Vector(*(-val for val in self.values))
    
    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return -self+other
    def __mul__(self,other):
        #if isinstance(other,(int,float)):
         #   raise NotImplementedError("A vector can only be multiplied by a number! The Lie algebra is not implemented yet")
        #else:
        if isinstance(other,Vector):
            return other.__class__(*(self*val for val in other) )
        else:
            return Vector (*(other*val for val in self) )

    __rmul__=__mul__

    def __truediv__(self,other):
        if isinstance(other,Vector):
            raise ValueError("Can't divide two vectors!")
        else:
            return Vector(*(comp/other for comp in self.values))
    def __rtruediv__(self,other):
        return Vector(*(other/comp for comp in self.values))
        
    def norm(self):
        return Sqrt(self.dot(self)).eval()
    
            

    def T(self):
        subvecs=[]
        try:
            l=self.values[0].dim
            check=all(comp.dim==l for comp in self.values)
            if not check:
               raise ValueError("Can't transpose object with unequal number of elements in each column!")
            veclen=self.values[0].dim
            for ind in range(veclen):
                subvecs.append(Vector(*(vec.values[ind] for vec in self.values)))
            return Vector(*subvecs)
        except (TypeError,AttributeError): 
            return self
        
            
            
            

    def cross(self,other):
        if self.dim==2:
            vec1=Vector(*self.values,0)
        else:
            vec1=self
        if other.dim==2:
            vec2=Vector(*other.values,0)
        else:
            vec2=other
        #print(vec1.dim,vec1,vec2.dim,vec2)
        if vec1.dim==vec2.dim!=3:
            raise ValueError("The vector product of two vectors satisfying Jacobi's identity is only defined in dimension 3!")
        x1,y1,z1=vec1.values
        x2,y2,z2=vec2.values
        return Vector(y1*z2-y2*z1,z1*x2-z2*x1,x1*y2-x2*y1)

        

    def dot(self,other):
        if not isinstance(other,Vector):
            raise ValueError("The right argument has to be a vector!")
        if self.dim!=other.dim:
            raise ValueError("The vectors need to have identical dimensions!")
        return sum(val1*val2 for val1,val2 in zip(self.values,other.values))
    def __repr__(self):
        return f"Vector("+",".join(repr(value) for value in self.values)+")"
    def __str__(self):
        #print("vvals:",self.values)
        return f"( "+" , ".join(truncate_number(value) if isinstance(value,float) else "".join(map(str,value))
        if isinstance(value,tuple) else str(value) for value in self.values)+" )"
    def __eq__(self,other):
        if not isinstance(other,Vector):
            return  all(comp==other for comp in self)
        #print("Comparing",repr(self),"and",repr(other))
        #print(self.values,other.values,self.values[0]-other.values[0],self.values[1]-other.values[1])
        for c1,c2 in zip(self.values,other.values):
            if c1!=c2:
                if isinstance(c1,(float,int)) and isinstance(c2,(float,int)):
                    if abs(c1-c2)>self.tol:
                        return False
                else:
                    return False
        return True 
        #return self.values==other.values
        #return all(c1==c2 for c1,c2 in zip(self.values,other.values))
    def __iter__(self):
        return iter(self.values)

    def deriv(self,dervar):
        newcomps=[]
        for comp in self.values:
            if isinstance(comp,(int,float)):
                newcomps.append(0)
            else:
                newcomps.append(comp.deriv(dervar))
        #print(newcomps)
        return Vector(*newcomps)
    def grad(self):
        #print(self,"entering grad(), values:",self.values)
        vars=list(sorted(self.get_vars()))
        
        if vars:
            newcomps=[]
            for comp in self.values:
                if isinstance(comp,(int,float)):
                    newcomps.append(Vector(*(0 for _ in self.values)))
                else:
                    newcomps.append(Vector( *(comp.deriv(vars[ind]) if ind<len(vars) else Monom(0)  for ind,_ in enumerate(self.values))))
                    
            return Vector(*newcomps)
        else:
            return Vector(*(Vector(*(0 for _ in self)) for _ in self))

    def divergence(self):
        vars=list(sorted(self.get_vars()))
        return sum(comp.deriv(var) if isinstance(comp,GeneralObject) else Monom(0) for comp,var in zip(self.values,vars))
    def curl(self):
        if self.dim==2:
            vec=Vector(*self.values,0)
        else:
            vec=self
        
        if vec.dim!=3:
            raise ValueError("The curl can only be taken in 3 dimensions!")
        #print([comp.values for comp in vec.grad()])
        (_,xy,xz),(yx,_,yz),(zx,zy,_)=( comp.values for  comp in vec.grad())

        return Vector(zy-yz,xz-zx,yx-xy)

    def laplace(self):
        vars=list(sorted(self.get_vars()))
        return Vector(*(sum(comp.deriv(var).deriv(var) if isinstance(comp,GeneralObject) else Monom(0) for var in vars) for comp in self.attached) )
    def simplify(self):
        return self.__class__(*(comp.simplify() if isinstance(comp,GeneralObject) else comp 
                                for comp in self.values))
    def flat(self):
        res=[]
        for comp in self:
            if type(comp) is Vector:
                for subcomb in comp.flat():
                    res.append(subcomb)
            else:
                res.append(comp)
        return Vector(*res)
    """def __getitem__(self,sl):
        if isinstance(sl,int):
            try:
                return self.values[sl-1]
            except IndexError:
                raise ValueError(f"The vector doesn't have a component with index {sl-1}!")
        elif isinstance(sl,Vector):
            try:
            
                print("vec:",sl)
                sl=slice(*sl)
                print("slice:",sl)
                return Vector(*self.values[slice(sl.start-1 if not (sl.start is  None or sl.start==0) else None,sl.stop  if not (sl.stop is None or sl.stop==0) else None,sl.step)])
            except (AttributeError,TypeError) as e:
                raise ValueError(f"The indices must be integer! |{e}")
        elif isinstance(sl,Variable):
            return self.deriv(sl)
                
                #return Vector(*self.values[slice(*sl)]                
         
    """ 

class Abs(Func):
    @property
    def name(self):
        return "abs"
    @property
    def numarg(self):
        return 1
    @property
    def evaluables(self):
        return int,float,Complex
    @property
    def inverse(self):
        return type(None)
    @property
    def func(self):
        def compeval(z):
            if isinstance(z,Complex):
                if isinstance(z.real,(int,float)) and isinstance(z.imag,(int,float)):
                    return abs(z.real+1j*z.imag).real
                else:
                    return Abs(z)
            else:    
                return abs(z)
        return compeval
class Angle(Func):
    @property
    def name(self):
        return "angle"
    @property
    def numarg(self):
        return 2
    @property
    def evaluables(self):
        return int,float,Complex
    @property
    def inverse(self):
        return type(None)

   
    @property
    def func(self):
        def angle(rreal,rimag):
            z=Complex(rreal,rimag)
            if isinstance(z.real,(int,float)) and isinstance(z.imag,(int,float)):
                return cmath.phase(z.real+1j*z.imag).real
            else:
                return Angle(rreal,rimag)
        return angle
        #return self.complexification()
    @property
    def ofunc(self):
        def angle(rreal,rimag):
            num=Complex(rreal,rimag)
            real,imag=num.real,num.imag
            
                
            conv=1 #180/math.pi
            if real>0:
                if imag>=0:
                    return math.atan(imag/real)*conv
                else:
                    return (2*math.pi+math.atan(imag/real))*conv
            elif real<0:
                return (math.atan(imag/real)+math.pi)*conv
            else:
                if imag>=0:
                    return math.pi/2*conv
                else:
                    return 3*math.pi/2*conv
        return angle
    
class Complex(Vector):

    @property
    def tol(self):
        return 1.e-10

    def __init__(self,real,imag=None):
        if isinstance(real,(Complex,complex)):
            self.real=real.real
            self.imag=real.imag
            if isinstance(imag,(Complex,complex)):

                self.real-=imag.imag
                self.imag+=imag.real        
            else:
                try:
                    self.imag+=imag
                except TypeError:
                    pass
        else:
            self.real=real
            if isinstance(imag,Complex):
                self.real-=imag.imag
                self.imag=imag.real
            else:
                if imag is None:
                    self.imag=0
                else:
                    self.imag=imag
        self.attached=self.values=[self.real,self.imag]
        self.dim=2 #len(self.values)
    def eval(self,*args,**at):
        try:
            rres=self.real.eval(**at)
        except (AttributeError,TypeError):
            rres=self.real
        try:
            ires=self.imag.eval(**at)
        except (AttributeError,TypeError):
            ires=self.imag
        #return rres+Complex(0,1)*ires
        #print(rres,ires)
        return Complex(rres,ires)
    def __add__(self,other):
        #print(type(other))
        if isinstance(other,Complex):
            return Complex(self.real+other.real,self.imag+other.imag)
        elif isinstance(other,Vector):
            return Vector(*(self+comp for comp in other.values))            
        else:
            return Complex(self.real+other,self.imag)
    __radd__=__add__
    def __neg__(self):
        return Complex(-self.real,-self.imag)
    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return (-self)+other
    def __mul__(self,other):
        if isinstance(other,Complex):
          #  #print("compmul",
          #  " | ".join(str(el) for el in (self.real,
           # self.imag,repr(self.real),repr(other.real),repr(self.real*other.real),type(self.real*other.real))))
            return Complex(self.real*other.real-self.imag*other.imag,self.real*other.imag+self.imag*other.real)
        else: 
            #print("mul",repr(self),repr(other),Complex(self.real*other,self.imag*other))
            #print(repr(self.real*other),repr(self.imag*other))
            return Complex(self.real*other,self.imag*other)
    __rmul__=__mul__
    def __truediv__(self,other):
        if isinstance(other,Complex):
            return self/other.dot(other)*other.conj()
        elif isinstance(other,Vector):
            return Vector(self/comp for comp in other.values)
        else:
            return Complex(self.real/other,self.imag/other)
    def __rtruediv__(self,other):
        return other/self.dot(self)*self.conj()
    def norm(self):
        return Abs(self).eval()#Sqrt(s elf.real**2+self.imag**2).eval()
    def __abs__(self):
        return self.norm()
    def conj(self):
        return Complex(self.real,-self.imag)
    
    def angle(self):
       # res=Angle(self.real,self.imag).eval()
        return Angle(self.real,self.imag).eval()
    def __pow__(self,exponent):
        ang=self.angle()#*math.pi/180
        #print(ang)
        if isinstance(exponent,int):
            if exponent>=0:
                return ft.reduce(mul,(self for _ in range(exponent)),1)
        return self.norm()**exponent*Complex((Cos(exponent*ang)).eval(),Sin(exponent*ang).eval())
    def __str__(self):
        real,imag=self.regularized().values
        
        lpar,rpar=["",""]
        if self==0:
            return "0"
        if real==0:
            if imag==0:
                return "0"
            else:
                rstr=""
        else:
            if isinstance(real,(int,float)):
                rstr=truncate_number(real)
            else:
                rstr=str(real)
                
            if imag==0:
                return rstr
            try:
                    if imag>0:
                        rstr+=" + "  
                    else:
                        rstr+=" - "  
                        imag*=-1
            except TypeError:
                if isinstance(imag,Monom):
                    if imag.coef>0:
                        rstr+=" + "  
                    else:
                        rstr+=" - "  
                        imag=-imag
                        #imag.coef*=-1
                else:
                    if imag==0:
                        rstr+=""
                    else:
                        rstr+=" + "
                
        
        
        if imag==1:
            ipref=""#str(imag)
        elif imag==-1:
            ipref="-"
        else:
            if isinstance(imag,(int,float)):
                ipref=truncate_number(imag)
                if imag<0:
                    lpar,rpar="()"
            else:
                ipref=str(imag)
                if  isinstance(imag,(Monom,Quotient)):
                    return rstr+ipref+"i"
                else:
                    return rstr+"i"+"("+ipref+")"
                
        return rstr+lpar+ipref+rpar+"i"
    def isreal(self):
        if isinstance(self.imag,(int,float)):
            return abs(self.imag)<self.tol
        else:
            return self.imag==0
    def isimag(self):
        if isinstance(self.real,(int,float)):
            return abs(self.real)<self.tol
        else:
            return self.real==0
    
    def regularized(self):
        real,imag=self
        if isinstance(self.real,(float)):
            if abs(self.real)>self.tol:
                real=self.real
            else:
                real=0
        if isinstance(self.imag,(float)):
            if abs(self.imag)>self.tol:
                imag=self.imag
            else:
                imag=0
        return Complex(real,imag)
    def __eq__(self,other):
        if isinstance(other,Complex):
            
            for c1,c2 in zip( (self.real,self.imag),(other.real,other.imag)):
                if c1!=c2:
                    if isinstance(c1,(float,int)) and isinstance(c2,(float,int)):
                        if abs(c1-c2)>self.tol:
                            return False
                    else:
                        return False
            return True 
        else:
            return self.real==other and self.isreal()
    def __float__(self):
        return float(self.real)
    def __int__(self):
        return int(self.real)
    def __complex__(self):
        return complex(self.real,self.imag)
    def __repr__(self):
        return f"Complex({repr(self.real)},{repr(self.imag)})"
    def __hash__(self):
        return hash(repr(self))
    def contains_complex(self):
        return True        
    def deriv(self,dervar):
        return Complex(*super().deriv(dervar))
    
def test():
    x=Monom(3,{"x":2,"y":3})
    y=Monom(9,{"x":4,"y":12})
    z=Monom(12,{"x":4,"y":12,"z":3})
    #print("Factoring ",x+y+z)
    #print("||".join(str(el) for el in (x+y+z).factor_variables()))
    x=Monom(1,{"x":1})
    y=Monom(1,{"y":1})
    z=Monom(1,{"z":1})
    #p=6*x**2*y**3+9*x**4*y**5+15*x**5*y**4*z**3
    #q=6*x**2*y**3+9*x**4*y**5+15*x**5*y**4*z**3
    #z=p/(2*q)
  
    #print("Factoring ",p)
    #print(" | ".join(str(el) for el in p.factor_variables()))
    #print("Factoring ",q)
    #print(" | ".join(str(el) for el in q.factor_variables()))
    #print("Canceling ",z)
    #z=z.cancel_common_prefactors()
    #print(x/y)
    #print("The result is: ",z)

"""
def factor_variables(self):
    cf=1
    d=None
    d=self.monlist[0].coef
    for mon in self.monlist[1:]:
        d=gcd(d,mon.coef)
    pref_vars={var:min(mon.vars.get(var,0) for mon in self.monlist) for var in self.varset}
    prefactor=Monom(d,pref_vars)
    new_coefs=(mon.coef//d for mon in self.monlist)
    new_vars=({var:mon.vars[var]-pref_vars[var] for var in mon.vars}  for mon in self.monlist)
    return (prefactor,Polynomial(Monom(coef,var) for coef,var in zip(new_coefs,new_vars)))
"""


def gcd(a,b):
    #print("gcd:",a,b)
    if a==0:
        return b
    if b==0:
        return a
    if not (int(a)==a and int(b)==b):
        if a%b==0:
            #print("Warning! a or b is not integer! Since b | a, I return  b")
            return b
        elif b%a==0:
            #print("Warning! a or b is not integer! Since a | b, I return  a")
            return b
        else:
            #print("Warning! a or b is not integer! Since not b | a nor a|b , I return  1")
            return 1 # max(abs(a),abs(b))/min(abs(a),abs(b))
    a,b=(a,b) if a>=b else (b,a)
    while True:
        if b==0:
            return a
        else:
            a,b=b,a%b


def lcm(a,b):
    return a*b//gcd(a,b)

if __name__=="__main__":
    x=Variable("x")
    y=Variable("y")
    z=Variable("z")
    
    #print( (1/Cos(x))/Cos(x))
    """x=Variable("x")
    y=Variable("y")
    #q=x*y
    #s=Sin(x*y)
    #z=Sin(x*y)
    #w=Monom(1,{str(s):(s,1)})
    #a=5*(x+y)*x
    #a=5*z+s
    #b=s+5*z+Cos(x)
    #print(a,b,a.eval(y=1),b.eval(y=1),a.eval(x=1,y=5),b.eval(x=1,y=7))
    #print((x+y)**3,"|||",((x+y)**3).deriv("x"))
    #print((Cos(x*y**2)+y+y**2*Sin(x)).deriv("y"))
    v=(Sin(x)*Cos(x)*x*y).deriv("x")
    #print(v,v.eval(x=1))
    #print(*(repr(vy) for vy in v.monlist))
    #print(Sin(4)*Sin(5**2)**5)
    #print(Sin(x)**(x)) 
    #print(Sin(x),Sin(x).eval(x=5),(x+Sin(x)**x)**2,((x+Sin(x)**x)**2).eval(x=4))
    #print(((Sin(x)/y).eval(x=Sin(x)**2)).eval(y=100,x=3),x/x,(x*y)/(x**2))
    x=Variable("x")
    y=Variable("y")
    #print(x.eval(x=4),x**2,y.eval(y=7))
    #print(x.name,repr(x),str(x))
    #print(x/y,(x**2)/y,(Sin(x)/Cos(y)).eval(x=Cos(y),y=Cos(y)))
    #print(x.eval(y=4),(y*x**2).eval(y=4,x=4),x*y,x*5*Sin(x)**2)
    #print(s,s.eval(x=1,y=2))
    #print(q,q.eval(x=1,y=5))
    #print(s*q,(s*q).eval(x=1,y=2))
    #print(s*q*s,(s*q*s).eval(x=1))
    #print(w*w)
    #print(x)
    #print(x.eval(x=3))
    #print(s)
    #q=Monom(4,{"("+str(s)+")":(s,2)})
    #s=go.Sin(go.Cos(x*q)) 
    #s=go.Sin(go.Sin(x*y))
    #print(y,z)
    
    #print(s)
    #print("...")
    #print(s.eval(),s.eval(x=2),s.eval(y=2),s.eval(x=2,y=2))
    #print(y.eval(x=0))
    #q=Monom(1,{"("+str(x)+")":(x,2)})
    #print(q,q**2)
    #print(q.eval(y=2),(q**2).eval(y=2))
    #s=go.Sin()
    x=Variable("x")
    y=Variable("y")
    s=Sin(x)
    #print(x,x**2,x+3*y,(x+3*y)**2,s,s**2,(s+x)**2,(s+x)**x,((s+x)**x)**3)
    vars=(x,x**2,x+3*y,(x+3*y)**2,s,s**2,(s+x)**2,(s+x)**x,((s+x)**x)**3,x.deriv("x"),s.deriv("x"))
    #print(" | ".join(str(var.eval()) for var in vars))
    #print(" |".join(str(var.eval(x=2)) for var in vars))
    #print(" | ".join(str(var.eval(y=2)) for var in vars))
    #print(" |".join(str(var.eval(x=2,y=2)) for var in vars))
    z=Sin(x)*Cos(y)**2
    d=(z.deriv("y")).deriv("x")
    #print(z,z.deriv("y"),z.deriv("y").deriv("x"),z.deriv("y").deriv("x").eval(y=x,x=y))
    z=Sin(2*x)
    #print(z,z.simplify())
    q=Cos(2*x)
    #print(q,q.simplify())
    t=Tan(2*x)
    #print(t,t**2,t.simplify())
    y=Sin(Acos(x))
    #print(y,y.simplify(),y.eval(x=1))
    for func in (Sin,Cos,Tan,Asin,Acos,Atan,Sqrt):
        #print(func(x).deriv("x"),end="|")
    z=Variable("z")
    #print("\n",y.get_vars(),x.get_vars(),Sin(z+x).get_vars())
    #print((x+z*z+Sin(x)).grad())
    #print((y*y).deriv("x"))
    #print(Vector(x,z).divergence())
    y=Variable("y")
    lap=(1/Sqrt(x**2+y**2+z**2)).laplace()
    #print( (1/Sqrt(x**2+y**2+z**2)).grad().divergence())
    #print( (1/Sqrt(x**2+y**2+z**2)).laplace())
    #print(Vector(x*z,y*z).divergence())
    #print(lap," | ",lap.simplify())
    #print(Sqrt(x)**2,(3*Sqrt(x+y)**2).simplify())
    #print(((x**(x))**(1/x)).simplify())
    #print(Ln(x**2).deriv(x))
    #print(1/x**2*2*x)
    #print((y*y).deriv("y"))
    #print(Sin(x).eval(x=1),1/(1+Sin(x).eval(x=1)))
    #print(z,1/(z+1),z.eval(x=4),(1/z).eval(x=4))"""
    """Angle, old eval:
     def eval(self,*args,**kwargs): 
        if len(self.attached)!=self.numarg:
            raise ValueError(f"Func {self.name}  needs to take exactly {self.numarg} argument(s)!")
        else:
            if Vector not in self.evaluables and type(self.attached[0]) is Vector:
                return Vector(*(self.__class__(comp).eval(*args,**kwargs) for comp in self.attached[0]))
            z=Complex(self.attached[0],self.attached[1])
            results=[obj.eval(*args,**kwargs) if isinstance(obj,GeneralObject) else obj for obj in z]
            if all(isinstance(res,self.evaluables) for res in results):
                return self.func(*(results))
            else:
                return self.__class__(*results)
    """