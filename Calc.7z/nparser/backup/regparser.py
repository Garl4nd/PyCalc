from typing import Callable
import matplotlib.pyplot as plt
import matplotlib
#from matplotlib.animation import FuncAnimation

import math
import re
from operator import mul
import functools as ft
import itertools as it
import numpy as np
from . import prime_factor
from . import solver
from . import gen_obj
from .gen_obj import SPolynomial,Polynomial,Monom,Vector,Quotient,Variable,PrettyVariable,Complex,GeneralObject
from . import appr_polsolve
#[b(k-1)]cos(t)+bcos[t(k-1)],[b(k-1)]sin(t)-bsin[t(k-1)] |b=1;k=1/3,1/2,1/4,0.65,1.5,4,6 from 0 to 320pi pden 10000
# TODO: implicitni doplnění pro závorky a unární operátory: (x-1)#2 
# TODO: plotování komplexnich cisel do komplexní roviny
# TODO: Místo implicit_ops a implicit_op= mít jen jednu volbu implicit_op="" a nedoplňovat jestliže to bude "".
# TODO: x**5 hlásí dělení nulou, co za to může? -> fujiwara
# TODO: -> by z konzistence mělo taky vracet jen jeden plochý vektor -> nejdřív nasbírat všechny substituce, kde jsou čárky a potom z nichudělat jeden vektor přes product
# TODO: Bod nahoře splněn, možná by to ještě by to chtělo přepínač na nested verzi
# TODO: Flatten do kalkulačky
class Op:
    def __init__(self,symbol:str,pri: int,arity: int,action: Callable,
                identity:set = None,direction="right",acts_on="left",unary_overload=None):
        self.pri=pri
        self.arity=arity
        self.action=action
        self.symbol=symbol
        self.identity=identity
        self.direction=direction
        self.acts_on=acts_on
        self.unary_overload=unary_overload
        self._textual=False
        if self.identity:
            self.id_rep=next(iter(self.identity))
    
    def intr(self,*args):    
        
        if len(args)!=self.arity and self.arity!="*":
            raise ValueError("Spatny pocet argumentu!")
        else:
            #print(self.action,args)
            return self.action(*args)
    def __repr__(self):
        return "Priority: {0}, arity: {1},interpretation: {2},direction: {3}, acts on: {4}".format(
            self.pri,self.arity,self.action,self.direction,self.acts_on
        )
class Parser:


    def __init__(self,preload=True,preparse=True,fill_id=True,force_func_brackets=False,implicit_conversion=True,
                restrict_symb=True,verbose=True,implicit_ops=True,
                fractions=True,solve_w_complex=True,solformat=False,backend="TkAgg"):
        self.operators={}
        self.opsymbols=set()
        self.funcs={}
        self.funcsymbols=set()
        self.symbols=set()
        self.brackets=[]
        self.modifier="#"
        self.forbidden_symbols={"-","+","."} # Plus,- a . pred cislem python chape jako cislo. ALternativa je mist maskovani kontrolovat, jestli se tyto symboly vyskytuji na zacatku a neuznavat je jako cisla.
        self.modified_symbols=set()
        self.implicit_op="*"
        self.implicit_conversion=implicit_conversion # prevadet automaticky nedefinovane symboly na polynomy?
        self.orig_text=None
        self.verbose=verbose
        self.preparse=preparse
        self.implicit_ops=implicit_ops
        self.fill_id=fill_id
        self.force_func_brackets=force_func_brackets
        self.restrict_symb=restrict_symb
        self.fractions=fractions
        self.solve_w_complex=solve_w_complex
        self.backend=backend

        self.solformat=solformat
        self.max_symbol_len=0
        # emergency error handling 
        self.max_error_depth=10
        self.__cur_error_depth=0
        self.__error_text=None
        self.pollist=[]
        self.pops={}
        self.pfuncs={}
        self.def_func=""
        self.settings={"preparse":preparse,"verbose":verbose,"restrict_symb":restrict_symb,"fill_id":fill_id,"force_func_brackets":force_func_brackets,"implicit_conversion":implicit_conversion,
        "implicit_ops":implicit_ops,"fractions":fractions}
        if preload: 
            self.load_standard()
        if self.verbose:
            print(self)

    def show_settings(self,help=False):
       
        print("The parser is using the following settings: \n")
        if help:
            help_dict={"preparse": "Make minor changes to the string for easier processing (e.g. convert -- to +, convert *-4 to *(-4), check for correct placement of bracekts, etc.)",
                        "verbose": "Print additional information about the parsing process","restrict_symb": "Restrict implicit variable names to letters of the alphabet(s)",
                        "fill_id": "In case of missing arguments of binary operators, fill in their unit elements (eg. replace '*5+' with '1*5+0').",
                        "force_func_brackets":"Require that functional arguments are enclosed with brackets (e.g. 'sin 4 5' fails if this options is True, otherwise returns 5*sin(4)).",
                        "implicit_conversion":"If an undefined symbol is encountered, automatically convert all it's letters to variables",
                        "implicit_ops": "Automatically fill in a predifined operator between symbols and brackets (e.g. '4x' -> '4*x', '(4)(5)'->'(4)*(5)' " ,
                        "fractions" : "When solving equations, output the result as fractions (e.g. for '4x=1' return Q(1,4)=1/4 if True and 0.25 if False)"}
            for key,value in help_dict.items():
                print(f"{key} ({self.settings[key]}): {value}\n")
            print("\nTo temporarily change the settings, you can set the corresponding keyword argument when calling parse(): \n\np=Parser();\np.parse('4*5',verbose=False)"  
                    "\n\nTo change the settings permanently, either set the corresponding keyword arguments when initializing the parser:\n\np=Parser(verbose=False,force_func_brackets=True)"
                    "\n\nor set them manually: \n\np=Parser()\np.verbose=False")

        else:
            for key,value in self.settings.items(): 
                print(key,":",value)
            print("\nFor details on the settings, call this function again with help=True")
        
    def __str__(self):
        return "\nParser with operators {0}\n {1:>20} {2} \n {3:>20} {4} \n\n{5:>20}".format(
            [self.unmake_unique_text(el) for el in list(self.operators.keys())],"and functions",list(self.funcs.keys()),"and brackets",self.brackets,
            "Call 'show_settings()' to see settings.")
        
    def add_operator(self,op: str,pri: int,arity: int,action: Callable,identity:set =None,
                    direction="right",acts_on="left",implicit_conversion=False,unary_func=None,overwrite=False):
        if op in self.forbidden_symbols:
            op=self.make_unique(op)
        #print(type(self.operators),op,op in self.operators)
        if op in self.symbols:
            if overwrite:
                if op in self.operators:
                    self.delete_operator(op)
                elif op in self.funcs:
                    self.delete_function(op)
            else:
                raise ValueError("Operator uz je zaregistrovany! Pridejte 'overwrite=True' ")
        if arity==1:
            if acts_on=="right":
                direction="right"
            else:
                direction="left"
        if implicit_conversion:
            self.implicit_op=op
        if unary_func==None:
            uop=None
        else:
            uop=Op("",pri,1,unary_func[0],acts_on=unary_func[1])
        #print(uop)
        self.operators[op]=Op(op,pri,arity,action,identity=identity,direction=direction,acts_on=acts_on,unary_overload=uop)
        self.opsymbols.add(op)
        self.add_symbol(op)
        
        self._sort_ops()
        
    def add_symbol(self,symbol):
        self.symbols.add(symbol)
        self.max_symbol_len=max(map(len,self.symbols))

    def delete_operator(self,op):
        if op in self.forbidden_symbols:
            op=self.make_unique(op)
        try:
            del self.operators[op]
            self.opsymbols.remove(op)
        except KeyError:
            print(f"The parser does not have operator {op}! ")

    def delete_function(self,name):
        try:
            del self.funcs[name]
            self.funcsymbols.remove(name)
            self.symbols.remove(name)
        except KeyError:
            print(f"The parser does not have function {name}! ")
    def add_function(self,name: str,arity: int,action: Callable,identity:set =None,overwrite=False,textual=False):
        if name in self.symbols:
            if overwrite:
                if name in self.operators:
                    self.delete_operator(name)
                elif name in self.functions:
                    self.delete_function(name)
            else:
                raise ValueError("Operator uz je zaregistrovany! Pridejte 'overwrite=True' ")
        self.funcs[name]=Op(name,10000,arity,action,identity)
        self.funcs[name]._textual=textual
        self.funcsymbols.add(name)
        self.add_symbol(name)
        self._sort_functions()
    def make_unique(self,symbol):
        nt=self.modifier+symbol+self.modifier
        self.modified_symbols.add((symbol,nt))
        return nt
    def unmake_unique_text(self,text):
        for el in self.modified_symbols:
            text=text.replace(el[1],el[0])
        return text
    def add_brackets(self,brackets: list):
        if len(brackets)!=2:
            raise ValueError("Must specify a pair of brackets!")
        self.brackets.append(brackets)
        self.add_symbol(brackets[0])
        self.add_symbol(brackets[1])

    def delete_bracekts(self,brackets: list):
        try:
            self.brackets.remove(brackets)
            self.symbols.remove(brackets[0])
            self.symbols.remove(brackets[1])
        except ValueError:
            print(f"The parser does not have brackets {brackets}")
            
    def _sort_op_key(self,op):
        if op[1].arity==0:
            return 10**7-len(op[0])
        else:
            return op[1].pri
            
    def _sort_ops(self):                      
        self.operators=dict(sorted(self.operators.items(),key=self._sort_op_key))
    def _sort_functions(self):
        self.funcs=dict(sorted(self.funcs.items(),key=lambda item:-len(item[0])))
    
    def find_all(self,text,p,direction="right",hungry=False):
        '''Yields all the positions of
        the pattern p in the string s.'''

        if direction=="right":
            if p=="":
                return
            i = text.find(p)
            while i != -1:
                yield i
                if hungry:
                    i = text.find(p, i+1)
                else:
                    i = text.find(p, i+len(p))
        else:
            if p=="":
                return
            i = text.rfind(p)
            while i != -1:
                yield i
                if hungry:
                    i = text.rfind(p, i+1)
                else:
                    i = text.rfind(p, i+len(p))


    def _filter_brackets(self,text:str):
        masked_inds=[[] for _ in self.brackets]
        #print(text)
        for bind,bracks in enumerate(self.brackets):
            left,right=bracks
            linds=[(pos,"l") for pos in self.find_all(text,left)]
            rinds=[(pos,"r") for pos in self.find_all(text,right)]
            inds=sorted(linds+rinds)
            lc=0
            rc=0
            for ind in inds:
                if lc==0:
                    lp=ind[0]
                if ind[1]=="l":
                    lc+=1
                else:
                     rc+=1
                if lc==rc:
                    rp=ind[0]
                    lc=0
                    rc=0
                    masked_inds[bind].append((lp,rp))
                
        return masked_inds
    
    def mask_text(self,text,brack_inds):
        masked_text=str(text)
        for ind_list in brack_inds:
            for lind,rind in ind_list:
                masked_text=masked_text[:lind]+" "*(rind-lind+1)+masked_text[rind+1:]
        #print("text: {0}, masked: {1}, brack_inds: {2}".format(text,masked_text,brack_inds))
        return(masked_text)


    def mask_text_im(self,text): #C onveniece routine, combines bracks and mask
        brack_inds=self._filter_brackets(text)
        return self.mask_text(text,brack_inds)

    def is_number(self,text):
        try:
            float(text)
        except ValueError:
            
            return False
        else:
            return True
    
    def convert_to_num(self,text):
        try:
            res=int(text)
        except ValueError:
            res=float(text)
        return res

    def strip_brackets(self,text,aggresive=True):
        #print("Stripping brackets from :",text)
        text=text.strip()
        #print("Stripped spaces :",text)
        for left,right in self.brackets:
            if text.startswith(left) and text.endswith(right):
         #       print("Processing ",left,right)
          #      print(f"{text} starts with ",left)
                left_inds=list(self.find_all(text,left))
                right_inds=list(self.find_all(text,right))

                if (len(left_inds)!=len(right_inds)):
                    raise ValueError("Spatne uzavrene zavorky!")
                else:
                    #nums=(len(k for k in left_inds if k<i) for i in left_inds)
                    nums=(len([k for k in left_inds if k<ri])-(i+1) for i,ri in enumerate(right_inds[:-1])) #Pro kazdou pravou zavorku vrati kolik nalevo od ni prebyva levych zavorek. 
                    if any(num==0 for num in nums):
                        continue
                    else:
                        if aggresive:
                            text=self.strip_brackets(text[len(left):-len(right)],aggresive=True)
                        else:
                            text=text[len(left):-len(right)]
                            break
                #print(f", stripping: {text}")
        if text.strip()=="":
            return "0"
        else:
            return text

    
    def strip2(self,text,brack_inds):
        #print(f"strip text {text}",brack_inds)
        for ind,bind in enumerate(brack_inds):
            #print(ind,bind)0f
            if len(bind)==1:
                
                lind,rind=bind[0]
                len_left=len(self.brackets[ind][0])
                len_right=len(self.brackets[ind][1])
             #   print(len_left,len_right,lind,rind,text[len_left:rind])
                if lind==0 and rind==len(text)-len_right:
                    return text[len_left:rind]
        return text

    def check_forward_conflicts(self,text,symbol):
        for it_symbol in self.symbols:
            if len(it_symbol)>len(symbol):
                    if text.startswith(it_symbol):
                        return True
        return False


    def is_substring(self,text,my_pos,sub_len=1,let_pass={}):
        #print("checking",text,"|",text[my_pos:my_pos+sub_len],"...",my_pos)
        for symbol in self.symbols:
            if symbol in let_pass:
                continue
            for pos in self.find_all(symbol,text[my_pos:my_pos+sub_len]): # Najde pozici znaku v symbolu
                if my_pos-pos<0: # pozice znaku v symbolu je vetsi nez nase misto v textu (tudiz to nemuze byt match)
                    continue
                else:
                    if text[my_pos-pos:my_pos+len(symbol)-pos]==symbol:
                        return True,my_pos+len(symbol)-pos
        return False,None

    def contains_illegals(self,text,temp_ops=set()):
            letind=0
            #print("Checking",text)
            #input()
            while letind<len(text):
                #print(letind)
                letter=text[letind]
                if letter not in self.symbols.union({"."," ",","}) and not letter.isdigit(): #is the letter missing from symbols?
                    found,new_ind=self.is_substring(text,letind)
                    if not found:
                        if self.implicit_conversion:
                            if letter.isalpha() or not self.restrict_symb:
                                #self.add_monvar(letter)
                                self.add_polvar(letter,temp_ops=temp_ops)
                                if self.verbose:
                                    print(f"Converting {letter} to variable")
                            else:
                                
                                raise ValueError(f"Can't implicitly convert the non-alphabetic symbol {letter} to variable. "
                            "To override this, set restrict_symb to 'False'")
                        else:
                            print("Found illegal letter ",letter,"which is not in",self.symbols)
                            return True,letter
                    else:
                        letind=new_ind
                else:
                    letind+=1
            return False,None

    def lexicalize(self,text,temp_ops=set()):
        letind=0
        #print("Checking",text)
        #input()

        while letind<len(text):
            found=set()
            for symbol in self.symbols:
                if text[letind:].startswith(symbol):
                    found.add(symbol)
            if found:
                symb=sorted(found,key=len,reverse=True)[0]
                if symb in self.operators:
                    self.pops[symb]=self.operators[symb]
                elif symb in self.funcs:
                    self.pfuncs[symb]=self.funcs[symb]
                letind+=len(symb)
            else:
                letter=text[letind]
                if letter not in {"."," ",","} and not letter.isdigit():
                    if self.implicit_conversion:
                            if letter.isalpha() or not self.restrict_symb:
                                self.add_polvar(letter,temp_ops=temp_ops)
                                self.pops[letter]=self.operators[letter]
                                if self.verbose:
                                    print(f"Converting {letter} to variable")
                            else:  
                                raise ValueError(f"Can't implicitly convert the non-alphabetic symbol {letter} to variable. "
                            "To override this, set restrict_symb to 'False'")
                    else:
                        raise ValueError("Found illegal letter ",letter,"which is not in",self.symbols)
                        #return True,letter
                letind+=1
        if "," in text:
            try:
                self.pfuncs[self.def_func]=self.funcs[self.def_func]
            except KeyError:
                pass

    def fill_implicit(self,text):
        lenop=len(self.implicit_op)
        for lbrack,rbrack in self.brackets:
            while True:
                ot=text
                text=re.sub(f"(\d)\s+(\d)",lambda s: f"{s[1]}{self.implicit_op}{s[2]}",text)
                if ot==text:
                    break
            text=re.sub(f"(\d)\s*{re.escape(lbrack)}",lambda s: s[1]+f"{self.implicit_op}{lbrack}",text)
            text=re.sub(f"{re.escape(rbrack)}\s*(\d)",lambda s: f"{rbrack}{self.implicit_op}"+s[1],text)
            for symb,op in self.pops.items():
                if op.arity==0: 
                    #text=re.sub(f"({re.escape(symb)})\s*{re.escape(lbrack)}",lambda s: s[1]+f"{self.implicit_op}{lbrack}",text)
                    text=re.sub(f"{re.escape(rbrack)}\s*({re.escape(symb)})",lambda s: f"{rbrack}{self.implicit_op}"+s[1],text) #komplet nahrazeni, zde asi nehrozi nebezpeci
                    text=re.sub(f"({re.escape(symb)})\s*{re.escape(lbrack)}",lambda s: s[1]+f"{lbrack}",text) # Jen odstrani mezeru
                    lpad=0 
                    for ind in self.find_all(text,f"{symb}{lbrack}"):                        
                        if not self.is_substring(text,ind+lpad,len(f"{symb}"),let_pass=self.opsymbols)[0]:
                            ns=f"{symb}{self.implicit_op}{lbrack}"
                            text=text[:ind+lpad]+ns+text[ind+lpad+len(ns)-1:]
                            #text=re.sub(f"({symb2}){name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)
                            lpad+=lenop
                for symb,op in self.pfuncs.items():
                    #text=re.sub(f"({re.escape(symb)})\s*{re.escape(lbrack)}",lambda s: s[1]+f"{self.implicit_op}{lbrack}",text)
                    text=re.sub(f"{re.escape(rbrack)}\s*({re.escape(symb)})",lambda s: f"{rbrack}{self.implicit_op}"+s[1],text)
        
        for lbrack in (brack[0] for brack in self.brackets):
            for rbrack in (brack[1] for brack in self.brackets):
                text=re.sub(f"{re.escape(rbrack)}\s*{re.escape(lbrack)}",f"{rbrack}*{lbrack}",text)
        for name in self.pfuncs:
            text=re.sub(f"(\d)\s*{name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)
            for symb2,op2 in self.pops.items():
                if op2.arity==0: 
                    lpad=0 
                    for ind in self.find_all(text,f"{symb2}{name}"):      
                        if not self.is_substring(text,ind+lpad,len(f"{symb2}{name}"))[0]:
                            ns=f"{symb2}{self.implicit_op}{name}"
                            text=text[:ind+lpad]+ns+text[ind+lpad+len(ns)-1:]
                            lpad+=lenop
                    nt=None
                    while True:
                        ot=text
                        text=re.sub(f"({symb2})\s+{name}",lambda s: f"{s[1]}{self.implicit_op}{name}",text)
                        if ot==text:
                            break
        for symb,op in self.pops.items():
            if op.arity==0 or (op.arity==1 and op.acts_on=="left"):
                if op.arity==0:
                    text=re.sub(f"(\d)\s*{symb}",lambda s: f"{s[1]}{self.implicit_op}{symb}",text)
                    text=re.sub(f"{symb}\s*(\d)",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)
                for symb2,op2 in self.pops.items():
                    if op2.arity==0 or (op2.arity==1 and op2.acts_on=="right"):
                        lpad=0
                        for ind in self.find_all(text,f"{symb}{symb2}",hungry=True):
                                if not self.is_substring(text,ind+lpad,len(f"{symb}{symb2}"))[0]:
                                    ns=f"{symb}{self.implicit_op}{symb2}"
                                    text=text[:ind+lpad]+ns+text[ind+lpad+len(ns)-1:]
                                    lpad+=lenop
                        while True:
                            ot=text
                            text=re.sub(f"{symb}\s+({symb2})",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)
                            if ot==text:
                                break
            elif op.arity==1:
                if op.acts_on=="right":
                    text=re.sub(f"(\d)\s*{symb}",lambda s: f"{s[1]}{self.implicit_op}{symb}",text)
                if op.acts_on=="left":
                    text=re.sub(f"{symb}\s*(\d)",lambda s: f"{symb}{self.implicit_op}{s[1]}",text)

               
        return text

    def check_save(self,text):
        ind=text.find("<-")
        if ind!=-1:
            varname=text[:ind].strip()
            rest=text[ind+2:]
            return varname,rest
        else:
            return None,text
    def substitute(self,text,eval_dict={},muleval_dict={},overwritten_funcs=set(),overwritten_ops=set(),temp_ops=set(),**kwargs):
        text=self.strip_brackets(text,aggresive=False) 
        masked_text=self.mask_text_im(text)
        multisub={}
        vars=[el for (lb,rb) in self.brackets for el in 
              re.findall(f"([Vv]ar{re.escape(lb)}(.*?){re.escape(rb)})",text)
        ]
        if vars:
            for expr,var in vars:
                for lb,rb in self.brackets:
                    if lb in var or rb in var:
                        raise ValueError("The argument of var can't contain any parentheses!")
                name=self.add_polvar(var,overwritten_funcs,overwritten_ops,temp_ops,pretty=True)
                #print(text,expr,name)
                #input()
                text=text.replace(expr,name)
        var_ind=masked_text.find("|")
        
        if var_ind!=-1:
            var_enum=text[var_ind+1:].split(";")
            #print(var_enum)
            text=text[:var_ind]
            #sub_list=[]
            
            for sub in var_enum:
                
                ind=sub.find(":=") 
                #assert ind!=-1, f"Wrong substitution in {sub}"
                if ind!=-1:
                    #print("Found :=",sub)
            
                    symbol,value=sub[:ind].strip(),sub[ind+2:].strip()
                    #print(symbol,value)
                 
                    temp_ops.add(symbol)
                    
                    if value.startswith("\\"):
                        try:
                            value=eval("lambda "+value[1:])
                        except SyntaxError:
                            raise ValueError("Wrongly specified operator!")
                        if symbol in self.funcsymbols:
                            overwritten_funcs.add(self.funcs[symbol])
                        elif symbol in self.opsymbols:
                            overwritten_ops.add(self.operators[symbol])
                        
                        self.add_operator(symbol,10**4,2,value,overwrite=True)
                    else:
                        if self.is_number(value):
                            value=self.convert_to_num(value)
                        else:
                            tempkwargs={**kwargs}
                            tempkwargs["draw"]=False
                            value=self.parse(value,**tempkwargs)
                            
                        if symbol in self.funcsymbols:  
                            overwritten_funcs.add(self.funcs[symbol])
                        elif symbol in self.opsymbols:
                            overwritten_ops.add(self.operators[symbol])
                        self.add_operator(symbol,10**4,0,lambda value=value: value,overwrite=True)
               

                else:
                    ind=sub.find("->") 
                    if ind!=-1:
                        #print("Found =",sub)
                        varname,exprs=sub[:ind].strip(),sub[ind+2:].strip()
                        brack_inds=self._filter_brackets(exprs)
                        commas=list(self.find_all(self.mask_text(exprs,brack_inds),","))
                        if commas:
                           # print("COMMAS!",list(commas))                                
                            expr_list=[]
                            last_pos=0
                            for comma_pos in commas:
                                expr_list.append(exprs[last_pos:comma_pos])
                                last_pos=comma_pos+1
                            expr_list.append(exprs[last_pos:])
                            multisub[varname]=expr_list
                            #new_texts=(re.sub(f"{varname}",f"{expr}" ,text) for expr in expr_list) #odkomentovat pro původní nested verzi
                            #text="("+",".join(new_texts)+")"
                        else:
                            text=re.sub(f"{varname}",f"{exprs}" ,text)  
                
                    
                    else:
                        sub=sub.strip()
                        #if sub.startswith("{") and sub.endswith("}"):
                        #    sub=sub.lstrip("{").rstrip("}")
                        #    mlist=sub.split(",")
                            
                        ind=sub.find("=") 

                        if ind!=-1:
                            

                            #print("Found ->",sub)
                            symbol=sub[:ind].strip()
                            if symbol.isalpha() or not self.restrict_symb:

                                self.add_polvar(symbol,overwritten_funcs,overwritten_ops,temp_ops)
                                tempkwargs={**kwargs}
                                tempkwargs["draw"]=False

                                exprs=sub[ind+1:].strip()
                                brack_inds=self._filter_brackets(exprs)
                                commas=list(self.find_all(self.mask_text(exprs,brack_inds),","))
                                if commas:
                                    #print("COMMAS!",list(commas))                                
                                    expr_list=[]
                                    last_pos=0
                                    for comma_pos in commas:
                                        expr_list.append(exprs[last_pos:comma_pos])
                                        last_pos=comma_pos+1
                                    expr_list.append(exprs[last_pos:])
                                    muleval_dict[symbol]=[self.parse(expr,**tempkwargs) for expr in expr_list]
                        
                                else:
                                    eval_dict[symbol]=self.parse(exprs,**tempkwargs)
                                
                            else:
                                raise ValueError(f"Can't use {symbol} as a variable name, use letters of the alphabet."
                                "To override this, set restrict_symb to 'False'")
                            #print(self.eval_dict)
                        else:        
                            symbol=sub.strip()
                            
                            self.add_polvar(symbol,overwritten_funcs,overwritten_ops,temp_ops)
            if multisub: #if False: # pro nested verzi
        
                vals=([(key,comp) for comp in val] for key,val in multisub.items())
                combs=it.product(*vals)
                textcol=[]
                for subs in combs:
                    nt=text
                    for varname,expr in subs:
                        nt=re.sub(f"{varname}",f"{expr}" ,nt) #zakomentovat
                    textcol.append(nt)
                text="("+",".join(txt for txt in textcol)+")"
                    

        return text 
    def add_monvar(self,symbol,temp_ops=set()):
        temp_ops.add(symbol)
        self.add_operator(symbol,10**7,0,
        lambda value=Monom(1,{symbol:1}):value)
    def add_polvar(self,symbol,overwritten_funcs=set(),overwritten_ops=set(),temp_ops=set(),pretty=False):
        
        if pretty:
            var=PrettyVariable(symbol)
        else:
            var=Variable(symbol)
        symbol=str(var) 
        temp_ops.add(symbol)
        if symbol in self.funcsymbols: 
            overwritten_funcs.add(self.funcs[symbol])
        elif symbol in self.symbols:
            overwritten_ops.add(self.operators[symbol])
        self.add_operator(symbol,10**7,0,lambda value=var:value,overwrite=True)    
        return symbol
    def check_brackets(self,text):
        #print("chb:",text)
        #input() 
        bracknums=[[0,0] for _ in self.brackets]
        last_left=[]
        for letind,letter in enumerate(text):
            for ind,brack in enumerate(self.brackets):
                if letter==brack[0]:
                    bracknums[ind][0]+=1
                    last_left.append(ind)
                if  letter==brack[1]:
                    bracknums[ind][1]+=1
                    if bracknums[ind][1]>bracknums[ind][0]:
                        raise ValueError(f"Spatne uzavrene zavorky (pravych zavorek je do pozice {letind+1} vic nez levych)!")
                    if ind==last_left.pop():
                        pass
                    else:
                        raise ValueError(f"Zkrizene zavorky na pozici {letind+1}!")
                    
                #print(bracknums,ind)
                
                

        if any(num[1]!=num[0] for num in bracknums):
            raise ValueError("Spatne uzavrene zavorky (levych je vic nez pravych)!")


    def preprocess(self,text):
        #text=re.sub("(--)+","+",text) #sudy pocet minusu -> jedno plus
        for op in self.pops:#operators:
            if self.operators[op].arity<2:
                continue
            for op2 in self.pops:#operators:
                if self.operators[op2].arity<2:
                    continue
                symb=self.unmake_unique_text(op)
                symb2=self.unmake_unique_text(op2)
                #print(op,op2)
                
                if symb in text and symb2 in text:
                    if self.operators[op].pri>self.operators[op2].pri:
                        text=re.sub(f"{re.escape(symb)}{re.escape(symb2)}(-?\d+\.?\d*)",lambda s: f"{symb}({symb2}{s[1]})",text) #*- -> *(-)
        
        return text 

    def parse(self,text:str,draw=False,verbose=None,implicit_conversion=None,preparse=None,
              implicit_ops=None,force_func_brackets=None,fractions=None,solve_w_complex=None,
              solformat=None,**kwargs):
        #print(f"Putting {text} into parse")
        eval_dict={}
        meval_dict={}
        opops,opfuncs,self.pops,self.pfuncs=self.pops,self.pfuncs,{},{}
        #for_dict={}
        overwritten_funcs=set()
        overwritten_ops=set()
        self.partial_results=[]
        self.orig_text=text
        temp_ops=set()
        orig_impl=self.implicit_conversion
        if implicit_conversion!=None:
            self.implicit_conversion=implicit_conversion
        orig_verbose=self.verbose
        if verbose!=None:
            self.verbose=verbose
        orig_preparse=self.preparse
        if preparse!=None:
            self.preparse=preparse
        orig_implicit_ops=self.implicit_ops
        if implicit_ops!=None:
            self.implicit_ops=implicit_ops
        orig_force_func_brackets=self.force_func_brackets
        if force_func_brackets!=None:
            self.force_func_brackets=force_func_brackets
        orig_fractions=self.fractions
        if fractions!=None:
            self.fractions=fractions
        orig_sol_w_complex=self.solve_w_complex
        if solve_w_complex!=None:
            self.solve_w_complex=solve_w_complex
        orig_solformat=self.solformat
        if solformat!=None:
            self.solformat=solformat
        
        savevar,text=self.check_save(text) 
        text=self.substitute(text,eval_dict=eval_dict,muleval_dict=meval_dict,
            	            temp_ops=temp_ops,overwritten_funcs=overwritten_funcs,overwritten_ops=overwritten_ops,**kwargs)
        if fractions!=None:
            self.fractions=fractions
        if self.preparse:
            text=re.sub("(--)+","+",text) #sudy pocet minusu -> jedno plus
            self.check_brackets(text)


        for symb in self.forbidden_symbols:
            if self.make_unique(symb) in self.symbols:
                if symb in text:
                    text=text.replace(symb,self.make_unique(symb))
        #found_illegal,illegal_symbol=self.contains_illegals(text,temp_ops)
        self.lexicalize(text,temp_ops)
        if preparse:
            text=self.preprocess(text)
        try:    

            #if found_illegal:
            #    raise ValueError(f"The expression {text} contains an undefined symbol '{illegal_symbol}'!")
            if self.implicit_ops:
                self.pops[self.implicit_op]=self.operators[self.implicit_op]
                text=self.fill_implicit(text)
            
            self.pops=dict(sorted(self.pops.items(),key=self._sort_op_key))
            self.pfuncs=dict(sorted(self.pfuncs.items(),key=lambda item:-len(item[0])))
            
            if self.preparse:
                if self.verbose:
                    print("Preparsed: ", self.unmake_unique_text(text))
            res=self._parse(text)
            
                
            if eval_dict:
                if isinstance(res,GeneralObject):
                    res=res.eval(**eval_dict)
            if meval_dict:
                try:
                    if isinstance(res,GeneralObject):
                        vals=( [(key,comp) for comp in val] for key,val in meval_dict.items())
                        combs=list(it.product(*vals))
                        args=[dict(comb) for comb in combs]
                        res=Vector(*(res.eval(**arg) for arg in args))
                except TypeError as e:
                    print(str(e))
                    pass
                
        finally:
            for op in set(temp_ops):
                try:
                    
                    self.opsymbols.remove(op)
                    self.symbols.remove(op)
                    del self.operators[op]
                except (KeyError,IndexError):
                    pass 
                for func in overwritten_funcs:
                    self.funcs[func.symbol]=func
                    self.funcsymbols.add(func.symbol)
                    self.add_symbol(func.symbol)
                for op in overwritten_ops:
                    self.operators[op.symbol]=op
                    self.opsymbols.add(op.symbol)
                    self.add_symbol(op.symbol)
                self._sort_ops()
                self.implicit_conversion=orig_impl
                self.verbose=orig_verbose
                self.preparse=orig_preparse
                self.implicit_ops=orig_implicit_ops
                self.fractions=orig_fractions
                self.solformat=orig_solformat
                self.sol_w_complex=orig_sol_w_complex
                self.force_func_brackets=orig_force_func_brackets
            self.pops,self.pfuncs=opops,opfuncs
            self.__cur_error_depth=0
        #print(eval_dict)
        if savevar!=None:
            #print("adding",savevar)
            self.add_operator(savevar,10**7,0,lambda value=res:value,overwrite=True)    
        if draw:
            self.draw_parse_tree(**kwargs)
        return res

    def sparse(self,*args,**kwargs):
        res=self.parse(*args,**kwargs)
        if isinstance(res,(int,float)):
            return gen_obj.truncate_number(res)
        else:
            return str(res)
        
    def _parse(self,text:str,level=(0,0),lbuf=None,rbuf=None):
        #print(f"_parser got {text}")
        self.partial_results.append([level,self.unmake_unique_text(text),"sym",None])
        #print(text)
        #print(text)
        text=self.strip_brackets(text,aggresive=True)
        #print(text)
        if self.is_final(text): 
        #    print(f"final {text}")
            #return(str(float(text)))
            #print(lbuf,rbuf)
            if lbuf!=None or rbuf!=None:
                
                if text[0] not in ("+","-"):
                    #print(text,lbuf,rbuf)

                    raise ValueError("Spatne zadany vyraz! (Nejspis unarni operator mezi dvema argumenty nebo unarni operator na spatne strane)")
            res=self.convert_to_final(text) # a zde by se mohli vracet obecnejsi algebraicke objekty
            #print(text,res)
            self.partial_results.append([level,res,"res",None])
            return res


        #self.partial_results.append((level,self.unmake_unique_text(text),"sym"))
        
        brack_inds=self._filter_brackets(text)
        masked_text=self.mask_text(text,brack_inds)
        if masked_text.find(",")!=-1:
            text=f"{self.def_func}({text})"
        else:
            #for symbol,op in self.operators.items():
            for symbol,op in self.pops.items():
                
                #text=self.strip2(text,brack_inds)
                #print(f"Before mask {text}") 
                #print(text,symbol) ##zde musi byt smycka pres findall (v pripade confliktu)
                for ind in self.find_all(masked_text,symbol,direction=op.direction):
                    #print(symbol,ind)
                    #print("Found",symbol)
                    is_conflict,_=self.is_substring(text,ind,len(symbol),let_pass={symbol})
                    if is_conflict: #alternativa: maskovat prekryvajici se operatory krizkem #
                        #print("Konflikt!")
                        continue

                    #print("Passed conflict check: ",symbol)
                    lp=text[:ind]
                    rp=text[ind+len(symbol):]
                    #print(symbol)
                    #print(f"Before eval: lp = {lp}, rp= {rp}")
                    
                    if op.arity==0:
                        res=op.intr()
                        #print(f"res {res} , {type(res)}")
                        self.partial_results.append([level,res,"res",None])
                        return res
                    else:
                        
                        if op.arity==1:
                            res=self.expr_eval1(lp,rp,op,level=level,lbuf=lbuf,rbuf=rbuf)
                            self.partial_results.append([level,res,"res",None])
                            return res
                    #       print(lp,rp)
                        
                        elif op.arity==2:
                            #print("ar2",op.symbol,lp,rp,lbuf,rbuf)
                            if lp=="" and lbuf==None and op.unary_overload:
                            #    print("Overloading")
                            #       print("Overloading right")
                                    if op.unary_overload.acts_on=="left":                            
                                        raise ValueError(f"Wrong direction of action! The operator {symbol} acts on left.")
                                    else:
                                        res=self.expr_eval1(lp,rp,op.unary_overload,level=level,lbuf=lbuf,rbuf=rbuf)
                                        self.partial_results.append([level,res,"res",None])
                                        return res
                            elif rp=="" and rbuf==None and op.unary_overload:
                                    #print(lbuf,rbuf,lp,rp)
                                    if op.unary_overload.acts_on=="right":
                                        raise ValueError(f"Wrong direction of action! The operator {symbol} acts on right.")
                                    else:
                                        res=self.expr_eval1(lp,rp,op.unary_overload,level=level,lbuf=lbuf,rbuf=rbuf)
                                        self.partial_results.append([level,res,"res",None])
                                        return res
                            else:
                                res=self.expr_eval2(lp,rp,op,level=level,lbuf=lbuf,rbuf=rbuf)
                                self.partial_results.append([level,res,"res",None])
                                return res

        res=self.eval_funcs(text,level=level)
        self.partial_results.append([level,res,"res",None])
        return res

    def expr_eval1(self,lp,rp,op,level=(0,0),lbuf=None,rbuf=None):
            #print(f"Unary, expr= {expr},op= {op.symbol}")
            #if self.is_number(expr):
            #    return op.intr(float(expr))
            #else:
            #return self.expr_eval1(self._parse(expr),op)
        xl,yl=level
        if op.acts_on=="left": 
            if not rp:
                if not lp:
                    if lbuf!=None:
                        return op.intr(lbuf)
                    else:
                        print(lp,rp,op.symbol,lbuf,rbuf,sep="|")
                        raise ValueError("Wrong input!")
                return op.intr(self._parse(lp,level=(xl,yl+1),lbuf=lbuf,rbuf=rbuf))
                                    
            else:
                #print(lp,rp,lbuf,rbuf)
                res=op.intr(self._parse(lp,level=(xl,yl+1),lbuf=lbuf,rbuf=None))
                #print("res",res)
                #assert lbuf==!None,f"No lbuf in {lp}!"
                    
                #print(lp,rp)
                return self._parse(rp,level=(xl+1/2**yl,yl+1),lbuf=res,rbuf=rbuf)
        else: #if op.acts_on=="right"
            if not lp:
                if not rp:
                    if rbuf!=None:
                        return op.intr(rbuf)
                    else:
                        print(lp,rp,op.symbol,lbuf,rbuf,sep="|")
                        raise ValueError("Wrong input!")
                return op.intr(self._parse(rp,level=(xl,yl+1),lbuf=lbuf,rbuf=rbuf))
            else: #if lp
                #assert lbuf==None,f"Conflicting lbuf in {lp}!"
                #print(rp,None,rbuf)
                res=op.intr(self._parse(rp,level=(xl,yl+1),lbuf=None,rbuf=rbuf))
                #print(lp,rp)
                return self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf,rbuf=res)

    def expr_eval2(self,lp,rp,op,level=(0,0),lbuf=None,rbuf=None):
        xl,yl=level
        #print(f"lp = {lp}, rp= {rp},op= {op.symbol}")
        #if self.is_number(lp) and self.is_number(rp):
            #print(f"returning {op.intr(float(lp),float(rp))}")
         #   return op.intr(float(lp),float(rp))
        #print("lrb:",lp,rp,lbuf,rbuf,sep="|")
        #print("bin",op.symbol,lp,rp,lbuf,rbuf)
        if ""  in [lp,rp]:
            if lp=="":
                
                if lbuf!=None:
                    self.partial_results[-1][3]=self.unmake_unique_text(op.symbol)    
                    return op.intr(lbuf,self._parse(rp,level=(xl+1/2**yl,yl+1),rbuf=rbuf))   
                elif self.fill_id and op.identity:
                    lp=str(op.id_rep)
                else:
                    raise ValueError("Wrong input!",lp,rp)
            elif rp=="":
                if rbuf!=None:
                    self.partial_results[-1][3]=self.unmake_unique_text(op.symbol+str(rbuf))    
                    return op.intr(self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf),rbuf)
                elif self.fill_id and op.identity:
                    rp=str(op.id_rep)
                else:
                    raise ValueError("Wrong input!")
        #return self.expr_eval2(self._parse(lp),self._parse(rp),op)
        self.partial_results[-1][3]=self.unmake_unique_text(op.symbol)    
        return op.intr(self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf),self._parse(rp,level=(xl+1/2**yl,yl+1),rbuf=rbuf))

    def eval_funcs(self,text,level=(0,0)):
        #print(f"eval_funcs got {text}")
        #for symb in self.funcs:
        for symb in self.pfuncs:
            if text.startswith(symb):
                
                if self.force_func_brackets:
                    if not any((text[len(symb):].strip()).startswith(lbra) for lbra,_ in self.brackets):
                        raise ValueError("The functional arguments are not enclosed by bracekts! Set force_func_brackets to False if you wish to ignore this")
                #print(f"Stripping brackets from: {text}")
                text=self.strip_brackets(text[len(symb):],aggresive=False)
                #if self.funcs[symb]._textual:
                #    return self.funcs[symb].intr(text)
                #print(text[len(symb):])
                #print(f"Stripped brackets: {text}")

                brack_inds=self._filter_brackets(text)
                #print(text,brack_inds)
                commas=self.find_all(self.mask_text(text,brack_inds),",")
                #print(f"Masking text and getting comma indices: {self.mask_text(text,brack_inds)}")
                expr_list=[]
                last_pos=0
                for comma_pos in commas:
                    expr_list.append(text[last_pos:comma_pos])
                    last_pos=comma_pos+1

                expr_list.append(text[last_pos:])
                arity=self.funcs[symb].arity
                arg_num=len(expr_list)
                
                if arity != "*":
                    if arg_num!=arity:
                        raise ValueError("Spatny pocet argumentu!") 
                xl,yl=level
                if arg_num%2==0:
                    xlevels=list(range(-(arg_num//2),0))+list(range(1,arg_num//2+1))
                else:
                    xlevels=list(range(-(arg_num//2),arg_num//2+1))
                return self.funcs[symb].intr(*(self._parse(el,level=(xl+xlevels[ind]/arg_num**yl,yl+1)) 
                                            for ind,el in enumerate(expr_list)))
        raise ValueError("Wrong input (are the functional arguments bracekted correctly?)")
        #print(f"eval_funcs is returning {text}")
        

    def is_final(self,text):
        if any(text.startswith(pl) for pl in self.pollist):
            return True
        try:
            float(text)
        except ValueError:
            
            return False
        else:
            return True
    
    def convert_to_final(self,text):
        for pl in self.pollist:
            if text==pl:
                return SPolynomial(pl,0,1)
        try:
            res=int(text)
        except ValueError:
            res=float(text)
        return res

    def simple_tree(self,part_res):
        part_res=sorted(part_res,key=lambda t: t[0][1])
        tree=[]#list((el[2],el[1]part_res)
        levels=[]
        
        for el in part_res:
            level=el[0][1]
            if level not in levels:
                levels.append(level)
                tree.append([])
            if el[2]=="sym":
                tree[level].append({"sym":el})
                for rel in part_res:
                    if rel[0]==el[0] and rel[2]=="res":
                        tree[level][-1]["res"]=rel
                        break
        #print(expr_by_levels)
        return tree
        
        

    def print_simple_tree(self,indtensity=5,row_height=1):
        indtensity=indtensity
        row_height=row_height
        base=3
        tree=self.simple_tree(self.partial_results)
        for exprs in tree:
            #print(exprs)
            #input()
            sorted_expr=sorted(exprs,key=lambda el: el["res"][0][1] )
            #print(sorted_expr)
            cp=0
            
            for el in sorted_expr:
                x=el["sym"][0][0]
                y=el["sym"][0][1]
                #pos=(base+x)
                pos=(base+round(x))
                true_space=(pos)*indtensity
            #    print(" "*(true_space-cp),end="")
                text="{0} [={1},:{2}]".format(el["sym"][1],el["res"][1],el["sym"][3] if el["sym"][3] else "")
             #   print(text,end="")
                cp=true_space+len(text)
                
                
            print("\n"*row_height,end="")
        
    def draw_parse_tree(self,pr=None,xc=0.5,yc=0.9,size0=20,adapt_size=False,zepr=None,save=False,filename=None):
        if pr is None:
            tree=self.simple_tree(self.partial_results)
        else:
            tree=self.simple_tree(pr)
        if save:
            matplotlib.use("Agg")
            #x0,y0=0.15,1.1
        else:
            matplotlib.use(self.backend)
            #matplotlib.use(self.backend)
            #x0,y0=0.2,1.1
        #print(matplotlib.get_backend())
        height=0.2
        width=0.2
        size_exp=1.1
        fig,ax=plt.subplots(figsize=(15,7))
        mng = plt.get_current_fig_manager()
        try:
            mng.window.state("zoomed")
        except AttributeError:
            pass
        ax.text(0.5,1.1,self.orig_text,size=size0,color="green",horizontalalignment="center",verticalalignment="center")

        for exprs in tree:
            
            #print(exprs)
            #input()
            sorted_expr=sorted(exprs,key=lambda el: el["res"][0][1] )
            #print(sorted_expr)
            replace_powers=re.compile("\^\(?(-?\d+)\)?")
            for el in sorted_expr:
                level=el["sym"][0][1]
                x=xc+el["sym"][0][0]*width
                y=yc-level*height
                #text1="{:^12}".format(el["sym"][1])
                #text2="{:^12.3f}".format(el["res"][1])
                text1=el["sym"][1]
                res=el["res"][1]
                if type(el["res"][1])==float:
                    text2=str(res) if type(res)==int else gen_obj.truncate_number(res,3)
                else:
                    text2=str(res) 
                text1=replace_powers.sub(lambda s: f"${{}}^{{{s[1]}}}$",text1)
                text2=replace_powers.sub(lambda s: f"${{}}^{{{s[1]}}}$",text2)
                #text1=re.sub("\^\(?(\d+)\)?",lambda s: f"${{}}^{{{s[1]}}}$",text1)
                #text2=re.sub("\^(\d+)",lambda s: f"${{}}^{{{s[1]}}}$",text2)

             #   print(x,y)
                if adapt_size:
                    size=size0*size_exp**(-level)
                else:
                    size=size0
                ax.text(x,y,text1,size=size,horizontalalignment="center",verticalalignment="center")
                ax.text(x,y+height/2,text2,size=size*0.8,color="red",horizontalalignment="center",verticalalignment="center")
                if el["sym"][3]:
                    x=xc+(el["sym"][0][0])*width
                    y=yc-(level+1)*height
              #      print(el["sym"][3],el["sym"][1],level)
                    #ax.text(x,y,"{:^12}".format(el["sym"][3]),size=size*0.8,color="blue")
                    ax.text(x,y,el["sym"][3],size=size,color="blue",horizontalalignment="center",verticalalignment="center")
            for spine in ax.spines.values():
                spine.set_visible(False)
            ax.xaxis.set_ticks([])        
            ax.yaxis.set_ticks([]) 
                #plt.plot(np.arange(0,1,0.1),np.arange(0,1,0.1))
            level+=1
        if save:
            plt.savefig(filename+".png")
            matplotlib.use("Agg")
        else:
            if self.backend=="Qt5Agg":
                plt.ion()
            plt.show()
                    

        #plt.close(fig)

    def draw_exprs(self,*expressions,verbose=False,**kwargs):
        for ind,expr in enumerate(expressions):
            self.parse(expr,draw=True,save=True,filename=f"../SavedFigures/Expr. # {ind+1}",**kwargs,verbose=verbose)

    def load_standard(self):
        self.def_func="V"
        self.add_operator("*",100,2,lambda x,y: x*y,identity={1})
        self.add_operator("/",110,2,lambda x,y: x/y,direction="left")
        self.add_operator("=",-10,2,self.solve)
        self.add_operator("==",-10,2,lambda x,y: "True" if x==y else "False")
        self.add_operator("+",10,2,lambda x,y: x+y,identity={0},unary_func=(lambda x: x,"right"))
        self.add_operator("-",12,2,lambda x,y: x-y,identity={0},direction="left",unary_func=(lambda x: -x,"right"))
        #self.add_operator("m",100,1,lambda x: -x,acts_on="right")
        #self.add_operator("^2",190,1,lambda x: x**2,acts_on="left")
        self.add_operator("#",-1,1,lambda x: x**2,acts_on="right")
    #  self.add_operator("~2",190,1,lambda x: x**2,acts_on="right")
        self.add_operator("^",200,2,lambda x,y: x**y)
        self.add_operator("**",200,2,lambda x,y: x**y)
        self.add_operator("e",1000,0,lambda: math.e)
        self.add_operator("pi",1000,0,lambda: math.pi) 
        self.add_operator("π",1000,0,lambda: math.pi)
        self.add_operator("i",1000,0,lambda: Complex(0,1))
        for card in ("♦","♣","♥","♠"):
            self.add_operator(card,1000,0,lambda s=card: Variable(s))    
        self.add_operator("Veronika Miháliková",1000,0,lambda: "♥♥♥")
        def ldiv(x,y): 
            if type(x) in [int,float,Monom,Quotient,Variable]:
                x=Polynomial(x)
            try:
                return x.longdiv(y)[0]
            except AttributeError:
                raise AttributeError("Both arguments must be polynomials!")
        def ldiv_modulo(x,y):
            if type(x) in [int,float,Monom,Quotient,Variable]:
                x=Polynomial(x)
            try:
                return x.longdiv(y)[1]
            except AttributeError:
                raise AttributeError("Both arguments must be polynomials!")

        def smart_deriv(obj,def_var=None,full_set=None):
            if isinstance(obj,(int,float)):
                return 0
            vars=obj.get_vars()
            if len(vars)==1:
                return obj.deriv(next(iter(vars)))
            else:
                return obj.grad()
            
        def grad(obj):
            if isinstance(obj,(int,float)):
                return Vector(0)
            else:
                return obj.grad()
        

        def deriv(obj,*variables):
            for variable in variables:
                if isinstance(obj,(int,float)):
                    return 0
                if not isinstance(variable,Variable):
                    variable=Variable(repr(variable))
                obj=obj.deriv(variable)
            return obj
        def simplify(obj):
            if not isinstance(obj,GeneralObject):
                return obj
            else:
                return obj.simplify()
        
        def dot(v,w):
            
            try:
                return v.dot(w)
            except AttributeError:
                raise ValueError("The left argument of the function 'dot' is not a vector!")
        def cross(v,w):
            try:
                return v.cross(w)
            except AttributeError:
                raise ValueError("The left argument of the function 'cross' is not a vector!")
            
        def curl(v):
            try:
                #print(v,type(v))
                return v.curl()
            except AttributeError:
                raise ValueError("The argument of the function 'curl' is not a vector!")
        
        def lap(obj):
            if isinstance(obj,(int,float)):
                return 0
            else:
                return obj.laplace()
        def divergence(v):
            if not isinstance(v,Vector):
                raise ValueError("The argument of the function 'div' must be a vector!")
            return v.divergence()
        def matmul(obj1,obj2):
            try:
                #print(obj1,obj2)
                return dot(obj1,obj2.T())
            except AttributeError:
                raise TypeError("The arguments must be vectors!")
        def norm(obj):
            if isinstance(obj,Vector):
                return obj.norm()
            elif isinstance(obj,(int,float)):
                return abs(obj)
            else:
                return gen_obj.Abs(obj).eval()
            
        def sum_obj(obj):
            try:
                return sum(obj)
            except TypeError:
                return obj
        def mul_obj(obj):
            try:
                return ft.reduce(mul,obj)
            except TypeError:
                return obj
        def trans(obj):
            try:
                return obj.T()
            except AttributeError:
                
                return obj
        def factorization(num):
            if type(num)==Vector:
                return Vector(*(factorization(comp) for comp in num))
            if isinstance(num,(Variable,Monom,Polynomial)):
                vars=num.get_vars()
                if len(vars)<1:
                    num=float(num)
                    num=int(num) if int(num)==num else num
                elif len(vars)>1:
                    raise NotImplementedError("Can't decompose multivariate polynomials yet")
                else:
                    use_complex=False
                  #  print(vars)
                    var=next(iter(vars))
                    x=Variable(var)
                    roots=self.solve(num,0,format=False)
                    
                    if not isinstance(roots,Vector):
                        roots=[roots]
                    if use_complex:
                        return Vector(*(x-root for root in roots))
                    else:
                        real_roots=[root for root in roots if (not isinstance(root,Complex)) or root.isreal()]
                        compl_roots=[root for root in roots if root not in real_roots]
                        
                        partners=[]
                        found=set()
                        for root in compl_roots:
                            if root not in found:
                                for root2 in compl_roots:
                                    if root is not root2 and root2 not in found:
                                        #print(root,root2,root.conj())
                                        #input()

                                        if root==root2.conj() or root==-root2.conj():
                                            
                                            partners.append((root,root2))
                                            found.add(root)
                                            found.add(root2)
                        #print(*(repr(el) for el in real_roots))
                        #print("rp",real_roots,compl_roots,partners)
                        return Vector(*(x-root for root in real_roots),*( ((x-r1)*(x-r2)).real.simplify() for (r1,r2) in partners))

            if not isinstance(num,int):
                raise TypeError("The argument must be a positive integer or a polynomial in one variable!")
            return Vector(*prime_factor.prime_fact(num))
        def choose(n1,n2):
            res=gen_obj.Choose(n1,n2).eval()
            if isinstance(res,float):
                if int(res)==res:
                    res=int(res)
            return res
        def factorial(num):
            try:
                return math.factorial(num)        
            except ValueError:
                return gen_obj.Gamma(num+1).eval()
        def flat(v):
            try:
                return v.flat()
            except AttributeError:
                return v
        
        self.add_operator(":",-5,2,ldiv)
        self.add_operator("%",-4,2,ldiv_modulo)
        self.add_operator("'",193,1,smart_deriv,acts_on="left")
        def extended(func,ext):
            def ext_func(x):
                if isinstance(x,(int,float)): 
                    return func(x)
                elif isinstance(x,GeneralObject):
                    return ext(x).eval()
            return ext_func
        self.add_operator("!",194,1,factorial,acts_on="left")
        self.add_function("sin",1,extended(math.sin,gen_obj.Sin))
        self.add_function("cos",1,extended(math.cos,gen_obj.Cos))
        self.add_function("asin",1,extended(math.asin,gen_obj.Asin))
        self.add_function("acos",1,extended(math.acos,gen_obj.Acos))
        #self.add_function("sqrt",1,extended(math.sqrt,gen_obj.Sqrt))
        self.add_function("sqrt",1,lambda x: gen_obj.Sqrt(x).eval())
        #self.add_function("√",1,extended(math.sqrt,gen_obj.Sqrt))
        self.add_function("√",1,lambda x: gen_obj.Sqrt(x).eval())
        self.add_function("exp",1,extended(math.exp,gen_obj.Exp))
        self.add_function("ln",1,extended(math.log,gen_obj.Ln))
        self.add_function("log",1,extended(math.log10,gen_obj.Log))
        self.add_function("tan",1,extended(math.tan,gen_obj.Tan))
        self.add_function("atan",1,extended(math.atan,gen_obj.Atan))
        self.add_function("abs",1,extended(abs,gen_obj.Abs))
        self.add_function("angle",2,lambda x,y: gen_obj.Angle(x,y).eval())
        self.add_function("V","*",Vector)
        self.add_function("dot",2,dot)
        self.add_function("cross",2,cross)
        self.add_function("Q","*",Quotient)
        self.add_function("grad",1,grad) 
        self.add_operator("×",99,2,cross)
        self.add_operator("·",99,2,dot)
        self.add_operator("∇",105,1,grad,acts_on="right")
        self.add_operator("∇·",101,1,divergence,acts_on="right")
        self.add_operator("∇×",102,1,curl,acts_on="right")
        self.add_operator("Δ",104,1,lap,acts_on="right")
        self.add_function("sinh",1,extended(math.sinh,gen_obj.Sinh))
        self.add_function("cosh",1,extended(math.cosh,gen_obj.Cosh))
        self.add_function("tanh",1,extended(math.tanh,gen_obj.Tanh))
        self.add_function("asinh",1,extended(math.asinh,gen_obj.Asinh))
        self.add_function("acosh",1,extended(math.acosh,gen_obj.Acosh))
        self.add_function("atanh",1,extended(math.atanh,gen_obj.Atanh))
 
        #self.add_function("∇",1,grad)
        self.add_function("curl",1,curl)
        self.add_function("rot",1,curl)
        self.add_function("div",1,divergence)
        self.add_function("lap",1,lap)
        self.add_function("matmul",2,matmul)
        self.add_function("der","*",deriv)
        self.add_function("simp",1,simplify)
        self.add_function("trans",1,trans)
        self.add_function("decomp",1,factorization)
        self.add_function("norm",1,norm)
        self.add_function("sum",1,sum_obj)
        self.add_function("mul",1,mul_obj)
        self.add_function("flat",1,flat)
        self.add_function("choose",2,choose)
        self.add_brackets("()")
        self.add_brackets("{}")
        self.add_brackets("[]")
    
    def solve(self,lhs,rhs,format=None,fractions=None):
        if format is None:
            format=self.solformat
        if fractions is None:
            fractions=self.fractions
        """ def make_whole(x,y):
            for _ in range(5):
                if int(x)==x and int(y)==y:
                    x,y=int(x),int(y)
                    break
                x,y=x*10,y*10
            return x,y"""
        """ # Už máme lepší metody, jen by to bylo matoucí            
        if type(rhs) is Vector:
            if type(lhs) is Vector:
                print(lhs.dim,rhs.dim)
                if lhs.dim==rhs.dim:
                    return Vector(*(self.solve(l,r,format,fractions) for (l,r) in zip(lhs,rhs)))
                else:
                    raise ValueError("LHS and RHS must have the same dimension!")
            else:
                    return Vector(*(self.solve(lhs,r,format,fractions) for r in rhs))
        if type(lhs) is Vector:
                    return Vector(*(self.solve(l,rhs,format,fractions) for l in lhs))
        """
        if isinstance(lhs,Quotient):
            lhs,rhs=lhs.p,rhs*lhs.q
        if isinstance(rhs,Quotient):
            lhs,rhs=lhs*rhs.q,rhs.p

        #lhs=Polynomial(lhs)
        #rhs=Polynomial(rhs)
        lhs,rhs=lhs-rhs,0
        #print(lhs,rhs,repr(lhs),repr(rhs))
        #print("lhs...",lhs,repr(lhs))
        if isinstance(lhs,Complex):
            if lhs.isreal():
                lhs=lhs.real
            else:
                raise NotImplementedError("Can't solve equations with complex coefficients yet")
        lhs=Polynomial(lhs)
        #print("lhs...",lhs,repr(lhs))
        if lhs.order>4:
            return appr_polsolve.absolve(lhs)
            #raise NotImplementedError("Rovnice vetsiho nez ctvrteho radu zatim neumime resit.")
        else:            
            #print(len(lvar),len(rvar))
            #if len(lvar)==len(rvar)==0:
            if (not lhs.varset):
                
                if lhs!=0:
                    return "Never true"
                else:
                    return "Always true"
            else:
                #print("1")
                #print(lhs,lhs.varset)
                lvar=next(iter(lhs.varset))
                if len(lhs.varset)>1:
                    raise ValueError("Rovnice musi byt ve stejnych promennych, soustavy zatim neumime resit.")

            #print(lvar)
            a0,a1,a2,a3,a4=lhs.get_coefs(lvar,at_least=4)#.values()
            print("coefs:",a0,a1,a2,a3,a4)
           # print(a1,b1,c1)
           # print(a2,b2,c2)
            if a4==0:
                if a3==0:
                    if a2==0:
                        return solver.solve_linear(a1,a0,fractions=fractions)
                    else:
                        return solver.solve_quadratic(a2,a1,a0,format=format,fractions=fractions,use_complex=self.solve_w_complex)
                else:
                    return solver.solve_cubic(a3,a2,a1,a0,fractions=fractions,use_complex=self.solve_w_complex)
            else:
                return solver.solve_quartic(a4,a3,a2,a1,a0,fractions=fractions,use_complex=self.solve_w_complex)

    def solve2(self,lhs,rhs):
        """ def make_whole(x,y):
            for _ in range(5):
                if int(x)==x and int(y)==y:
                    x,y=int(x),int(y)
                    break
                x,y=x*10,y*10
            return x,y"""
        if isinstance(lhs,Quotient):
            lhs,rhs=lhs.p,rhs*lhs.q
        if isinstance(rhs,Quotient):
            lhs,rhs=lhs*rhs.q,rhs.p

        lhs=Polynomial(lhs)
        rhs=Polynomial(rhs)
        if lhs.order>2 or rhs.order>2:
            raise NotImplementedError("Rovnice vetsiho nez druheho radu zatim neumime resit.")
        else:
            
            
            #print(len(lvar),len(rvar))
            #if len(lvar)==len(rvar)==0:
            if (not lhs.varset) and (not rhs.varset):
                
                if lhs!=rhs:
                    return "Never true"
                else:
                    return "Always true"
            else:
                #print("1")
               
                if not lhs.varset:
                    rvar=next(iter(rhs.varset))
                    lvar=rvar
                elif not rhs.varset:
                    lvar=next(iter(lhs.varset))
                    rvar=lvar
                else:
                    lvar=next(iter(lhs.varset))
                    rvar=next(iter(rhs.varset))
                if lvar!=rvar or len(lhs.varset)>1 or len(rhs.varset)>1 :
                    raise ValueError("Rovnice musi byt ve stejnych promennych, soustavy zatim neumime resit.")

            #print(lvar,rvar)
            c1,b1,a1=lhs.get_coefs(lvar,at_least=2)#.values()
            c2,b2,a2=rhs.get_coefs(lvar,at_least=2)#.values()
           # print(a1,b1,c1)
           # print(a2,b2,c2)
            if a1==a2:
                num=c2-c1
                den=b1-b2
                
                if den==0:
                    if num==0:    
                        return "Always true"
                    else:
                        return "No solution"
                else: 
                    if self.fractions:
                        #print("fractions")
                        #num,den=make_whole(num,den)
                        return Quotient(num,den)
                    else:
                        return num/den if num%den else int(num//den)
            else:
                a=a1-a2
                bh=(b1-b2)/2
                c=c1-c2
                D=bh**2-a*c
                #print(a,bh,c,D)
                if D<0:
                    return "No solution"
                elif D==0:
                    return -bh/(a)
                else:
                    sqrtD=math.sqrt(D)
                    if self.fractions:
                        #print("Fractions")
                        #print("Got res: ",sqrtD-bh,-sqrtD-bh,a,Quotient(sqrtD-bh,a),Quotient(-sqrtD-bh,a))
                        #return (Vector(Quotient(sqrtD-bh,a),Quotient(-sqrtD-bh,a)))
                        if int(sqrtD)==sqrtD or int(1/sqrtD)==1/sqrtD:
                            num1,num2,den=-bh+sqrtD,-bh-sqrtD,a
                         #   print(num1,num2,den)
                            #inum1,iden1=make_whole(num1,den)
                            #inum2,iden2=make_whole(num2,den)
                            #return Vector(Quotient(inum1,iden1),Quotient(inum2,iden2)) 
                            return Vector(Quotient(num1,den),Quotient(num2,den)) 
                        
                        D=gen_obj.truncate_number(D)
                        #num,den=make_whole(-bh,a)
                        #vertex=Quotient(num,den)
                        vertex=Quotient(-bh,a)
                        #print(vertex,repr(vertex),vertex.p.isconst,vertex.q.isconst)
                        if vertex==0: 
                                    vertex=""
                        if a<0:
                            a=-a
                        if a==1:
                            return (Vector((vertex,f"+√({D})"),(vertex,f"-√({D})")))
                        else:
                            return (Vector((vertex,f"+√({D})/{a}"),(vertex,f"-√({D})/{a}")))
                    else:
                        return (Vector(sqrtD,-sqrtD)-bh)*(1/a)

    def longdiv(self,s1,s2=None,draw=False,implicit_conversion=True,**kwargs):
        if s2==None:
            #print(s1,"|",s2)

            lind=s1.find("|")
            if lind==-1:
                lind=len(s1)
            col_num=len([el for el in self.find_all(s1,":") if el<lind])
            
            if col_num!=1:
                raise ValueError("The expression must contain exactly  one ':' sign!")
            else:
                dind=s1.find(":")
                s1,s2=s1[:dind],s1[dind+1:]
             #   print(s1,"|",s2)
                if any(t.strip()=="" for t in (s1,s2)):
                    raise ValueError("There have to non-empty expressions on each side of the division sign!")
                
                if "|" in s2:
                    _,sub,*_=s2.split("|")
                    s1+=" | "+sub

        pol1=self.parse(s1,implicit_conversion=implicit_conversion,verbose=self.verbose,**kwargs)
        pol2=self.parse(s2,implicit_conversion=implicit_conversion,verbose=self.verbose,**kwargs)
        if isinstance(pol1,(int,float,Variable,Monom,Quotient)):
            pol1=Polynomial(pol1)
        if isinstance(pol2,(int,float,Variable,Monom,Quotient)):
            pol2=Polynomial(pol2)
        
        res,zbytek,partial=pol1.longdiv(pol2)
        #print(partial)
        spartial=list(map(lambda t: tuple(map(str,t)),partial))
        if draw:
            self.draw_ldiv(spartial,str(pol2),**kwargs)
        return str(res),str(zbytek),list(map(lambda t: tuple(map(str,t)),partial))
    
    def draw_ldiv(self,partial,pol2,use_colors=True,color_mode=1,save=False,filename=None,size=18):
        assert len(partial)>0,"Chybi mezivysledky!"
    
        if save:
            matplotlib.use("Agg")
            x0,y0=0.15,1.1
        else:
            matplotlib.use(self.backend)
            #matplotlib.use(self.backend)
            x0,y0=0.2,1.1
  
        fig,ax=plt.subplots(figsize=(15,7))
        mng = plt.get_current_fig_manager()
        try:
            mng.window.state("zoomed")
        except AttributeError:
            pass
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.xaxis.set_ticks([])        
        ax.yaxis.set_ticks([]) 
        def subpow(text): return re.sub("\^\(?(-?\d+)\)?",lambda s: f"${{}}^{{{s[1]}}}$",text)
        nice_partial=[(subpow(text1),subpow(text2)) for text1,text2 in partial ]
        #print(nice_partial)
        #ax.text(0.5,1.1,self.orig_text,size=size0,color="green",horizontalalignment="center",verticalalignment="center")
        font = {'family' : 'monospace',
        'weight' : 'normal',
        'size'   : size}
        matplotlib.rc('font', **font)
        #print(partial)
        nice_lhs=nice_partial[0][0]
        adjl=len(list(self.find_all(nice_lhs,"^")))
        adjconst=7
        if use_colors:
            colors=["blue","green","orange","darkmagenta"]*100
        else:
            colors=["black"]*400   
        #xlevel0=len("{0} : {1} = ".format(lhs,pol2))
        pol2=subpow(str(pol2))
        adjm=len(list(self.find_all(pol2,"^")))
        xlevel0=len(" : {0} = ".format(pol2))-adjm*7
        xlevel=xlevel0
        respos=0
        toplevel=0
        ylevel=toplevel
        height=0.1
        #size=15
        #print("{0} : {1} = {2}".format(lhs,pol2,rhs))
        if color_mode==1:
            lcolor=colors[0]
        elif color_mode==2:
            lcolor="black"
        ax.text(x0,y0+ylevel*height,"{0}".format(nice_lhs),size=size,color=lcolor,
                horizontalalignment="right",verticalalignment="center")
        ax.text(x0,y0+ylevel*height," : {0} = ".format(pol2),size=size,color="black",
                horizontalalignment="left",verticalalignment="center")
        ylevel+=1
        
        last_color=colors[0]
        if color_mode==1:
            colors=colors[1:]
        elif color_mode==2:
            last_color=colors[0]
            colors=colors
        if len(partial)==1:
            ax.text(x0,y0-toplevel*height," "*xlevel+str(0),size=size,color="black",
                    horizontalalignment="left",verticalalignment="center") 
        for (r,s),color in zip(nice_partial[1:],colors):
            if color_mode==1:
                lcolor=color
                rcolor=last_color
            elif color_mode==2:
                lcolor=color
                rcolor=color
            #print(r,s,"{0:>{ljust}}".format(r,ljust=ljust)) "x{0:>{ljust}}".format(r,ljust=ljust)
            adjl=len(list(self.find_all(r,"^")))
            ax.text(x0,y0-ylevel*height,"{0}".format(r),size=size,color=lcolor,
            horizontalalignment="right",verticalalignment="center")
            adjl=len(list(self.find_all(s,"^")))
            ax.text(x0,y0-toplevel*height," "*xlevel+" {0}".format(s[respos:]),size=size,color=rcolor,
                    horizontalalignment="left",verticalalignment="center")            
            respos=len(s)
            #print(respos)
            xlevel=xlevel0+respos-adjl*adjconst
            last_color=color
            ylevel+=1


        #if respos==0:
        #  ax.text(x0,y0+toplevel," "*xlevel+" {}".format(0),size=size,color=lcolor,horizontalalignment="center",verticalalignment="center")            
        if save:
            plt.savefig(filename+".png",bbox_inches='tight')
            matplotlib.use(self.backend)
                

        else:
            if self.backend=="Qt5Agg":
                plt.ion()
            plt.show()
        #plt.close(fig)
        

    def ldiv_and_save(self,*exprlist,**kwargs):
        for ind,expr in enumerate(exprlist):
            
            self.longdiv(expr,draw=True,save=True,filename=f"../SavedFigures/Deleni #{ind+1}",**kwargs)



    #import numpy
    def plot(self,*objs,llim=None,ulim=None,pden=None,style="",save=False,filename="Plot.png",polar=None,use_grid=None,contours=None,hold=False,anim=True,**at):
        
#        hold=True
        if save:
            matplotlib.use("Agg")
        else:
           #matplotlib.use(self.backend)
           matplotlib.use(self.backend)
        
        x0,x1=llim,ulim

        if all(isinstance(obj,(int,float,complex)) or not obj.get_vars() for obj in objs): #konstanty (hlavně na vypisování kořenů)
            real,imag,names=[],[],[]
            for obj in Vector(*objs).flat():
                obj=Complex(obj).eval()
                real.append(obj.real);imag.append(obj.imag);names.append(str(obj.regularized()))
            x0=min(real) if x0 is None else x0;x1=max(real) if x1 is None else x1;
            if x0>x1:
                x0,x1=x1,x0
            x0=x0-0.15*(x1-x0);x1=x1+0.15*(x1-x0)
            tol=Complex(None).tol
            print(x1,x0)
            if (x1-x0)<tol:
                x0-=1
                x1+=1

            y0=min(imag);y1=max(imag) 
            #print(x0,y0)
            y0=y0-0.15*abs(y1-y0);y1=y1+0.15*abs(y1-y0)
          #  if (y1-y0)<Complex.tol:
           #     y0-=1
           #     y1+=1
            xdif=x1-x0
            if y1-y0<1/7*xdif:
                y0,y1=(y0+y1)/2-1/14*xdif,(y1+y0)/2+1/14*xdif
            ydif=y1-y0
            if x1-x0<1/7*ydif:
                x0,x1=(x0+x1)/2-1/14*ydif,(x1+x0)/2+1/14*ydif
            xdif,ydif=x1-x0,y1-y0
            #print(xdif,ydif,x0,y0)
            fig,ax=plt.subplots()
            def sign(x):
                if x>0:
                    return 1
                elif x<0:
                    return -1
                else:
                    return 0
            for r,i,name in zip(real,imag,names):
                ax.plot(r,i,"o")
                xtext,ytext=r-0.05*(x1-x0)*sign(r),i-0.05*(y1-y0)*sign(i)
                if abs(xtext)<1/14*(xdif):
                    xtext+=1/14*(xdif)
                if abs(ytext)<1/14*(ydif):
                    ytext+=1/14*(ydif)
                ax.annotate(name,(r,i),ha="center",xytext=(xtext,ytext),xycoords="data")
            ax.set_xlim(x0,x1);ax.set_ylim(y0,y1)
            ax.axhline(0,lw=1,color="black")
            ax.axvline(0,lw=1,color="black")
            plt.gca().set_aspect("equal")
            if use_grid!=False:
                plt.grid()
            plt.show()
            return 
       
        varset=set() #for label
        
        new_objs=[]
        names=[]
        ind=0
        rinds=[]
        iinds=[]
        for ind,obj in enumerate(objs):
            if isinstance(obj,GeneralObject) and obj.contains_complex():
                new_objs.append(obj)
                new_objs.append(obj)
                rinds.append(ind)
                iinds.append(ind+1)
                names.append("Real part of "+str(obj))
                names.append("Imaginary part of "+str(obj))
      
                #print(obj.real,obj.imag,objs)
            else:
                new_objs.append(obj)
                names.append(str(obj))
        objs=new_objs
        for obj in objs:
           
            
            if isinstance(obj,Polynomial):
                if x0==None==x1:
                    try:
                        
                        roots=self.solve(obj,0,format=False,fractions=False)
                        try:
                            iter(roots)
                        except TypeError:
                            roots=[roots]
                        realroots=[]
                        for root in roots:
                            if isinstance(root,GeneralObject):
                                root=root.eval()
                            if isinstance(root,(int,float)): 
                                realroots.append(root)
                            if isinstance(root,Complex) and root.isreal():
                                realroots.append(root.real)
                        #print(realroots)
                        if realroots:
                            if use_grid is None:
                                #print("using grid")
                                use_grid=True

                            x0=min(realroots+[x0]) if x0 is not None else min(realroots)
                            x1=max(realroots+[x1]) if x1 is not None else max(realroots)
                            if x0==x1:
                                if x0<0:
                                    if x0<-1:
                                        x1=-x0
                                    else:
                                        x0,x1=-1,1
                                else:
                                    if x0>1:
                                        x0,x1=-x0,x0
                                    else:
                                        x0,x1=-1,1
                            else:
                                d=x1-x0
                                x0=x0-d/3
                                x1=x1+d/3
                    except (ValueError,NotImplementedError):
                        pass
                
                        
                    #print(x0,x1)
        try:
            x0=x0[0]
        except TypeError:
            pass
        try:
            x1=x1[0]
        except TypeError:
            pass
          
        
        
        

        is_open=False
        
        parinds=[]
        for ind,obj in enumerate(objs):
            if isinstance(obj,GeneralObject):
                obj=obj.eval(**at)
            if not isinstance(obj,GeneralObject):
                obj=Monom(obj)
            vars=obj.get_vars()
            if len(vars)==0:
                vars="x"
            if len(vars)>1:         
                if pden is None:       
                    ps=None
                else:
                    ps=pden if pden<250 else 250
                if ind not in iinds:
                    self.plot2(obj,llim=llim,ulim=ulim,pden=ps,style=style,save=save,filename="2DPlot",use_grid=use_grid,polar=polar,contours=contours,**at)
                continue
                #raise NotImplementedError("Can only plot functions of a single variable. For vector fields, complex functions and functions of two variables, use mplot")
            else:
                var=next(iter(vars))
                if var in ("f","fi","Φ","α","β","γ","φ"):
                    if polar is None:
                        polar=True
            if not is_open:
                
                if polar:
                    if hold:
                        fig=plt.gcf()
                    else:
                        fig=plt.figure()
                    ax = fig.add_subplot(111, projection='polar')
                    if x0 is None:
                        x0=0
                    if x1 is None:
                        x1=2*math.pi
                    plt.gca().set_aspect("equal")
    
                else:
                    if hold:
                        fig,ax=plt.gcf(),plt.gca()
                    else:
                        fig,ax=plt.subplots()
                    if all(isinstance(comp,Vector) for comp in objs):
                        if x0 is None:
                            x0=0
                        if x1 is None:
                            x1=2*math.pi

                    else:
                        if x0 is None:
                            x0=-1
                        if x1 is None:
                            x1=1
                if x0>x1:
                    x0,x1=x1,x0
                is_open=True
            if pden==None:
                pden=1000
            var=next(iter(vars))
            varset.add(var)
            grid=[x0+(x1-x0)*i/pden for i in range(pden)] #np.linspace(x0,x1,)
            vals=[]
            #print(ind,rinds,iinds)
            for point in grid:
                try:
                    newval=obj.eval(**{**{var:point},**at})
                    #print(newval)
                    if ind in rinds:
                        try:
                            newval=newval.real
                        except AttributeError:
                            pass
                    elif ind in iinds:
                        try:
                            newval=newval.imag
                        except AttributeError:
                            newval=0
                        
                    #print("real:",newval)
                except ZeroDivisionError:
                    newval=None
                vals.append(newval)
            print(names[ind])
            leg=re.sub("\^\((-?\d+)\)",lambda s: f"${{}}^{{{s[1]}}}$",names[ind])
            leg=re.sub("\^\s*(-?\d+\s*)",lambda s: f"${{}}^{{{s[1]}}}$",leg)
            #leg=re.sub("\^\(?(-?\d+\)?)",lambda s: f"${{}}^{{{s[1]}}}$",str(obj))
            #leg=re.sub("\^\((-?\d+)\)",lambda s: f"${{}}^{{{s[1]}}}$",str(obj))
            if type(obj) is Vector: #parametric plot
                if polar:
                    yvals,xvals=zip(*vals)    
                else:
                    xvals,yvals=zip(*vals)
                if anim is None:
                    anim=True
                if anim:
                    parinds.append((names[ind],xvals,yvals))
                ax.plot(xvals,yvals,style,label=str(ind+1)+": "+leg+f", {var} $\in [ {x0:4g} , {x1:4g} ]$")
                if len(varset)==1:
                    if var.strip() not in ("x","y"):
                        ax.set_xlabel("x")  
                        ax.set_ylabel("y")  
                    elif var.strip()=="x":
                        ax.set_xlabel("y")  
                        ax.set_ylabel("z")  
                    elif var.strip()=="y":
                        ax.set_xlabel("x")  
                        ax.set_ylabel("z")  
            else:
                if anim:
                    parinds.append((names[ind],grid,vals))
                ax.plot(grid,vals,style,label=str(ind+1)+": "+leg)
                ax.set_xlabel(", ".join(str(var) for var in sorted(varset)))
            ax.legend()
            
            #plt.axhline(y=0)
        if is_open:

            if anim:
                self.par_anim(parinds,x0,x1,polar=polar,style=style)
            if use_grid is None:
                use_grid=False
            if use_grid:
                plt.grid()
            #animace:
            if save:
                plt.savefig(filename)
            else:
                if self.backend=="Qt5Agg":
                    plt.ion()
                #plt.ion()
                plt.show()      
    
    def plot2(self,*objs,llim=None,ulim=None,pden=None,style="",save=False,filename="2DPlot",use_grid=None,contours=None,polar=None,**at):
        
      
        if save:
            matplotlib.use("Agg")
        else:
            #matplotlib.use(self.backend)
            matplotlib.use(self.backend)
        
        try:
            x0,y0=llim
        except TypeError:
            x0=y0=llim
        try:
            x1,y1=ulim
        except TypeError:
            x1=y1=ulim
        
        if style:
            cmap=style
        else: 
            cmap="plasma"
        
        

                
        for obj in objs:
            if isinstance(obj,GeneralObject):
                obj=obj.eval(**at)
            if not isinstance(obj,GeneralObject):
                obj=Monom(obj)
            
            vars=obj.get_vars()
            

            lv=len(vars)

            if lv==0:
                var1,var2="x","y"
            elif lv==1:
                
                t=next(iter(vars))
                #print(t)
                var1,var2= (t,"y") if t!="y" else ("x","y")
                #print("polar...",polar)
                if polar is None:
                    if t=="r":
                        polar=True
                    elif t in ("f","fi","Φ","α","β","γ","φ"):
                        polar=True
                        var1,var2=var2,var1
                #var1,var2=  "y","z"
                
            elif lv==2:
                ivars=iter(vars)
                var1,var2=ivars
                if polar is None:
                    if var2=="x" or var1=="y":
                        var1,var2=var2,var1
                    if any(symb in vars for symb in ("r","f","fi","Φ","α","β","γ","φ")):
                        polar=True
                        if var2=="r" or var1 in ("f","fi","Φ","α","β","γ","φ"):
                            var1,var2=var2,var1
            else:
                raise NotImplementedError("Can only plot functions of at most two variables")

            if polar:
                if x0 is None:
                    x0=0
                if x1 is None:
                    x1=1
                if y0 is None:
                    y0=0
                if y1 is None:
                    y1=2*math.pi
            else:
                if x0 is None:
                    x0=-1
                if x1 is None:
                    x1=1
                if y0 is None:
                    y0=-1
                if y1 is None:
                    y1=1
            if x1<x0:
                x0,x1=x1,x0
            if y1<y0:
                y0,y1=y1,y0

            
            iscomplex=False
            isvector=False
            #if isinstance(obj,Complex):
            if obj.contains_complex():
                    iscomplex=True
                    if contours==None:
                        contours=True
            elif isinstance(obj,Vector):
                if obj.dim>3:
                    raise NotImplementedError("Can't plot vector fields in more than two dimensions")
                try:
                    obj1,obj2=(comp if isinstance(comp,GeneralObject) else Monom(comp) for comp in obj)
                except ValueError:
                    obj1=next(iter(obj))
                    obj1,obj2=obj1 if isinstance(obj1,GeneralObject) else Monom(obj1),Monom(0)
                isvector=True
                if contours==None:
                    contours=False
            if contours==None:
                contours=True

            leg=re.sub("\^\((-?\d+)\)",lambda s: f"${{}}^{{{s[1]}}}$",str(obj))
            leg=re.sub("\^\s*(-?\d+\s*)",lambda s: f"${{}}^{{{s[1]}}}$",leg)
            #print(x0,x1,y0,y1)
            if pden is None:
                pden=125 if iscomplex else 250
            xgrid,ygrid=np.meshgrid(np.linspace(x0,x1,pden),np.linspace(y0,y1,pden))
            vals=np.array([ [(xgrid[i,j],ygrid[i,j]) for i,_ in enumerate(xgrid)] for j,_ in enumerate(xgrid[0])] )
            

            if not isvector:
                if iscomplex:
                    if not isinstance(obj,Complex):
                        obj=Complex(obj)
                    norm,ang=np.empty(np.shape(xgrid)),np.empty(np.shape(xgrid))
                    onorm=obj.norm() if isinstance(obj.norm(),GeneralObject) else Monom(obj.norm())
                    oangle=obj.angle() if isinstance(obj.angle(),GeneralObject) else Monom(obj.angle())
                    for i,_ in enumerate(vals):
                        for j,_ in enumerate(vals[:,0]):
                            try:
                                norm[j,i]=onorm.eval(**{**{var1:vals[i,j][0],var2:vals[i,j][1]},**at})
                                ang[j,i]=oangle.eval(**{**{var1:vals[i,j][0],var2:vals[i,j][1]},**at})
                            except ZeroDivisionError:
                                norm[j,i]=None
                                ang[j,i]=None

                    pref=("Absolute value","Phase")

                    for ind,valgrid in enumerate((norm,ang)):
                        fig,ax=plt.subplots()
                        if ind==1:
                            #backend = matplotlib.get_backend()
                            if self.backend=="Qt5Agg":
                                mngr = plt.get_current_fig_manager()
                                geom = mngr.window.geometry()
                                x,y,dx,dy = geom.getRect()
                                mngr.window.setGeometry(x+dx/2, y+dy/2, dx, dy)
                        
                        fig.suptitle("{3} of $f({0},{1}) ={2}$".format(var1,var2,obj,pref[ind]))
                        if polar:
                            plt.axes(projection='polar')
                            im=plt.pcolormesh(ygrid,xgrid,valgrid,cmap=cmap)
                            cbar=plt.colorbar(im)
                            if contours:
                                cset=np.linspace(np.min(valgrid),np.max(valgrid),20)
                                try:
                                    cnt=plt.contour(valgrid.transpose(),cset,linewidths=1,extent=(y0,y1,x0,x1),colors="black")
                                    cbar.add_lines(cnt)
                                except ValueError as e:
                                    if str(e)=="Contour levels must be increasing":
                                        pass
                                    else:
                                        raise
                        else:
                            im=plt.pcolormesh(xgrid,ygrid,valgrid,cmap=cmap)
                            cbar=plt.colorbar(im)
                            if contours:
                                cset=np.linspace(np.min(valgrid),np.max(valgrid),20)
                                try:
                                    cnt=plt.contour(valgrid,cset,linewidths=1,extent=(x0,x1,y0,y1),colors="black")
                                    cbar.add_lines(cnt)
                                except ValueError as e:
                                    if str(e)=="Contour levels must be increasing":
                                        pass
                                    else:
                                        raise
                        ax.set_aspect("equal")
                        if save:
                            plt.savefig(filename+"_"+pref[ind]+".png")
                    
                else:
                    
                    fig,ax=plt.subplots()
                    valgrid=np.empty(np.shape(xgrid))
                    for i,_ in enumerate(vals):
                        for j,_ in enumerate(vals[:,0]):
                            try:
                                valgrid[j,i]=obj.eval(**{**{var1:vals[i,j][0],var2:vals[i,j][1]},**at})
                                #print(obj,valgrid[j,i])
                                #input()
                            except ZeroDivisionError:
                                #print("error",obj,valgrid[j,i])
                                valgrid[j,i]=None
                    
                    if polar:
                        plt.axes(projection='polar')
                        im=plt.pcolormesh(ygrid,xgrid,valgrid,cmap=cmap)
                        cbar=plt.colorbar(im)
                        if contours:
                            cset=np.linspace(np.min(valgrid),np.max(valgrid),20)
                            cnt=plt.contour(valgrid.transpose(),cset,linewidths=1,extent=(y0,y1,x0,x1),colors="black")
                            cbar.add_lines(cnt)
                    else:
                        im=plt.pcolormesh(xgrid,ygrid,valgrid,cmap=cmap)
                        cbar=plt.colorbar(im)
                        if contours:
                            cset=np.linspace(np.min(valgrid),np.max(valgrid),20)
                            cnt=plt.contour(valgrid,cset,linewidths=1,extent=(x0,x1,y0,y1),colors="black")
                            cbar.add_lines(cnt)
                    
                    
                    plt.title("Plot of f({0},{1}) ={2}".format(var1,var2,leg))

            else:
               
                fig,ax=plt.subplots()
                valgrids=[np.empty(np.shape(xgrid)),np.empty(np.shape(xgrid))]
                for i,_ in enumerate(vals):
                    for j,_ in enumerate(vals[:,0]):
                        try:
                            valgrids[0][j,i]=obj1.eval(**{**{var1:vals[i,j][0],var2:vals[i,j][1]},**at})
                            valgrids[1][j,i]=obj2.eval(**{**{var1:vals[i,j][0],var2:vals[i,j][1]},**at})
                        except ZeroDivisionError:
                            valgrid[j,i]=None
                #print(var1,var2,np.max(xgrid),np.max(ygrid),xgrid[0]])        
                


                
                if polar:
                    plt.axes(projection='polar')
                    #valgrids[0],valgrids[1]=valgrids[1],valgrids[0]#*ygrid
                    norm=np.sqrt(valgrids[0]**2+valgrids[1]**2)
                    im=plt.pcolormesh(ygrid,xgrid,norm,cmap="plasma")
                    
                    lx,ly=np.shape(ygrid)
                    decim=30
                    dy,dx=ly//decim,lx//decim
                    dxgrid,dygrid=[xgrid[::dx,::dy],ygrid[::dx,::dy]]
                    dvalgrids=[valgrids[0][::dx,::dy],valgrids[1][::dx,::dy]]
                    plt.quiver(dygrid,dxgrid,dvalgrids[0]*np.cos(dygrid)-dvalgrids[1]*np.sin(dygrid), dvalgrids[0]*np.sin(dygrid)+dvalgrids[1]*np.cos(dygrid))
                    if contours:
                        cset=np.linspace(np.min(norm),np.max(norm),20)
                        cnt=plt.contour(norm.transpose(),cset,extent=(y0,y1,x0,x1))
                else:
                    norm=np.sqrt(valgrids[0]**2+valgrids[1]**2)
                    

                    im=plt.pcolormesh(xgrid,ygrid,norm,cmap=cmap)
                    cbar=plt.colorbar(im)
                    lx,ly=np.shape(ygrid)
                    decim=30
                    dy,dx=ly//decim,lx//decim
                    plt.quiver(xgrid[::dx,::dy],ygrid[::dx,::dy],valgrids[0][::dx,::dy],valgrids[1][::dx,::dy])
                    if contours:
                        cset=np.linspace(np.min(norm),np.max(norm),20)
                        cnt=plt.contour(norm,cset,extent=(x0,x1,y0,y1))
        
        
            
                plt.title("Plot of f({0},{1}) ={2}".format(var1,var2,leg))
            #plt.title(r"\textbf{46545646}")
            plt.xlabel(var1)
            plt.ylabel(var2)
            plt.gca().set_aspect("equal")
            if use_grid is None:
                use_grid=False
            if use_grid:
                plt.grid("on")
        
        if save:
            plt.savefig(filename+".png")
        else:
            if self.backend=="Qt5Agg":
                plt.ion()
            plt.show()      
            
    def par_anim(self,data,t0,t1,polar=False,style=""):
        from matplotlib.animation import FuncAnimation
        #matplotlib.use(self.backend)

        if not data:
            return
        
        if polar:
            fig=plt.figure()
            #t1=2*math.pi
            ax = fig.add_subplot(111, projection='polar')
        else:
            fig,ax=plt.subplots()
        #backend = matplotlib.get_backend()
        if self.backend=="Qt5Agg":
            mngr = plt.get_current_fig_manager()
            geom = mngr.window.geometry()
            x,y,dx,dy = geom.getRect()
            mngr.window.setGeometry(x+dx/2, y+dy/2, dx, dy)
        
        names,xdata,ydata=zip(*data)
        max_t=t1-t0
        len_t=len(xdata[0])
        dt=max_t/len_t*1000
        lines=[ax.plot([],[],style,label=name)[0] for name in names]
        
        #x_min,x_max=0,2*math.pi
        if polar:
             x_min,x_max=0,2*math.pi
        else:
            x_min=ft.reduce(min,[np.min(ar) for ar in xdata])
            x_max=ft.reduce(max,[np.max(ar) for ar in xdata])
        #if polar:
        #    y_min,y_max=0,2*math.pi
        #else:
        y_min=ft.reduce(min,[np.min(ar) for ar in ydata])
        y_max=ft.reduce(max,[np.max(ar) for ar in ydata])
        #print(x_maxes)
        #print(lines)
        #xlim=x_max#200
        #ylim=y_max#50
        #x_maxes=[max(ylim,x_max) for x_max in x_maxes]
        #y_maxes=[max(ylim,y_max) for y_max in y_maxes]
        #print(y_maxes)
        time_text = ax.text(.7, .8, '', fontsize=15,transform=ax.transAxes)
        global pause,direction
        
        pause = False
        direction=1
        def init():
            #ax.clear()
            for line in lines:
                line.set_data([],[])
            ax.set_xlim(x_min,x_max)
            ax.set_ylim(y_min,y_max)
            time_text.set_text("")
            self.frame=0
            fig.legend()
            return lines+[time_text]
        
        def update(_):
            #if frame==len_t-1:
            #    init()
            if self.frame==len_t-1:
                self.frame=0
            elif self.frame==-1:
                self.frame=len_t-1
            if not pause:
                self.frame+=direction
                
            for lind,line in enumerate(lines):    
                line.set_data(xdata[lind][:self.frame],ydata[lind][:self.frame])
               # print(max(ylim,np.max(y_maxes[frame])))
            
            time_text.set_text("t = {0:.3f}".format(t0+(self.frame)*dt/1000))
            #ax.set_xlim((0,x_maxes[frame])) # moving lims
            #ax.set_ylim((0,y_maxes[frame])) # moving lims
            
            return lines+[time_text]
        def onClick(event):
            global pause
            global direction 
            if event.button==1:
                pause = not pause
            elif event.button==3:
                direction=-direction
                #print(direction)
        fig.canvas.mpl_connect('button_press_event', onClick)
        self.anim=FuncAnimation(fig,update,init_func=init,blit=True,interval=1,repeat=True)
        if self.backend=="TkAgg":
            plt.show()
