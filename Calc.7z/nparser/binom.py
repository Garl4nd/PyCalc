def lbnm(p,n,k):
    res=1
    d=k    
    if k<d:
        k=n-k
        d=n-k
    if (k>=d):
        for q in range(n,k,-1):
            
            res*=q/(q-k)*(1-p)
            #print(q,q-k,d,n,res)
            while res>1 and d>=0:
                    res*=p
                    d-=1
        return res*p**(d)
n=4000000
print(lbnm(0.5,n,n//2))