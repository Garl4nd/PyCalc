from . import gen_obj as go
import matplotlib.pyplot as plt
#import numpy
def plot(obj,x0=None,x1=None,**at):
    pden=1000
    if not isinstance(obj,go.GeneralObject):
        obj=go.Monom(obj)
        #raise NotImplementedError("Won't plot a constant")
    if x0 is None:
        x0=0
    if x1 is None:
        x1=1
    if x0>x1:
        x0,x1=x1,x0
    obj=go.Monom(obj.eval(**at))
    vars=obj.get_vars()
    if len(vars)==0:
        vars="x"
    if len(vars)>1:
        #plot_multi(obj)
        raise NotImplementedError("Can only plot functions of a single variable")
    var=next(iter(vars))
    grid=[x0+(x1-x0)*i/pden for i in range(pden)] #np.linspace(x0,x1,)
    vals=[]
    for point in grid:
        try:
            newval=obj.eval(**{**{var:point},**at})
        except ZeroDivisionError:
            newval=None
        vals.append(newval)

    plt.plot(grid,vals)
    plt.show()