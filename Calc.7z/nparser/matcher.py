
def find_all(text,p):
        '''Yields all the positions of
        the pattern p in the string s.'''
        i = text.find(p)
        if p=="":
            return
        while i != -1:
            print(i)
            yield i
            print(p,i+len(p))
            i = text.find(p, i+len(p))

symbols={"a","bc","sin","pie"}
def is_substring(text,my_pos,ls=1):
        for symbol in symbols:
            
            if my_pos+ls>len(text):
                raise IndexError("Spatny index hledani!")
            for pos in find_all(symbol,text[my_pos:my_pos+ls]): # Najde pozici znaku v symbolu
                if my_pos-pos<0: # pozice znaku v symbolu je vetsi nez nase misto v textu (tudiz to nemuze byt match)
                    continue
                else:
                    if text[my_pos-pos:my_pos+len(symbol)-pos]==symbol:
                        print(symbol)
                        return True,my_pos+len(symbol)-pos
        return False,None
for el in find_all("as",""):
    print(el)
#print(is_substring("sinpi",0,2))