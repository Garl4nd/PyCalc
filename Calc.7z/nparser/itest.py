from . import gen_obj as go
from .gen_obj import Polynomial
#from . import gen_obj 

#from .gen_obj import Polynomial
s=go.Polynomial(1)
q=Polynomial(1)
print(go.checkinst(s))
print(isinstance(s,go.Polynomial))
print(isinstance(q,Polynomial))