from  gen_obj import SPolynomial
import itertools as it
def sin_series():
    res=1
    i=1
    while True:
        yield 0
        yield res
        i+=2
        res*=-1/(i*(i-1))
        
def cos_series():
    res=1
    i=0
    while True:
        yield res
        yield 0
        i+=2  
        res*=-1/(i*(i-1))
        
def product(s,c,n):
    #s=sin_series()
    #c=cos_series()
    sn=it.islice(s,0,n+1)
    cn=it.islice(c,0,n+1)
    spol=SPolynomial("x",*sn)
    cpol=SPolynomial("x",*cn)
    return spol*cpol

def alt_product(sn,cn,n):
    return sum(a*b for on,a in enumerate(sn) for om,b in enumerate(cn) if on+om==n)
def prodseries(s,c,n):
    sn=list(it.islice(s,0,n+1))
    cn=list(it.islice(c,0,n+1))
    for i in range(n+1):
        yield alt_product(sn[:i+1],cn[:i+1],i)

for el in prodseries(cos_series(),cos_series(),2):
    print(el)

