# prime factorization using Pollard's rho algorithm
import math

primes=[]
nonprimes=set()

def sieve(n):
    #lb=int(math.sqrt(n))
#    cdef int lb,x,i
    lb=n
    #print(lb)
    for x in range(2,lb):
        if x in nonprimes:
            continue
        else:
            primes.append(x)
            for i in range(x**2,lb,x):
                

                nonprimes.add(i)
    return primes
def prime_fact(n):
    if n<=0 or isinstance(n,float):
        raise ValueError("The number must be a positive integer!")
    #candidates=(num for num in sieve(n//2+1))
    lb=int(math.sqrt(n))+1
    candidates=(num for num in sieve(lb))
    oldn=n
    primes=[]
    for candidate in candidates:
        #print(candidate)
        while not n%candidate:
           # print("match",candidate)
            n=n//candidate
            primes.append(candidate)
            if n==1:
                return primes
    return primes+[n]


#print(sieve(546545))
#print(prime_fact(54654546789944))