from .regparser import Op,Parser
from .polynom import SPolynomial,Vector#Polynomial,Monom

class bParser(Parser):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        #self.add_operator("x",0,0,lambda:SPolynomial("x",0,1))
        self.pollist=[]
    def _parse(self,text:str,level=(0,0),lbuf=None,rbuf=None):
        self.partial_results.append([level,self.unmake_unique_text(text),"sym",None])
        #print(text)
        #print(text)
        text=self.strip_brackets(text)
        #print(text)
        if self.is_final(text): 
        #    print(f"final {text}")
            #return(str(float(text)))
            #print(lbuf,rbuf)
            if lbuf!=None or rbuf!=None:
                
                if text[0] not in ("+","-"):
                    #print(text,lbuf,rbuf)

                    raise ValueError("Spatne zadany vyraz! (Nejspis unarni operator mezi dvema argumenty nebo unarni operator na spatne strane)")
            res=self.convert_to_final(text) # a zde by se mohli vracet obecnejsi algebraicke objekty
            #print(text,res)
            self.partial_results.append([level,res,"res",None])
            return res


        #self.partial_results.append((level,self.unmake_unique_text(text),"sym"))
        
        brack_inds=self._filter_brackets(text)
        masked_text=self.mask_text(text,brack_inds)
        for symbol,op in self.operators.items():
            
            #text=self.strip2(text,brack_inds)
            #print(f"Before mask {text}") 
            #print(text,symbol) ##zde musi byt smycka pres findall (v pripade confliktu)
            for ind in self.find_all(masked_text,symbol,direction=op.direction):
                #print(symbol,ind)
                #print("Found",symbol)
                is_conflict,_=self.is_substring(text,ind,len(symbol),let_pass={symbol})
                if is_conflict: #alternativa: maskovat prekryvajici se operatory krizkem #
                    #print("Konflikt!")
                    continue

                #print("Passed conflict check: ",symbol)
                lp=text[:ind]
                rp=text[ind+len(symbol):]
                #print(symbol)
                #print(f"Before eval: lp = {lp}, rp= {rp}")
                
                if op.arity==0:
                    res=op.intr()
                    #print(f"res {res} , {type(res)}")
                    self.partial_results.append([level,res,"res",None])
                    return res
                else:
                    
                    if op.arity==1:
                        res=self.expr_eval1(lp,rp,op,level=level,lbuf=lbuf,rbuf=rbuf)
                        self.partial_results.append([level,res,"res",None])
                        return res
                #       print(lp,rp)
                    
                    elif op.arity==2:
                        #print("ar2",op.symbol,lp,rp,lbuf,rbuf)
                        if lp=="" and lbuf==None and op.unary_overload:
                        #    print("Overloading")
                        #       print("Overloading right")
                                if op.unary_overload.acts_on=="left":                            
                                    raise ValueError(f"Wrong direction of action! The operator {symbol} acts on left.")
                                else:
                                    res=self.expr_eval1(lp,rp,op.unary_overload,level=level,lbuf=lbuf,rbuf=rbuf)
                                    self.partial_results.append([level,res,"res",None])
                                    return res
                        elif rp=="" and rbuf==None and op.unary_overload:
                                #print(lbuf,rbuf,lp,rp)
                                if op.unary_overload.acts_on=="right":
                                    raise ValueError(f"Wrong direction of action! The operator {symbol} acts on right.")
                                else:
                                    res=self.expr_eval1(lp,rp,op.unary_overload,level=level,lbuf=lbuf,rbuf=rbuf)
                                    self.partial_results.append([level,res,"res",None])
                                    return res
                        else:
                            res=self.expr_eval2(lp,rp,op,level=level,lbuf=lbuf,rbuf=rbuf)
                            self.partial_results.append([level,res,"res",None])
                            return res

                            
                        #print(f"Text: {text}")
        
        res=self.eval_funcs(text,level=(level[0],level[1]))
        self.partial_results.append([level,res,"res",None])
        return res
        #print(f"Konec: {text}")
        """
        print(f"'{text}' neni Finalni!")
        if self.__error_text==text:
            self.__cur_error_depth+=1
            if self.__cur_error_depth>=self.max_error_depth:
                raise ValueError("Nezpracovatelny vyraz!")
        else:
            self.__error_text=text
            self.__cur_error_depth=0
                
        return(self._parse(text))
        """
    def expr_eval1(self,lp,rp,op,level=(0,0),lbuf=None,rbuf=None):
            #print(f"Unary, expr= {expr},op= {op.symbol}")
            #if self.is_number(expr):
            #    return op.intr(float(expr))
            #else:
            #return self.expr_eval1(self._parse(expr),op)
        xl,yl=level
        if op.acts_on=="left": 
            if not rp:
                if not lp:
                    if lbuf!=None:
                        return op.intr(lbuf)
                    else:
                        print(lp,rp,op.symbol,lbuf,rbuf,sep="|")
                        raise ValueError("Wrong input!")
                return op.intr(self._parse(lp,level=(xl,yl+1),lbuf=lbuf,rbuf=rbuf))
                                    
            else:
                #print(lp,rp,lbuf,rbuf)
                res=op.intr(self._parse(lp,level=(xl,yl+1),lbuf=lbuf,rbuf=None))
                #print("res",res)
                #assert lbuf==!None,f"No lbuf in {lp}!"
                    
                #print(lp,rp)
                return self._parse(rp,level=(xl+1/2**yl,yl+1),lbuf=res,rbuf=rbuf)
        else: #if op.acts_on=="right"
            if not lp:
                if not rp:
                    if rbuf!=None:
                        return op.intr(rbuf)
                    else:
                        print(lp,rp,op.symbol,lbuf,rbuf,sep="|")
                        raise ValueError("Wrong input!")
                return op.intr(self._parse(rp,level=(xl,yl+1),lbuf=lbuf,rbuf=rbuf))
            else: #if lp
                #assert lbuf==None,f"Conflicting lbuf in {lp}!"
                #print(rp,None,rbuf)
                res=op.intr(self._parse(rp,level=(xl,yl+1),lbuf=None,rbuf=rbuf))
                #print(lp,rp)
                return self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf,rbuf=res)

    def expr_eval2(self,lp,rp,op,level=(0,0),lbuf=None,rbuf=None):
        xl,yl=level
        #print(f"lp = {lp}, rp= {rp},op= {op.symbol}")
        #if self.is_number(lp) and self.is_number(rp):
            #print(f"returning {op.intr(float(lp),float(rp))}")
         #   return op.intr(float(lp),float(rp))
        #print("lrb:",lp,rp,lbuf,rbuf,sep="|")
        #print("bin",op.symbol,lp,rp,lbuf,rbuf)
        if ""  in [lp,rp]:
            if lp=="":
                
                if lbuf!=None:
                    self.partial_results[-1][3]=self.unmake_unique_text(op.symbol)    
                    return op.intr(lbuf,self._parse(rp,level=(xl+1/2**yl,yl+1),rbuf=rbuf))   
                elif self.fill_id and op.identity:
                    lp=str(op.id_rep)
                else:
                    raise ValueError("Wrong input!",lp,rp)
            elif rp=="":
                if rbuf!=None:
                    self.partial_results[-1][3]=self.unmake_unique_text(op.symbol+str(rbuf))    
                    return op.intr(self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf),rbuf)
                elif self.fill_id and op.identity:
                    rp=str(op.id_rep)
                else:
                    raise ValueError("Wrong input!")
        #return self.expr_eval2(self._parse(lp),self._parse(rp),op)
        self.partial_results[-1][3]=self.unmake_unique_text(op.symbol)    
        return op.intr(self._parse(lp,level=(xl-1/2**yl,yl+1),lbuf=lbuf),self._parse(rp,level=(xl+1/2**yl,yl+1),rbuf=rbuf))
    

    def is_final(self,text):
        if any(text.startswith(pl) for pl in self.pollist):
            return True
        try:
            float(text)
        except ValueError:
            
            return False
        else:
            return True
    
    def convert_to_final(self,text):
        for pl in self.pollist:
            if text==pl:
                return SPolynomial(pl,0,1)
        try:
            res=int(text)
        except ValueError:
            res=float(text)
        return res

if __name__=="__main__":
    p=bParser(implicit=True)
    #print(Vector(1,2,3))
    print(p.sparse("(xyz)''''' |x;y;z "))
    p.sparse("x**2-x=0")
    #p.draw_parse_tree(xc=0.5,yc=0.9,adapt_size=True)

    