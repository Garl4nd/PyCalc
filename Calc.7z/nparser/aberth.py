import gen_obj as go
from gen_obj import Complex,SPolynomial
import random
import math

def absolve(pol):
    try:
        
        var=next(iter(pol.varset))
        coefs=pol.get_coefs(var)
        lbound,ubound=get_bounds(coefs)
        print(lbound,ubound)
        for _ in range(10):
            zks=gen_compl(ubound,pol.order)
            #print("Try",zks)
            for _ in range(10):
                qks=[(pol/pol.deriv(var)).eval(**{var:zk}) for zk in zks]
                print("qks",qks)
                denoms=[1-qk*sum(1/(zks[k]-zj) for j,zj in enumerate(zks) if j!=k ) for k,qk in enumerate(qks)]
                wks=[ (qk/(denom)).eval(**{var:zk}) for zk,qk,denom in zip(zks,qks,denoms)]
                #print("wk:","|".join(str(w) for w in wks))
                zks=[zk-wk for zk,wk in zip(zks,wks)]
            #print(zks)
            if all(abs(zk)<ubound for zk in zks):
                break
        return zks
    except KeyError:
        if len(pol.varset)==0:
            return "Never True" if pol!=0 else "Always True"
        else:
            raise ValueError("Can only solve for functions of one variable")
        
def get_bounds(coefs):
    an=coefs[-1]
    ubound=1+max(abs(a_i/an) for a_i in coefs[:-1] )
    coefs=[coef for coef in coefs[::-1] if coef!=0] #reverse
    an=coefs[-1]
    try:
        lbound=1/(1+max(abs(a_i/an) for a_i in coefs[:-1] ))
    except ValueError:
        lbound=0
    return lbound,ubound
def gen_compl(bound,n):
    res=[]
    for _ in range(n):
        norm=random.random()*bound
        rind=random.random()*2*math.pi
        res.append(Complex(norm*math.cos(rind),norm*math.sin(rind)))
    return res
q=SPolynomial("x",1,0,0,0,0,0,1)
print(q)
print(absolve(q))
#print(gen_compl(1,5))