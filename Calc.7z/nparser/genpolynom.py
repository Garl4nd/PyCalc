import functools as ft
import gen_obj as go
from gen_obj import GeneralObject
from operator import mul,add
#import quotient
#module_prefix_options={"direct":__loader__.name+".","concise":""}
module_prefix="" #module_prefix=module_prefix_optinos["direct"]  to make eval the inverse of repr

def product(args): 
    
    return ft.reduce(mul,args,1)
def msum(mon):
    
    ##print(arglist,len(arglist))
 
    return -(mon.order*100000-len(mon.vars)*1000-0.01*sum(ord(str(key[0])) for key in mon.vars.keys()))

def truncate_number(num,sig_nums=3):
    """Prevede cela cisla sama na sebe a desetinna cisla na cisla s desetinnou casti na sig_nums vyznamnych cislic"""
    inum=int(num)
    if inum==num:
        return str(inum)
    else:
        base,decpart="{:.15f}".format(num).split(".")
        sig=decpart.strip("0")
        ind=decpart.find(sig)
        decimal=str(round(int(decpart[:ind+sig_nums+1]),-1)).rstrip("0")
        return base+"."+"0"*ind+decimal

def to_sigfigs(num,sig_nums=3): #  Vyznamne cislice s hezci vedeckou notaci
    s="{:.{sign}g}".format(num,sign=sig_nums)
    s=re.sub("e[\+\-](\d+)",lambda k: f"^{k[1]}",s)
    return s

def make_whole(x,y):
    ##print("make whole:",x,y)
    orx,ory=x,y
    if x==0:
        return 0,y
    rx,ry=1/x,1/y
    if int(rx)==rx:
        p=x*y
        if int(p)==p:
            return 1,p
        if int(ry)==ry:
            return ry,rx
    if int(ry)==ry:
        p=x*y
        if int(p)==p:
            return p,1

    #if abs(x)<abs(y):
    #    x,y=1/y,1/x
    for _ in range(5):
        if int(x)==x and int(y)==y:
            x,y=int(x),int(y)
            ##print("looping",x,y)
            break
        x,y=x*10,y*10
    else:
        

        return orx,ory    
    ##print("Returning",x,y)
    return x,y
    
class Monom(GeneralObject):
    @property
    def name(self):
        return "Monom"
    @property
    def evaluables(self):
        return int,float
       
    def __init__(self,coef: float=0,vars :dict={}):
        self.isconst=True
        ##print("Building Monom",coef,vars)
        if coef==0:
            self.coef=0
            self.vars={}
            self.order=0
            self.varset=set()

        else:
            icoef=int(coef)
            if icoef==coef:
                coef=icoef
            self.vars={}
            
            for name,obj_info in vars.items():
                if isinstance(obj_info,tuple):
                    obj,order=obj_info
                else:
                    obj,order=None,obj_info
                if order!=0:
                    self.vars[name]=(obj,order)
                    self.isconst=False
            self.coef=coef
            self.vars=dict(sorted(self.vars.items()))
            self.order=sum(order for _,order in self.vars.values())
            self.varset={*self.vars.keys()}
         #   #print("From Monom:",coef,self.varset,self.order,self.isconst)
    def fl_eval_objs(self)->float or int: #Povinna funkce, diky ktere Monom bude hrdou podtridou abstraktni tridy "Obecny vyraz" 
        res=self.coef
        for var,power in self.vars.items():
            res*=var.eval()**power # var.eval()!
        return res

    def eval_objs(self,*args,**kwargs)->float or int: #Povinna funkce, diky ktere Monom bude hrdou podtridou abstraktni tridy "Obecny vyraz" 
        res=self
        print("evaling",args,kwargs)
        new_vars={}
        for var,(obj,power) in self.vars.items():
            if obj is not None:
                res*=obj.eval_objs(**kwargs)**power # var.eval()!
                #new_vars.append()
            else:
                if var in kwargs:
                    res*=kwargs[var]**power
        return res
        

    def at(self,**vals):
        new_coef=self.coef
        new_vars={**self.vars}
        for var,value in vals.items():
            if var in self.vars:
                new_coef*=value**self.vars[var][1]
                del new_vars[var]
        return Monom(new_coef,new_vars)
        
    def issame(self,other):
        return self.vars==other.vars

    def inv(self):
        try:
            return Monom(1/self.coef if 1%self.coef else 1//self.coef,{
                var:-coef for var,coef in self.vars.items()})
        except ZeroDivisionError:
            #print("Deleni nulou!")
            raise

    def __add__(self,other):
        if isinstance(other,(Polynomial,Quotient)):
            return other+self
        
        if type(other) in [int,float]:
            other=Monom(other,{})
        
        if self.issame(other):
            return Polynomial([Monom(self.coef+other.coef,self.vars)])
        else:
            return Polynomial([self,other])
            #raise ValueError("Can't add different monomials in Monom!")
    
    __radd__=__add__

    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return other+(-self)

    def monaddition(self,other):
        if self.issame(other):
            return Monom(self.coef+other.coef,self.vars)
        else:
            raise ValueError("Monomy musi byt stejneho typu!")

    def __mul__(self,other):
        if isinstance(other,(Polynomial,Quotient)):
            return other*self
        if type(other) in [int,float]:
            other=Monom(other,{})
        nv={**self.vars,**other.vars}
        nc=self.coef*other.coef
        if nc==0: 
            return Monom(0,{})
        else:
            for var1,order1 in self.vars.items():
                for var2,order2 in other.vars.items():
                    if var1==var2:
                        nv[var1]=order1+order2
                    #if var1=="const":
                     #   nv[var2]=order2
        return Monom(nc,nv)
    def __hash__(self):
        return hash(repr(self))
    __rmul__=__mul__

    def __truediv__(self,other):
        if type(other) in [int,float]:
           return Monom(self.coef/other if self.coef%other else self.coef//other,self.vars)
        return Quotient(self,other)
    def __rtruediv__(self,other):
        return Quotient(other,self)
    def __neg__(self):
        return Monom(-self.coef,self.vars)

    def __pow__(self,exponent):
        if type(exponent)!=int:
            raise TypeError("Exponent musi byt cele cislo!")
        if exponent>0:
            return Monom(self.coef**exponent,{var:(obj,order*exponent) for var,(obj,order) in self.vars.items()})            
        elif exponent<0:
            return Quotient(1,self**(-exponent))
        else:
            return Monom(1)

        #return ft.reduce(mul,(self for _ in range(exponent)),Monom(1,{}))
    def deriv(self,var):
        return Polynomial(self).deriv(var)

    def divgrad(self):
        return Polynomial(self).divgrad()

    def __eq__(self,other):
        if self.isconst and type(other) in (float,int):
            return self.coef==other
        if isinstance(other,Monom):
            return self.coef==other.coef and self.vars==other.vars
        if isinstance(other,(Polynomial,Quotient)):
            return other.__eq__(self)
        return super().__eq__(other)
    
    def __repr__(self):
        return f"{module_prefix}Monom({self.coef},{self.vars})"
        #self.vars=(("x",1),("y",5))
    @classmethod
    def fromrepr(cls,text):
        if not text.startswith("M("):
            raise ValueError("Wrong format! The string must start with \"M(\" ")
        else:
            
            return eval("Monom("+text[2:])
        
    def __str__(self):
        s=""
        if self.isconst:
            return truncate_number(self.coef)
        else:
            if self.coef>=0:
                pref=""
            else:
                pref="-"
            
            s+=f"{pref}{truncate_number(abs(self.coef)) if abs(self.coef)!=1 else ''}"
            for var,(obj,order) in self.vars.items():
                    s+=var
                    if order!=1:
                        if order>0:
                            s+=f"^{order}"
                        else:
                            s+=f"^({order})"
           # #print(s)
            return(s)
        
            

class Polynomial:


    def __init__(self,monlist):
        
        ##print("Entering Polynomial constructor with monlist:",type(monlist),monlist)
        
        ##print(monlist)
        #input()
        nl=[]
        if isinstance(monlist,Polynomial):
            monlist=monlist.monlist
        try:
            iter(monlist)
        except TypeError:
            if isinstance(monlist,Quotient):
                if monlist.q.isconst:
                    const=(monlist.q.monlist)[0].coef
                    monlist=[mon/const for mon in monlist.p.monlist]

                else:
                    raise ValueError("Can't convert quotient with non-constant denominator to a polynomial!")
            else:
                monlist=[monlist]
        monlist=list(monlist)
        #print("#printing monlist at the begiinging:",monlist)
        
        ##print("Bulding",monlist)
        #input()
        for mon in monlist:
            ##print("Processing",mon)
         #   input()
            if not isinstance(mon,Monom):

                #print("Not a monom, converting!",type(mon),type(Monom()))
                mon=Monom(mon)
            same=False
            #print(mon,repr(mon),mon.isconst,resmon,resmon.isconst)
            for ind,savedmon in enumerate(list(nl)):
                delind=None
                if mon.issame(savedmon):
                    ##print(mon,"is the same as",savedmon)
                    same=True
                    ##print("Pred prictenim",nl,nl[ind])
                    res=mon.monaddition(nl[ind])
                    ##print(res,res==0)
                    if res==0:
                        del nl[ind]
                    else:
                        nl[ind]=res
#            #print("issame?",mon,same,0)
            if not same:
                if mon!=0:
                    nl.append(mon)
            ##print("nl:",nl)
        
        #self.monlist=sorted(nl,key=lambda mon: msum((order for order in mon.vars.values())))
        ##print("Nl after processing:",nl)
        self.monlist=sorted(nl,key=msum)
        if not self.monlist:
            self.monlist.append(Monom(0,{}))
      #  #print(self,"orders:", [(mon,mon.order) for mon in self.monlist])
        ##print(self.monlist)
        self.order=max(mon.order for mon in self.monlist)
        self.varset={var for mon in self.monlist for var in mon.vars.keys()}
        #print("#printing monlist at the end:")
        for mon in self.monlist:
            pass#print(mon,mon.isconst)
        self.isconst=all(mon.isconst for mon in self.monlist) 
        #print("Quiting Polynomial constructor with monlist:",type(monlist),monlist,self.monlist)
    def eval_objs(self):
        return sum(mon.eval() for mon in self.monlist)
    
    def factor_variables(self):
        #print("Factoring")
        d=self.monlist[0].coef
        ##print(self.varset)
        if self==0:
            return (Monom(0),Polynomial(0))
        for mon in self.monlist[1:]:
            d=gcd(d,mon.coef)
        ##print("Factor vartiables:",d)
        pref_vars={var:min(mon.vars.get(var,0) for mon in self.monlist) for var in self.varset}
        prefactor=Monom(d,pref_vars)
        new_coefs=(mon.coef//d  if d!=1 else mon.coef for mon in self.monlist)
        new_vars=({var:mon.vars[var]-pref_vars[var] for var in mon.vars if mon.vars[var]-pref_vars[var]!=0}  for mon in self.monlist)
        rest=Polynomial(Monom(coef,var) for coef,var in zip(new_coefs,new_vars))

        #print("Returning from factor","|".join(str(el) for el in (prefactor,rest,prefactor.coef,prefactor.isconst)))
        return (prefactor,rest)
   
    @classmethod
    def convert(cls,obj):
        if isinstance(obj,Polynomial):
            return obj
        if type(obj) in (float,int):
            ##print(obj)
            return SPolynomial("",obj)
        elif isinstance(obj,Monom):
                return Polynomial([obj])
        else:
            raise TypeError(f"Can't convert object {obj} with type {type(obj)} to Polynomial")

    def at(self,**vars):
        return sum(mon.at(**vars) for mon in self.monlist)

    def __add__(self,other):
        ##print("adding",self,other,type(self),type(other),self.monlist,other.monlist)
        if type(other) in [int,float]:
            other=Polynomial([Monom(other,{})])
        if isinstance(other,Monom):
            return Polynomial(self.monlist+[other])    
        elif isinstance(other,Quotient):
            
            return other+self
        else:
            return Polynomial(self.monlist+other.monlist)

    __radd__=__add__

    def __mul__(self,other):
        if type(other) in [int,float]: #nebo cokoliv jineho
            other=Polynomial([Monom(other,{})])
        if isinstance(other,Monom):
            return Polynomial(mon1*mon2 for mon1 in self.monlist for mon2 in [other])    
        if isinstance(other,Quotient):
            return other*self
        return Polynomial(mon1*mon2 for mon1 in self.monlist for mon2 in other.monlist)
                
    __rmul__=__mul__

    def __neg__(self):
        nl=[-mon for mon in self.monlist]
        return Polynomial(nl)

    def __pow__(self,exponent):
        if type(exponent)!=int: #or exponent<0:
            raise TypeError("Exponent musi byt cele cislo!")
        if exponent==0:
            return Polynomial(1)
        if len(self.monlist)==1:
            if exponent>0:
                return Polynomial(self.monlist[0]**exponent)
            else:
                return Quotient(1,self**(-exponent))
            
        else:
            if exponent>0:
                return ft.reduce(mul,(self for _ in range(exponent)))
            else:
                return Quotient(1,self**(-exponent))
            
    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return other+(-self)

    def __truediv__(self,other):
        ##print("Pol div",self,"|",other)
        if type(other) in [int,float]:
            if other==0:
                raise ZeroDivisionError("Deleni nulou!")
            else:
                return self*(1/other if 1%other else 1//other)
        if other==self:
            return Quotient(1)
        
        if isinstance(other,Monom):
            #return self*other.inv()
            return self/Polynomial(other)
        if isinstance(other,Quotient):
            ##print("other.inv",other.inv())
            return other.inv()*self
        ##print(type(self),type(other))        

        return Quotient(self,other) 

    def __rtruediv__(self,other):
        return Quotient(other)/self
    
    def deriv(self,var):
        nl=[]
        for mon in self.monlist:
            ##print(var,mon.vars,mon.coef)
            if var not in mon.vars:
                continue
            new_vars={**mon.vars}
            new_vars[var]-=1
            ##print(mon.coef,mon.vars[var])
            nl.append(Monom(mon.coef*mon.vars[var],new_vars))
        return Polynomial(nl)

    def divgrad(self):
        nl=[]
        for mon in self.monlist:
            if mon.isconst:
                continue
            for var,order in mon.vars.items():
                if order==0:
                    continue
                new_vars={**mon.vars}
                new_vars[var]-=1
                nl.append(Monom(mon.coef*order,new_vars))
        return Polynomial(nl)
    
    def __repr__(self):
        return(f"{module_prefix}Polynomial(["+",".join((f"{mon!r}" for mon in self.monlist))+"])")

    def __eq__(self,other):
        ##print(self.order)
        if self.isconst:
            if type(other) in (float,int):
                ##print(self.monlist[0],other)
                return self.monlist[0]==other
        if isinstance(other,Monom):
            return self==Polynomial(other)
        if isinstance(other,Polynomial):
            return set(self.monlist)==set(other.monlist)
        elif isinstance(other,Quotient):
            return other==self
        return super().__eq__(other)
    def __str__(self):
        
            
        #smonlist=sorted(self.monlist,key=lambda mon: product((order for order in mon.vars.values())))

        s=""
        for mon in self.monlist:
            if mon.coef!=0:
                if s=="":
                    s+=str(mon)
                    
                else:
                    if mon.coef>0:
                        s+=" + "+str(mon)
                    else:
                        s+=" - "+str(mon)[1:]   
        if s=="":
            s="0"               
        return s

    def __int__(self):
        for mon in self.monlist:
            if mon.isconst:
                return int(mon.coef)
        return 0

    def __float__(self):
        for mon in self.monlist:
            if  mon.isconst:
                return float(mon.coef)
        return 0.0

    @classmethod
    def fromrepr(cls,text):
        return eval(text.replace("P","Polynomial").replace("M","Monom"))
    def get_coefs(self,var,at_least=None):
       # #print(self.varset,self.order)

        max_order=max(at_least,self.order) if at_least else self.order
        coefs={order:0 for order in range(max_order+1)}
        for mon in self.monlist:
            if mon.vars=={}:
                coefs[0]=mon.coef
            else:
                coefs[mon.vars[var]]=mon.coef
        
        return dict(sorted(coefs.items())) 
    def longdiv(self,other):
        if isinstance(other, (int,float,Monom)):
            other=Polynomial(other)
        elif isinstance(other,Quotient):
            if other.q.isconst:
                other=Polynomial(other.p/other.q.monlist[0])
            else:
                raise TypeError("Can't use the long division algorithm to divide by a quotient")
        if not self.varset:
            if not other.varset:
                num=self.monlist[0].coef
                den=other.monlist[0].coef
                return Polynomial(num//den),Polynomial(num%den),[(self,0),(num%den,num//den)]
            else:
                return Polynomial(0),self,[(self,0),(self,0)]
        if other.varset:
            if len(self.varset)>1 or self.varset!=other.varset:
                raise NotImplementedError(r"The polynomials must be of the same type and in one variable,"
        r"the more general case hasn't been implemented yet")
        
        var=next(iter(self.varset))

        p=self
        q=other            
        def leading_term(pol): 
            return (0,pol.monlist[0].coef) if pol.isconst else max(filter(lambda d: d[1]!=0,(d for d in pol.get_coefs(var).items()) ))                    
        s=SPolynomial(var,0)
        partial_results=[(p,0)]

        porder,pcoef=leading_term(p)
        #print(porder,pcoef)
        qorder,qcoef=leading_term(q)
        
        while porder>=qorder:
            ##print(p,":",q) 
            ##print(porder,pcoef,qorder,qcoef)
            #input()
            newterm=Monom(pcoef/qcoef if pcoef%qcoef else pcoef//qcoef,{var:porder-qorder})
            s=s+newterm
            p=p-newterm*q
            ##print(newterm,newterm*q)
            ##print("s,r:",s,"|",p)
            ##print(p,p.order)
            ##print(repr(p),p==0,str(p))
            partial_results.append((p,s))
            if p==0:
                break
            
            porder,pcoef=leading_term(p)
            
         #   if self.order<other.order:
          #      return SPolynomial("",0.0),self
        ##print(self.varset)
        
        if len(partial_results)==1:
            partial_results.append((self,0))
        return s,p,partial_results
       # except AttributeError as e:
        #    #print(e)
         #   #print("The argument must a monomial, a polynomial or a polynomial quotient!")

class SMonom(Monom): 
    def __init__(self,coef,symb,order):
        super().__init__(coef,{symb:order})

class SPolynomial(Polynomial):
    def __init__(self,symb,*coefs):
        super().__init__((Monom(coef,{symb:i}) for i,coef in enumerate(coefs)))

class Quotient:
    

    def __init__(self,p:Polynomial,q:Polynomial=None,cancel_common=True):
        #print("Entering quotient init with p,q:",p,"---",q)
        #print("Cancel common with ",p,q,cancel_common)
        if q==0:
            raise ZeroDivisionError("Division by zero!")   
        if p is None:
            raise ValueError("P is none!")
        if p==0:
            p=Polynomial(0)
            q=Polynomial(1)
        else:
            if not q:
                q=SPolynomial("",1)
            ##print(p,q)
            if not isinstance(p,Polynomial): 
                p=Polynomial(p)
            if not isinstance(q,Polynomial):
                q=Polynomial(q)
            #print("const?",p,q,p.varset,q.varset,type(p),type(q),p.isconst,q.isconst,repr(q))
            #print("p==q?",p==q)
            if p==q:
                p=Polynomial(1)
                q=Polynomial(1)
            elif p.isconst and q.isconst:
                ##print("Building",p,q)
                a=p.monlist[0].coef
                b=q.monlist[0].coef
                ##print("Building",p,q,a,b,type(p),type(q),type(a),type(b))
                #print("About to make whole",a,b,type(a),type(b)) 
                a,b=make_whole(a,b)
                
                #print("pconst,qconst",a,b)
            # #print(a,b)
                com_div=gcd(a,b)
                a,b=a/com_div,b/com_div
                #print(com_div,a,b,"cdiv")
            # #print(a,b)
                p=Polynomial(a)
                q=Polynomial(b)
                #print(self.p,self.q,repr(self.p),repr(self.q))
                #print("Made polynomials",self.p,self.q,type(self.p),type(self.q))
                #input()

            else:
                if p.varset==q.varset and len(p.varset)==1:
                    
                        

                    if p.order>=q.order:
                        s,r,_=p.longdiv(q)                
                        if r==0:
                            p=s
                            q=Polynomial(1)
                    else:
                        s,r,_=q.longdiv(p)                
                        if r==0:
                            p=Polynomial(1)
                            q=s
                    ##print(s,r)
                 #   p,q=self.cancel_and_divide(p,q)

                else:
                    
                    if  cancel_common:
                        #print("cancel_common")    
                        p,q=self.cancel_and_divide(p,q)
                        #print("After cancelling, got",p,q)
        if q.monlist[0].coef<0:
            self.p,self.q=-p,-q            
        else:
            self.p,self.q=p,q
            
        self.varset=self.p.varset.union(self.q.varset)
        self.isconst=self.p.isconst and self.q.isconst

        #print("Finished Quotient with ",self.p,self.q)
            #print("Built Quotient with p,q:,type(p),type(q),varset,isconst:",self.p,self.q,type(p),type(q),self.varset,self.isconst)
 
    def cancel_and_divide(self,p,q):
        #print("cancelling",p,"|",q)
        ppref,prest=p.factor_variables()
        #print("factoring q",p,"|",q)
        qpref,qrest=q.factor_variables()
       # print("|".join(str(el) for el in (ppref,qpref,prest,qrest)))
        #input()
        
        #print(" | ".join(map(str,(ppref,qpref,prest,qrest))))
        pcoef,qcoef=ppref.coef,qpref.coef
        #print("d=gcd(pcoef,qcoef)")
        d=gcd(pcoef,qcoef)

        pcoef,qcoef=pcoef/d,qcoef/d #pozor, co to udělá když jedno z toho bude float?
        
        common_vars={var:min(mon.vars.get(var,0) for mon in (ppref,qpref)) for var in ppref.varset.union(qpref.varset)}
        newpvars,newqvars=({var:mon.vars[var]-common_vars[var] for var in mon.vars if mon.vars[var]-common_vars[var]!=0} for mon in (ppref,qpref))
        ppref,qpref=Monom(pcoef,newpvars),Monom(qcoef,newqvars)
        
        #print("v1:",prest,qrest)
        #input()
       # print(all(mon1.coef==mon2.coef for mon1,mon2 in zip(prest.monlist,qrest.monlist)))
      #  print(prest==qrest,repr(prest),repr(qrest))
        
       # print(v1)
        #v2=v1*ppref
        ##print("v2 pass",v2,type(v2))
        #v3=v2/qpref
        ##print("v3 pass",v3,type(v3))
        #print("Sending",prest,qrest,"and ",ppref,qpref," to newz")
        z1=Quotient(ppref,qpref,cancel_common=False)
        z2=Quotient(prest,qrest,cancel_common=False)
        
        newz=Quotient(z1.p*z2.p,z1.q*z2.q,cancel_common=False)
        return newz.p,newz.q

    def eval_objs(self):
        return self.p.eval()/self.q.eval()

    def at(self,**vars):
        res=self.p.at(**vars)/self.q.at(**vars)
        if type(res)==float:
            if int(res)==res:
                return int(res)
        else:
            return res
    
    def __add__(self,other):

        if isinstance(other,Monom):
            other=Polynomial(other)
        if isinstance(other,(Polynomial,int,float)):
            return Quotient(self.p+other*self.q,self.q)    
        if self.q==other.q:
            return Quotient(self.p+other.p,self.q)    
        else:
            return Quotient(self.p*other.q+self.q*other.p,self.q*other.q)
    __radd__=__add__
   


    def __sub__(self,other):
        if not isinstance(other,Quotient):
            return self-other
        else:
            return self+(-other)

    def __rsub__(self,other):
        return other+(-self)

    def __mul__(self,other):
        if isinstance(other,(Polynomial,Monom,int,float)):# or type(other) in [int,float]:
            other=Quotient(other)
        if not self.p==0:
            
            if self.p==other.q and self.q==other.p:
                return Quotient(1)
            elif self.p==other.q:
                return Quotient(other.p,self.q)
            elif other.p==self.q:
                return Quotient(self.p,other.q)
            elif self.p*other.q==self.q*other.p:
                return Quotient(1)
            else: 
                return Quotient(self.p*other.p,self.q*other.q)
    __rmul__=__mul__

    def __pow__(self,exponent):
        if exponent>0:
            return Quotient(self.p**exponent,self.q**exponent)
        elif exponent<0:
            if self.p==0:
                raise ZeroDivisionError("Nula nema zaporne mocniny!")
            else:
                return Quotient(self.q**(-exponent),self.p**(-exponent))
        else: #exponent==0
            return Quotient(0)

    

    def __repr__(self):

        cs=self
        return f"{module_prefix}Quotient({cs.p!r},{cs.q!r})"

    def __str__(self):
        cs=self
        if self.q.isconst and self.q.monlist[0].coef<0:
                p,q=-self.p,-self.q
        else:
            p,q=self.p,self.q
        
        p,q=cs.p,cs.q
        pstr=str(p)
        qstr=str(q)
        
        pstrlen=max(len(pstr.split(" + ")),len(pstr.split(" - ")))
        qstrlen=max(len(qstr.split(" + ")),len(qstr.split(" - ")))
        upar="()" if pstrlen>1 or len(self.p.varset)>1 else ["",""]
        lpar="()" if qstrlen>1 or len(self.q.varset)>1 else ["",""]
        ##print("debug",self.p,self.q)
        if q==1:
            return pstr
        
        return ("{upar[0]}{up}{upar[1]}/{lpar[0]}{down}{lpar[1]}".format(
            up=pstr,down=qstr,upar=upar,lpar=lpar))
    def __format__(self,fmt):
        if fmt=="q":
            pstr=str(self.p)
            qstr=str(self.q)

            pstrlen=max(len(pstr.split(" + ")),len(pstr.split(" - ")))
            qstrlen=max(len(qstr.split(" + ")),len(qstr.split(" - ")))
            upar="()" if pstrlen>1 else ["",""]
            lpar="()" if qstrlen>1 else ["",""]
        ##print("debug",self.p,self.q)
            return ("{upar[0]}{up}{upar[1]}/{lpar[0]}{down}{lpar[1]}".format(
            up=pstr,down=qstr,upar=upar,lpar=lpar))
        else: 
            return str(self)

    def inv(self):
        ##print(f"self {self},|{self.p},{self.q} | invself {Quotient(self.q,self.p)}")
        return Quotient(self.q,self.p)
    def __neg__(self):
        return Quotient(-self.p,self.q)
    def deriv(self,var):
        return Quotient(self.p.deriv(var)*self.q-self.p*self.q.deriv(var),self.q**2)
    def __truediv__(self,other):
        ##print("Quot div",self,"|",other)
        

        if not isinstance(other,Quotient):
            other=Quotient(other)
        if other.p==0:
            raise ZeroDivisionError("Deleni nulou!")
        else: 
         #   #print("here",self,type(other),type(other.inv()),self*other.inv())
            return self*other.inv()

    def __rtruediv__(self,other):
        
        if self.p==0:
            raise ZeroDivisionError("Deleni nulou!")
        else:
            if not isinstance(other,Quotient):
                other=Quotient(other)
            return other/self
    def __eq__(self,other):
        if  isinstance(other,(int,float,Monom,Polynomial)):
            ##print(self,other)
            ##print(",".join(map(repr,(self.p,self.q,other,other*self.q))))
            if self.q==1:
                return self.p==other
            else:
                
                return self.p==other*self.q
        else:
            return self.p*other.q==self.q*other.p

    def simplify(self):
        if self.p.order>self.q.order:
            return self.p.longdiv(self.q)

class Vector:
    def __init__(self,*values):
        ##print("Vector got values",values)
        self.values=list(values)
        self.dim=len(self.values)

    def __add__(self,other):
        if isinstance(other,(int,float)):
            return Vector(*(val+other for val in self.values) )
        if self.dim!=other.dim:
            raise ValueError("The vectors must have same dimension!")
        return Vector(*(val1+val2 for val1,val2 in zip(self.values,other.values)))
    __radd__=__add__

    def __neg__(self):
        return Vector(*(-val for val in self.values))

    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return -self+other
    def __mul__(self,other):
        if not isinstance(other,(int,float)):
            raise NotImplementedError("A vector can only be multiplied by a number! The Lie algebra is not implemented yet")
        else:
            return Vector(*(val*other for val in self) )
    __rmul__=__mul__
    
    def cross(self,other):
        if self.dim==2:
            vec1=Vector(*self.values,0)
        else:
            vec1=self
        if other.dim==2:
            vec2=Vector(*other.values,0)
        else:
            vec2=other
        ##print(vec1.dim,vec1,vec2.dim,vec2)
        if vec1.dim==vec2.dim!=3:
            raise ValueError("The vector product of two vectors satisfying Jacobi's identity is only defined in dimension 3!")
        x1,y1,z1=vec1.values
        x2,y2,z2=vec2.values
        return Vector(y1*z2-y2*z1,z1*x2-z2*x1,x1*y2-x2*y1)

        

    def dot(self,other):
        if not isinstance(other,Vector):
            raise ValueError("The right argument has to be a vector!")
        if self.dim!=other.dim:
            raise ValueError("The vectors need to have identical dimensions!")
        return sum(val1*val2 for val1,val2 in zip(self.values,other.values))
    def __repr__(self):
        return f"Vector("+",".join(str(value) for value in self.values)+")"
    def __str__(self):
        
        return f"V( "+" , ".join(truncate_number(value) if isinstance(value,float) else "".join(map(str,value))
        if isinstance(value,tuple) else str(value) for value in self.values)+" )"
    def __eq__(self,other):
        if isinstance(other,(int,float)):
            return  all(comp==other for comp in self)
        return all(c1==c2 for c1,c2 in zip(self,other))
    def __iter__(self):
        return iter(self.values)
def test():
    x=Monom(3,{"x":2,"y":3})
    y=Monom(9,{"x":4,"y":12})
    z=Monom(12,{"x":4,"y":12,"z":3})
    #print("Factoring ",x+y+z)
    #print("||".join(str(el) for el in (x+y+z).factor_variables()))
    x=Monom(1,{"x":1})
    y=Monom(1,{"y":1})
    z=Monom(1,{"z":1})
    #p=6*x**2*y**3+9*x**4*y**5+15*x**5*y**4*z**3
    #q=6*x**2*y**3+9*x**4*y**5+15*x**5*y**4*z**3
    #z=p/(2*q)
  
    #print("Factoring ",p)
    #print(" | ".join(str(el) for el in p.factor_variables()))
    #print("Factoring ",q)
    #print(" | ".join(str(el) for el in q.factor_variables()))
    #print("Canceling ",z)
    #z=z.cancel_common_prefactors()
    #print(x/y)
    #print("The result is: ",z)

"""
def factor_variables(self):
    cf=1
    d=None
    d=self.monlist[0].coef
    for mon in self.monlist[1:]:
        d=gcd(d,mon.coef)
    pref_vars={var:min(mon.vars.get(var,0) for mon in self.monlist) for var in self.varset}
    prefactor=Monom(d,pref_vars)
    new_coefs=(mon.coef//d for mon in self.monlist)
    new_vars=({var:mon.vars[var]-pref_vars[var] for var in mon.vars}  for mon in self.monlist)
    return (prefactor,Polynomial(Monom(coef,var) for coef,var in zip(new_coefs,new_vars)))
"""


def gcd(a,b):
    #print("gcd:",a,b)
    if a==0:
        return b
    if b==0:
        return a
    if not (int(a)==a and int(b)==b):
        if a%b==0:
            #print("Warning! a or b is not integer! Since b | a, I return  b")
            return b
        elif b%a==0:
            #print("Warning! a or b is not integer! Since a | b, I return  a")
            return b
        else:
            #print("Warning! a or b is not integer! Since not b | a nor a|b , I return  1")
            return 1 # max(abs(a),abs(b))/min(abs(a),abs(b))
    a,b=(a,b) if a>=b else (b,a)
    while True:
        if b==0:
            return a
        else:
            a,b=b,a%b


def lcm(a,b):
    return a*b//gcd(a,b)

if __name__=="__main__":
    x=Monom(5,{"x":3})
    s=go.Sin(x)
    print(x)
    print(x.eval_objs(x=3))
    print(s)
    y=Monom(2,{"("+str(s)+")":(s,2)})
    print(y)
    print(y.eval_objs(x=0))
    q=Monom(1,{"("+str(x)+")":(x,2)})
    print(q,q**2)
    print(q.eval_objs(y=2),(q**2).eval_objs(y=2))
    #s=go.Sin()