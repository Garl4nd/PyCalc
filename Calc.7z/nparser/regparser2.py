from regparser import Op,Parser
from polynom import SPolynomial#Polynomial,Monom

class aParser(Parser):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        #self.add_operator("x",0,0,lambda:SPolynomial("x",0,1))
        self.pollist=[]
    def _parse(self,text:str,level=(0,0)):
        self.partial_results.append([level,self.unmake_unique_text(text),"sym",None])
        #print(text)
        #print(text)
        text=self.strip_brackets(text)
        #print(text)
        if self.is_final(text): # Obecne by tu mohlo byt nejake jine kriterium
        #    print(f"final {text}")
            #return(str(float(text)))
            
            res=self.convert_to_final(text) # a zde by se mohli vracet obecnejsi algebraicke objekty
            #print(text,res)
            self.partial_results.append([level,res,"res",None])
            return res


        #self.partial_results.append((level,self.unmake_unique_text(text),"sym"))
        
        
        for symbol,op in self.operators.items():
            
        # while True:
                #print(f"text: {text}")
         #       print(text)
                brack_inds=self._filter_brackets(text)
                #text=self.strip2(text,brack_inds)
                #print(f"Before mask {text}") 
                if op.direction=="right":
                    ind=self.mask_text(text,brack_inds).find(symbol)
                else:
                    ind=self.mask_text(text,brack_inds).rfind(symbol)
                #ind=text.find(symbol)
                if ind==-1: 
                   # break
                   continue
                else:
                    if op.direction=="right":
                        is_conflict=self.check_forward_conflicts(text[ind:ind+self.max_symbol_len],symbol)
                    else:
                        if ind<self.max_symbol_len:
                            is_conflict=self.check_forward_conflicts(text[ind::-1],symbol)
                        else:
                            is_conflict=self.check_forward_conflicts(
                                text[ind:ind-self.max_symbol_len:-1],symbol)
                    if is_conflict: #alternativa: maskovat prekryvajici se operatory krizkem #
                        continue
                    lp=text[:ind]
                    rp=text[ind+len(symbol):]
                    #print(symbol)
                    #print(f"Before eval: lp = {lp}, rp= {rp}")
                    
                    if op.arity==0:
                        res=op.intr()
                        #print(f"res {res} , {type(res)}")
                        self.partial_results.append([level,res,"res",None])
                        return res
                    else:
                        if op.arity==1:
                            res=self.expr_eval1(lp,rp,op,level=level)
                            self.partial_results.append([level,res,"res",None])
                            return res
                     #       print(lp,rp)
                          
                        elif op.arity==2:
                            if ""  in [lp,rp] and op.unary_overload:
                            #    print("Overloading")
                                if lp=="":
                             #       print("Overloading right")
                                    if op.unary_overload.acts_on=="left":
                                        
                                        raise ValueError("Wrong direction of action!")
                                else:
                                    if op.unary_overload.acts_on=="right":
                                        raise ValueError("Wrong direction of action")
                                res=self.expr_eval1(lp,rp,op.unary_overload,level=level)
                                self.partial_results.append([level,res,"res",None])
                                return res
                            else:
                                res=self.expr_eval2(lp,rp,op,level=level)
                                self.partial_results.append([level,res,"res",None])
                                return res

                                
                            #print(f"Text: {text}")
        
        res=self.eval_funcs(text,level=(level[0],level[1]))
        self.partial_results.append([level,res,"res",None])
        return res
        #print(f"Konec: {text}")
        
        print(f"'{text}' neni Finalni!")
        if self.__error_text==text:
            self.__cur_error_depth+=1
            if self.__cur_error_depth>=self.max_error_depth:
                raise ValueError("Nezpracovatelny vyraz!")
        else:
            self.__error_text=text
            self.__cur_error_depth=0
                
        return(self._parse(text))
    def expr_eval1(self,lp,rp,op,level=(0,0)):
            #print(f"Unary, expr= {expr},op= {op.symbol}")
            #if self.is_number(expr):
            #    return op.intr(float(expr))
            #else:
            #return self.expr_eval1(self._parse(expr),op)
        xl,yl=level
        if op.acts_on=="left": 
            return op.intr(self._parse(lp,level=(xl,yl+1)))
        else:
            return op.intr(self._parse(rp,level=(xl,yl+1)))
                
    def is_final(self,text):
        if any(text.startswith(pl) for pl in self.pollist):
            return True
        try:
            float(text)
        except ValueError:
            
            return False
        else:
            return True
    
    def convert_to_final(self,text):
        for pl in self.pollist:
            if text==pl:
                return SPolynomial(pl,0,1)
        try:
            res=int(text)
        except ValueError:
            res=float(text)
        return res