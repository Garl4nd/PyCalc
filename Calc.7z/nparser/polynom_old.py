class Polynomial:
    def __init__(self,coefs={},implicit=False):
        if not implicit:
            self.rep=coefs # {"xyz": {(0,0,0):5,(2,0,1):10}}
        else:
            self.rep={}
            for var,cfs in coefs.items():
             
                self.rep[var]={(i,):el  for 
                                    i,el in enumerate(cfs)}
        #print(self.rep)

    def __add__(self,other):
        res={**self.rep,**other.rep}
        
        for var,coefs in self.rep.items():
            for var2,coefs2 in other.rep.items():
                if var==var2:
                    res[var]=self.add_same(coefs,coefs2)
        return Polynomial(res)

    def add_same(self,coefs,coefs2):
        res={**coefs,**coefs2}
        for order,value in coefs.items():
            for order2,value2 in coefs2.items():
                if order==order2:
                    #res[order]=tuple(num1+num2 for num1,num2 in zip(values,values2) )
                    res[order]=value+value2
        return res

    def __repr__(self):
        return str(self.rep)
    def __str__(self):
        s=""
        for var,coefs in self.rep.items():
            for order,value in coefs.items():
                for vind,sym in enumerate(var):
                    if value!=0:

                        if s=="":
                            coef=str(value)
                        else:
                            s+=(" ")
                            coef="{sym} {val}".format(sym="+" if value>0 else "-",val=value)
                        if order[vind]==0:
                            s+=f"{coef}"
                        elif order[vind]==1:
                            s+=f"{coef}{sym}"
                        else: 
                            print(value)
                            s+=f"{coef}{sym}^{order[vind]}"
        if s=="":
            s="0"
        return s
x=Polynomial({"x":(1,2,3)},implicit=True)
y=Polynomial({"x":(1,0,3,4)},implicit=True)
print(f"{x}+{y} = {x+y}")

