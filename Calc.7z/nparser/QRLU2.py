from gen_obj import Vector
import numpy as np
from operator import mul
import functools as ft
tol=1.e-6
def LUdecomp(A):
    U=np.array(A)
    nx,_=np.shape(U)
    L=np.eye(nx)
    perms=[]
    for n in range(nx-1):
        if abs(U[n,n])<tol:
        #    print("zero")
            for i in range(n+1,nx):
                if abs(U[i,n])>tol:
                    U[[i,n]]=U[[n,i]]
                    perms.append((n,i))
                    break
                        #print(perms)
                        #input()

                  #  P[i,i],P[n,n]=0,0
                  #  P[i,n],P[n,i]=1,1
                    
            else:
                li=0
                L[n,n+1:]=li
                continue
    #print("permuted U:",U)
    for n in range(nx-1):
        li=U[n+1:,n]/U[n,n]
        #for i in range(n+1,nx):
        #    U[i,:]=U[i,:]-li[i-n-1]*U[n,:]
        U[n+1:,:]=U[n+1:,:]-np.outer(li,U[n,:])
        L[n+1:,n]=li
    
    return L,U,perms

def LUPsolve(A,Borig):
    B=np.array(Borig)
    L,U,perms=LUdecomp(A)
    lx,*ly=np.shape(B)
    
    if not ly:
        B=np.reshape(B,(lx,1))
        ly=1
    else:
        ly=ly[0]
    x=np.empty((lx,ly))
    y=np.empty((lx,ly))
  #  print("perms",perms)
  #  print("B",B)
    for perm in perms:
        B[[perm[0],perm[1]]]=B[[perm[1],perm[0]]]
    #print("B",B)
    for i in range(lx):
        for k in range(i):
            B[i,:]=B[i,:]-L[i,k]*y[k,:]
        y[i,:]=B[i,:]/L[i,i]
    #print("U:",U,"y:",y)
    for i in reversed(range(lx)):
        for k in range(i+1,lx):
            y[i,:]=y[i,:]-U[i,k]*x[k,:]
        x[i,:]=y[i,:]/U[i,i]
    return x
def LUPinverse(A):
    return LUPsolve(A,np.eye(len(A)))

def QRdecomp(A):
    vs=[vec for vec in np.transpose(A)]
    nx,ny=np.shape(A)
    Q=np.empty((nx,nx))
    es=[]
    R=np.zeros((nx,ny))
    r=0
    for i,v in enumerate(vs):
        u=vs[i]
        
        for ind,e in enumerate(es):
            R[ind,r]=np.dot(u,e)
            #print("u",u)
            u=u-R[ind,r]*e
        magu=np.sqrt(abs(np.dot(u,vs[i])))
        if magu>tol:
            es.append(u/magu)
            R[r,r]=magu
            r+=1
    
    for i in range(r,min(nx,ny)):
        while True:
            u=np.random.random(nx)
            for ind,e in enumerate(es):
                u=u-np.dot(u,e)*e
            magu=np.sqrt(abs(np.dot(u,u)))
            if magu>tol:
                es.append(u/magu)
                break
    for i,e in enumerate(es):
        Q[:,i]=e
    #for i,v in enumerate(vs[nx:]):
    #    R[:,nx+i]=[np.dot(v,e) for e in Q] 
    return Q,R,r   

def QRsolve(A,B):
    Q,R=QRdecomp(A)
    lx,*ly=np.shape(B)
    if not ly:
        B=np.reshape(B,(lx,1))
        ly=1
    else:
        ly=ly[0]
    x=np.empty((lx,ly))
    y=np.matmul(np.transpose(Q),B)

   # print("Q:",Q,"B:",B,"R:",R,"y:",y)
    for i in reversed(range(lx)):
        for k in range(i+1,lx):
            y[i,:]=y[i,:]-R[i,k]*x[k,:]
        x[i,:]=y[i,:]/R[i,i]
    return x

def QRsolve2(A,Bc):
    B=np.array(Bc)
    Q,R,r=QRdecomp(np.transpose(A))
    L=np.transpose(R)
    lx,*ly=np.shape(B)
    if not ly:
        B=np.reshape(B,(lx,1))
        ly=1
    else:
        ly=ly[0]
    x=np.empty((lx,ly))
    y=np.empty((lx,ly))
   # print("Q:",Q,"B:",B,"R:",R,"y:",y)
    print("r:",r)
    print("R:",R)
    ker=Q[r:]
    print("Kernel:",Q[r:])
    input()
    print("L:",L)
    input()
    for i in range(r):
        for k in range(i):
            B[i,:]=B[i,:]-L[i,k]*y[k,:]
        y[i,:]=B[i,:]/L[i,i]
    
    return np.matmul(Q,y),True,ker
def QRinv(A):
    return QRsolve(A,np.eye(len(A)))
def QRdet(A):
    _,R=QRdecomp(A)
    try:
        return ft.reduce(mul,[R[i,i] for i in range(len(np.transpose(R)))])
    except IndexError:
        return 0
 
mat=np.array(((0,0,1),(4,1,0),(7,8,0)),dtype=np.float)
#print(mat)
#input()
L,U,perms=LUdecomp(mat)
#print("L",L)
#print("U",U)
#print(np.matmul(L,U))
#print(perms)
#mat=np.array([[1,1,1],[2,4,5],[1,3,6]],dtype=np.float)
mat=np.array([[1,0,0],[1,0,0],[0,0,0]],dtype=np.float)



b=np.array([1,1,3],dtype=np.float)

#print("LUmul",L,U,np.matmul(L,U),"end")

#print(LUPsolve(mat,b))
print(QRsolve2(mat,b))


Q,R,r=QRdecomp(mat)
print(Q,"_____")
print(R,"_____")
print(r,"_____")
print(np.matmul(Q,R))
print(np.matmul(Q,np.transpose(Q)))
"""
imat=LUPinverse(mat)
print(LUPinverse(mat))
print(np.matmul(mat,imat))

Q,R=QRdecomp(mat)
print("mat:",mat)
print("Q:",Q,R)
print(np.matmul(Q,R))
"""