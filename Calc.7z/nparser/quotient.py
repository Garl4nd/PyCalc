from polynom import Polynomial,SPolynomial,Monom,Quotient

s=Quotient(6,2)

#print(s,type(s))


#print(s==3)
p=SPolynomial("x",1,3)
q=SPolynomial("x",8,5,3)
z=p/q
print(p,"| ",(p/q/p*q))
q=Polynomial([Monom(0.0,{}),Monom(0.0,{})])
#print(repr(q))
#input()
s,r,partial=().longdiv(p)
print(s,f",zb. {r}")
print("Postupne:",[str(p) for p,_ in partial])
