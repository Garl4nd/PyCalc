#from . import gen_obj
from .gen_obj import Vector,Variable,Func,Monom,GeneralObject
import functools as ft
from operator import mul
import math
class Angle(Func):
    @property
    def name(self):
        return "angle"
    @property
    def func(self):
        def angle(real,imag):
            conv=1 #180/math.pi
            if real>0:
                if imag>=0:
                    return math.atan(imag/real)*conv
                else:
                    return (2*math.pi+math.atan(imag/real))*conv
            elif real<0:
                return (math.atan(imag/real)+math.pi)*conv
            else:
                if imag>=0:
                    return math.pi/2*conv
                else:
                    return 3*math.pi/2*conv
        return angle
    @property
    def numarg(self):
        return 2
    @property
    def inverse(self):
        return type(None)
class Complex(Vector):
    def __init__(self,real,imag=None):
        if isinstance(real,Complex):
            self.real=real.real
            self.imag=real.imag
        else:
            if imag is None:
                imag=0
            self.real=real
            self.imag=imag
        
        self.attached=self.values=[real,imag]
        self.dim=2 #len(self.values)
    def eval(self,**at):
        try:
            rres=self.real.eval(**at)
        except (AttributeError,TypeError):
            rres=self.real
        try:
            ires=self.imag.eval(**at)
        except (AttributeError,TypeError):
            ires=self.imag
        return Complex(rres,ires)
    def __add__(self,other):
        print(type(other))
        if isinstance(other,Complex):
            return Complex(self.real+other.real,self.imag+other.imag)
        elif isinstance(other,(Vector,):
            print("Vector")
            return Vector(*(self+comp for comp in other.values))            
        else:
            return Complex(self.real+other,self.imag)
    __radd__=__add__
    def __neg__(self):
        return Complex(-self.real,-self.imag)
    def __sub__(self,other):
        return self+(-other)
    def __rsub__(self,other):
        return (-self)+other
    def __mul__(self,other):
        if isinstance(other,Complex):
          #  print("compmul",
          #  " | ".join(str(el) for el in (self.real,
           # self.imag,repr(self.real),repr(other.real),repr(self.real*other.real),type(self.real*other.real))))
            return Complex(self.real*other.real-self.imag*other.imag,self.real*other.imag+self.imag*other.real)
        else: 
            return Complex(self.real*other,self.imag*other)
    __rmul__=__mul__

    def conj(self):
        return Complex(self.real,-self.imag)
    
    def angle(self):
        return Angle(self.real,self.imag).eval()
    def __pow__(self,exponent):
        ang=self.angle()#*math.pi/180
        print(ang)
        if isinstance(exponent,int):
            if exponent>=0:
                return ft.reduce(mul,(self for _ in range(exponent)),1)
        return self.norm()**exponent*Complex((gen_obj.Cos(exponent*ang)).eval(),gen_obj.Sin(exponent*ang).eval())
    def __str__(self):
        real,imag=self
        lpar,rpar=["",""]
        if real==0:
            rstr=""
        else:
            rstr=str(real)
            try:
                rstr+=("+" if imag>0 else "")
            except TypeError:
                if isinstance(imag,Monom):
                    rstr+=("+" if imag.coef>0 else "")
                else:
                    rstr+="+"
                    lpar,rpar="()"
        if imag==0:
            istr=""
        else:
            if imag==1:
                ipref=""#str(imag)
            elif imag==-1:
                ipref="-"
            else:
                ipref=str(imag)
            istr=ipref+"i"
        return rstr+lpar+istr+rpar
    def __float__(self):
        return float(self.real)
    def __int__(self):
        return int(self.real)
    def __complex__(self):
        return complex(self.real,self.imag)
    def __repr__(self):
        return f"Complex({repr(self.real)},{repr(self.imag)})"


""" def eval(self,*args,**kwargs): #nefunguje správně, co když některé argumenty budou čísla a jiná ne? Aha, možná to funguje správně

        if len(self.attached)!=self.numarg:
            raise ValueError(f"Func {self.name}  needs to take exactly {self.numarg} argument(s)!")
        else:
            if all( isinstance(obj,self.evaluables) for obj in self.attached):
              #  print("evaluable")
                
                return self.func(*self.attached)
            else:
             #   print("evaling",self.attached,kwargs)
                results=[obj.eval(*args,**kwargs) if isinstance(obj,GeneralObject) else obj for obj in self.attached]
            #    print("results:",results)
                if all(isinstance(res,self.evaluables) for res in results):
                    return self.func(*(obj.eval(*args,**kwargs) for obj in self.attached))
                else:
                    
                    tr=self.__class__(*results)
                    
                  #  print("r,tr",results,tr)
                    return tr
"""