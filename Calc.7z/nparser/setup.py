from distutils.core import setup
import setuptools
from Cython.Build import cythonize

setup(
    name='Prime app',
    package_dir={'cython_test': ''},
    ext_modules=cythonize("prime_fact.py"),
)