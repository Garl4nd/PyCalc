class MeasureTime(start_text="It"):
    def q():
        self.t0=time.time()
    def __exit__(self,type,value,tb):        
        print(f"{start_text} took {time.time()-self.t0} s")
        input()