from . import gen_obj
from .gen_obj import * 

class BVP(GeneralObject):
    @property
    def name(self):
        return "BVP"
    @property
    def evaluables(self):
        return int,float
    @property
    def is_evaluable(self):
        return True

    def __init__(self,*args,t0=0.0,t1=1.0,n=100,is_map=False):
        self.is_map=is_map
        try:
            #self.args=Vector(*args)
            
            self.args=Vector(*args)
            args=iter(args)
            self.funcs=[];self.init_points=[]
            try:
                while True:
                    self.funcs.append(next(args))
                    self.init_points.append(next(args))
            except StopIteration:
                if len(self.init_points)<len(self.funcs):
                    raise ValueError("Must supply initial conditions for all functions!")
            
        except TypeError:
            funcs,init_points=self.args
            self.funcs=[funcs]
            self.init_points=[init_points]
        self.t0=t0
        self.t1=t1
        self.n=n
        self.data=list(zip(self.funcs,self.init_points))
        self.attached=self.args

    def eval(self,*args,**kwargs):
        dargs=(arg.eval(*args,**kwargs) if isinstance(arg,GeneralObject) else arg for arg in self.args)
        return BVP(*dargs,t0=self.t0,t1=self.t1,n=self.n,is_map=self.is_map)
    def calculate(self,t0=0,t1=1,n=100):
        return self.pairwise_dif_eq(self.funcs,self.init_points,t0=t0,t1=t1,n=n)

    def dif_eq(self,func,init_point,t0=0,t1=1,n=100):
        from scipy.integrate import solve_bvp
        try:
            if n<0 or int(n)!=n:
                raise ValueError("n (tden)  must be a non-negative natural number!")
        except TypeError:
            raise ValueError("n (tden) must be a non-negative natural number!")
        if not isinstance(func,GeneralObject):
            func=Monom(func)
        if not isinstance(func,Vector):
            try:
                if isinstance(func,Complex):
                    func=Vector(func)
                else:
                    func=Vector(*func)
            except TypeError:
                func=Vector(func)
        if not isinstance(init_point,Vector):
            
            try:
                if isinstance(init_point,Complex):
                    init_point=Vector(init_point)
                else:
                    init_point=Vector(*init_point)
            except TypeError:
                init_point=Vector(init_point)
        #print(func,init_point)
        if func.dim!=init_point.dim:
            raise ValueError("The dimensions of the mapping function and of the initial point must be equal!")
        
        tarr=np.linspace(t0,t1,n)
        adjvars=func.get_vars().difference({"t"})
        ordvars={var for var in adjvars if not (len(var)>1 and var.startswith("d")) and var.islower() }
        dvars=adjvars.difference(ordvars)
        for var in dvars:
            if var.startswith("d") and var[1:] not in ordvars:
                ordvars.add(var[1:])
            elif var.isupper() and var.lower() not in ordvars:
                ordvars.add(var.lower())

        if not adjvars:
            ordvars={"y"}
        
        vars=sorted(ordvars)+sorted(dvars)
        #print(init_point)
        init_point=list(init_point)
        def f(t,y):
            #return func.numcompose(y,t)
            #return [*func.eval(**{var:comp for var,comp in zip(["t"]+vars,[t]+list(y))})]
            #print(np.shape(t))
            
            return [*func.numcompose(**{var:comp for var,comp in zip(["t"]+vars,[t]+list(y))})]
        def boundary(y0,y1):
            
            #print(init_point)
            
            if len(y0)%2==0:
                n=len(y0)//2
                #print ([y0[i]-init_point[i] for i in range(n)]+[y1[i]-init_point[i+n] for i in range(n)])
           #     return[y0[0]-init_point[0],y1[0]-init_point[2],y0[1]-init_point[2],y1[1]-init_point[3]]
                return [y0[i]-init_point[i] for i in range(n)]+[y1[i]-init_point[i+n] for i in range(n)]
            else:
                return [y0[i]-init_point[i] for i in range(len(y0))]
        #print("ip",init_point)
        y_init=[tarr  for _ in init_point]
        solver=solve_bvp(f,boundary,tarr,y_init)
        if solver.status!=0:
            raise ValueError("THe BVP failed to converge! ")
        print(np.shape(tarr),solver.sol(tarr))
        #return tarr,solver.sol(tarr),["t"]+vars
        return np.c_[tarr,np.transpose(solver.sol(tarr))],["t"]+vars

        #return Vector(*res)
    
    def pairwise_dif_eq(self,funcs,init_points,t0=0,t1=1,n=100):
        #args=list(args)
        #print(args)
        """
        try:
            funcs,init_points=zip(*args)
        except TypeError:
            funcs,init_points=args
            funcs=[funcs]
            init_points=[init_points]
        """
        names=[f"f = ${func}$, init: {init}" for func,init in zip(funcs,init_points)]
        res_array=[]
        
        for func,init_point in zip(funcs,init_points):
            res,var=self.dif_eq(func,init_point,t0=t0,t1=t1,n=n)
            res_array.append(res)
            #res_array.append(self.dif_eq(func,init_point,t0=t0,t1=t1,n=n))
        return res_array,names,var
        
    def __repr__(self):
        return f"ODE object with data: {self.args}, is_map = {self.is_map}"
    def __str__(self):
        if self.is_map:
            return "System of maps with equations: \n\t"+"\n\t".join(f'f= {func}, init point: {init}' for func,init in zip(self.funcs,self.init_points))
        else:
            return "System of ODEs with equations: \n\t"+"\n\t".join(f'f= {func}, init point: {init}' for func,init in zip(self.funcs,self.init_points))